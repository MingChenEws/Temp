﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;
using System.Diagnostics;
using System.Linq;

using GTID_Class;

namespace GTID_BridgeSocket
{
    public class BridgeSocketModule : GTID_Module
    {
        bool bContinue = true;
        private int MSGHDRLEN = 4;
        private uint mCurrentChanId = 0;
        private byte mCurrentReq = 0;
        private byte[] appId = new byte[32];
        List<AppIdKeyHandle> listAppIdKeyHandle = new List<AppIdKeyHandle>();

        Socket ListenSocket = null;
        Socket ClientSocket = null;

        public BridgeSocketModule()
        {
            moduleType = GTID_TYPE_TRANSPORT;
            moduleFunction = GTID_TRANSPORT_SOCKET;
        }

        private class AppIdKeyHandle
        {
            public byte[] mAppId;
            public byte[] mKeyHandle;

            public AppIdKeyHandle(byte[] a, byte[] k)
            {
                this.mAppId = a;
                this.mKeyHandle = k;
            }
        }

        override
        public Task Run()
        {
            Console.WriteLine(getTimeStamp() + "Start BridgeSocketModule...");
            try
            {
                moduleTask = Task.Factory.StartNew(() => Start(), cts.Token);
            }
            catch (TaskCanceledException)
            {
                ready = false;
            }

            return moduleTask;
        }

        override
        public int Send(byte function, byte cmd, uint cid, byte[] packet, int len)
        {
            mCurrentChanId = cid;
            if (packet != null)
            Console.WriteLine(getTimeStamp() + "BridgeSocketModule.Send: cmd=0x{0:X2}, INS=0x{1:X2}, INS=0x{2:X2}", 
                cmd, packet[1], packet[2]);
            if (cmd == 0x83) //CTAPHID_MSG
            {
                mCurrentReq = packet[1];
                if ((packet[1] == 0x01) || (packet[1] == 0x02))
                {
                    System.Buffer.BlockCopy(packet, 39, appId, 0, 32); // appID
                    if (packet[2] == 0x07) // Check Only
                    {
                        int keyHandleLen = packet[71];
                        byte[] keyHandle = new byte[keyHandleLen];
                        System.Buffer.BlockCopy(packet, 72, keyHandle, 0, keyHandleLen); // keyHandle
                        return checkKeyHandle(appId, keyHandle);
                    }
                }
            }

            if (ClientSocket != null)
            {

                //byte[] hdr = new byte[8] { function, cmd, (byte)(len % 256), (byte)(len >> 8),
                //                        (byte)(cid % 256), (byte)(cid >> 8), (byte)(cid >> 16), (byte)(cid >> 24) };
                byte[] hdr = new byte[8] { function, cmd, (byte)(len >> 8), (byte)(len % 256),
                                        (byte)(cid >> 24), (byte)(cid >> 16), (byte)(cid >> 8), (byte)(cid % 256) };
                byte[] message = null;
                if (len > 0)
                {
                    message = new byte[len + MSGHDRLEN];
                    System.Buffer.BlockCopy(hdr, 0, message, 0, MSGHDRLEN);
                    System.Buffer.BlockCopy(packet, 0, message, MSGHDRLEN, len);
                }
                else
                {
                    message = new byte[MSGHDRLEN];
                    System.Buffer.BlockCopy(hdr, 0, message, 0, MSGHDRLEN);
                }
                return ClientSocket.Send(message);
            }
            return -1;
        }

        override
        public void setStreamModule(GTID_Module module)
        {
            streamModule = module;
        }


        override
        public void Stop()
        {
            //Console.WriteLine(getTimeStamp()+"Stop BridgeSocketModule...");

            if (ListenSocket != null)
            {
                ListenSocket.Close();
            }
            if (ClientSocket != null)
            {
                ClientSocket.Close();
            }

            Console.WriteLine(getTimeStamp() + "Exit BridgeSocketModule...");
            cts.Cancel();
            bContinue = false;
        }

        override
        public void Configure(List<KeyValuePair<string, Object>> kvlist)
        {

        }

        private void Start()
        {
            do
            {
                try
                {
                    //IPAddress addr = IPAddress.Loopback;
                    IPAddress addr = IPAddress.Any;
                    ListenSocket = new Socket(
                            addr.AddressFamily,
                            SocketType.Stream,
                            ProtocolType.Tcp);
                    IPEndPoint localEndPoint = new IPEndPoint(addr, 27015);

                    ListenSocket.Bind(localEndPoint);
                    ListenSocket.Listen(1);
                    Console.WriteLine(getTimeStamp() + "Start Listening socket...");

                    ClientSocket = ListenSocket.Accept();
                    ready = true;
                    ListenSocket.Close();
                    ListenSocket = null;
                    Console.WriteLine(getTimeStamp() + "Bridge socket connected");

                    //retrieve stored appId & keyHandle
                    ClientSocket.Send(new byte[5] { 0x01, 0x88, 0x00, 0x01, 0x00 });

                    byte[] msgRcvd = new byte[1024];
                    int iLen = 0;

                    do
                    {
                        iLen = ClientSocket.Receive(msgRcvd);
                        if (iLen > 0)
                        {
                            Console.Write(getTimeStamp() + "BRIDGE_SOCKET ");

                            //displayHexDump(msgRcvd.data);

                            if (msgRcvd[1] == 0x88) // WINK to retrieve stored appId & keyHandle
                            {
                                int len = (int)((msgRcvd[2] << 8) + msgRcvd[3]);
                                //(int)((msgRcvd[3] << 8) + msgRcvd[2]));
                                int idx = 0;
                                while(idx < len)
                                {
                                    byte[] appId = new byte[32];
                                    System.Buffer.BlockCopy(msgRcvd, idx + 1 + MSGHDRLEN, appId, 0, 32);
                                    int keyHandleLen = msgRcvd[idx + MSGHDRLEN];
                                    byte[] keyHandle = new byte[keyHandleLen];
                                    System.Buffer.BlockCopy(msgRcvd, idx + 33 + MSGHDRLEN, keyHandle, 0, keyHandleLen);
                                    listAppIdKeyHandle.Add(new AppIdKeyHandle(appId, keyHandle));
                                    idx += (33 + keyHandleLen);
                                }
                                Console.WriteLine("[U2FHID_WINK]: rcvd {0:D} 0x{1:X2}{2:X2}{3:X2}{4:X2}, len={5:D}, LIST cnt={6:D}",
                                     iLen, msgRcvd[0], msgRcvd[1], msgRcvd[2], msgRcvd[3], len, listAppIdKeyHandle.Count);
                            }
                            else
                            { 

                                byte[] respData = new byte[iLen - MSGHDRLEN];
                                System.Buffer.BlockCopy(msgRcvd, MSGHDRLEN, respData, 0, respData.Length);

                                uint cid = mCurrentChanId;
                                if (MSGHDRLEN > 4)
                                {
                                    // Needs to add cid in the Bridge protocol to support more than 1 request
                                    //cid = (uint)((msgRcvd[7] << 24) + (msgRcvd[6] << 16) + (msgRcvd[5] << 8) + msgRcvd[4]);
                                    cid = (uint)((msgRcvd[4] << 24) + (msgRcvd[5] << 16) + (msgRcvd[6] << 8) + msgRcvd[7]);
                                }
                                if (mCurrentReq == 0x01)
                                {
                                    if (respData.Length > 2) // Success
                                    {
                                        int keyHandleLen = respData[66];
                                        byte[] keyHandle = new byte[keyHandleLen];
                                        System.Buffer.BlockCopy(respData, 67, keyHandle, 0, keyHandleLen); // keyHandle
                                        bool found = false;
                                        foreach(AppIdKeyHandle p in listAppIdKeyHandle)
                                        {
                                            if (appId.SequenceEqual(p.mAppId))
                                            {
                                                p.mKeyHandle = keyHandle;
                                                found = true;
                                                break;
                                            }
                                        }
                                        if (!found)
                                            listAppIdKeyHandle.Add(new AppIdKeyHandle(appId, keyHandle));
                                    }
                                }
                                Console.WriteLine("[U2FHID_MSG]: rcvd {0:D} 0x{1:X2}{2:X2}{3:X2}{4:X2}, len={5:D}, cid={6:D}, LIST cnt={7:D}",
                                    iLen, msgRcvd[0], msgRcvd[1], msgRcvd[2], msgRcvd[3],
                                    (int)((msgRcvd[2] << 8) + msgRcvd[3]), mCurrentChanId, listAppIdKeyHandle.Count);
                                //(int)((msgRcvd[3] << 8) + msgRcvd[2]));
                                streamModule.Send(msgRcvd[0], msgRcvd[1], cid, respData, respData.Length);
                            }
                        }
                        else
                        {
                            Console.WriteLine(getTimeStamp() + "Bridge socket closing or recv failed");
                            ClientSocket.Shutdown(SocketShutdown.Both);
                            ClientSocket.Close();
                            ClientSocket = null;
                        }

                    } while (iLen > 0);

                }
                catch (ArgumentNullException e)
                {
                    Debug.WriteLine("BridgeSocketModule [ArgumentNullException] -> " + e.Message);
                }
                catch (SocketException e)
                {
                    Thread.Sleep(1000);
                    if (streamModule != null)
                    {
                        TaskStatus st = streamModule.moduleTask.Status;
                        Debug.WriteLine("BridgeSocketModule [SocketException] -> " + e.Message);
                    }
                    else
                    {
                        Debug.WriteLine("BridgeSocketModule [SocketException]::streamModule NOT SET -> " + e.Message);
                    }
                    bContinue = false;
                }
                catch (Exception e)
                {
                    Debug.WriteLine("BridgeSocketModule [Exception] -> " + e.Message);
                }

                linkDown(1);
                //} while (streamModule.moduleTask.Status == TaskStatus.Running);
            } while (bContinue);
            linkDown(2);
        }

        private void linkDown(int step)
        {
            Console.WriteLine(getTimeStamp() + "BridgeSocketModule Link is DOWN......[{0:D}]", step);
            ready = false;
            listAppIdKeyHandle.Clear();
            if (streamModule != null) streamModule.streamDown();
        }

        public override void streamDown()
        {

        }

        private int checkKeyHandle(byte[] appId, byte[] keyHandle)
        {
            byte[] success = new byte[] { 0x69, 0x85 };
            byte[] fail = new byte[] { 0x6A, 0x80 };

            Console.Write(getTimeStamp() + "BridgeSocketModule: checkKeyHandle [0x{0:X2}{1:X2}{2:X2}{3:X2}], ",
                keyHandle[0], keyHandle[1], keyHandle[2], keyHandle[3]);
            foreach (AppIdKeyHandle p in listAppIdKeyHandle)
            {
                if ((appId.SequenceEqual(p.mAppId)) && (keyHandle.SequenceEqual(p.mKeyHandle)))
                {
                    Console.WriteLine("return [0x{0:X2}{1:X2}]", success[0], success[1]);
                    streamModule.Send(0, 0x83, mCurrentChanId, success, success.Length);
                    return 2;
                }
            }
            Console.WriteLine("return [0x{0:X2}{1:X2}]", fail[0], fail[1]);
            streamModule.Send(0, 0x83, mCurrentChanId, fail, fail.Length);
            return 2;
        }
    }
}
