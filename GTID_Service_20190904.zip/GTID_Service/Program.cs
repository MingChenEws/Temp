﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Threading;
using System.Net.Sockets;
using System.Net;

using GTID_FidoHid;
using GTID_BridgeSocket;
using GTID_BlueTooth;

namespace GTID_Service
{
    class Program
    {
        static void Main(string[] args)
        {
            bool useBlueTooth = true;

            List<Task> TaskList = new List<Task>();

            FidoHidModule fidoHidModule = new FidoHidModule();
            Task taskFidoHidModule = fidoHidModule.Run();
            if (taskFidoHidModule != null) TaskList.Add(taskFidoHidModule);

            BridgeSocketModule bridgeSocketModule = new BridgeSocketModule();
            Task taskBridgeModule = bridgeSocketModule.Run();

            BlueToothModule blueToothModule = new BlueToothModule();
            Task taskAappService = blueToothModule.Run();

            if (useBlueTooth == true)
            {
                if (taskAappService != null) TaskList.Add(taskAappService);
                blueToothModule.setStreamModule(fidoHidModule);
                fidoHidModule.setStreamModule(blueToothModule);
                Console.WriteLine("{0:MM/dd/yyyy hh:mm:ss.fff} Use BlueToothModule as Transport...({1:D})", DateTime.Now, TaskList.Count);
            }
            else
            {
                if (taskBridgeModule != null) TaskList.Add(taskBridgeModule);
                fidoHidModule.setStreamModule(bridgeSocketModule);
                bridgeSocketModule.setStreamModule(fidoHidModule);
                Console.WriteLine("{0:MM/dd/yyyy hh:mm:ss.fff} Use BridgeSocketModule as Transport...({1:D})", DateTime.Now, TaskList.Count);
            }

            Task.WaitAll(TaskList.ToArray()); // Wait for all tasks to finish

            if (useBlueTooth == true)
            {
                Console.WriteLine("{0:MM/dd/yyyy hh:mm:ss.fff} Stopping BlueToothModule... ", DateTime.Now);
                bridgeSocketModule.Stop();
            }
            else
            {
                Console.WriteLine("{0:MM/dd/yyyy hh:mm:ss.fff} Stopping BridgeSocketModule... ", DateTime.Now);
                blueToothModule.Stop();
            }

            Thread.Sleep(2000);
            Console.Write("\nExit GTID_Service, press Enter... ");
            Console.Read();

        }
    }
}









