﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;
using System.Timers;
using System.Diagnostics;
using System.Linq;

using GTID_Class;
using GTID_FidoHid.DllWrappers;
using GTID_FidoHid.DataStructure;

using System.Security.Cryptography;


namespace GTID_FidoHid
{
    public class FidoHidModule : GTID_Module
    {
        // constants
        private const int DigcfPresent = 0x00000002;
        private const int DigcfDeviceinterface = 0x00000010;
        private const int DigcfInterfacedevice = 0x00000010;
        private const uint GenericRead = 0x80000000;
        private const uint GenericWrite = 0x40000000;
        private const int FileShareRead = 0x00000001;
        private const int FileShareWrite = 0x00000002;
        private const int OpenExisting = 3;
        private const int EvRxflag = 0x0002;    // received certain character
        public const int FileFlagOverlapped = 0x40000000;

        private const ushort FidoVendorId = 0xDEED;
        private const ushort FidoProductId = 0xFEED;
        private const ushort FidoUsageId = 0x0001;
        private const ushort FidoUsagePage = 0xF1D0;
        private const ushort TXRX_PACKET_SIZE = 2048;
        private const ushort HID_RPT_SIZE = 64;

        private const ushort APDU_CID_OFFSET = 1;
        private const ushort APDU_INIT_CMD_OFFSET = 5;
        private const ushort APDU_INIT_BCNTH_OFFSET = 6;
        private const ushort APDU_INIT_BCNTL_OFFSET = 7;
        private const ushort APDU_INIT_DATA_OFFSET = 8;
        private const ushort APDU_CONT_SEQNO_OFFSET = 5;
        private const ushort APDU_CONT_DATA_OFFSET = 6;
        private const ushort HID_REPORT_FRAME_SIZE = 2;

        private const byte CTAPHID_INIT_FRAME = 0x80;
        // Manadatory CTAP HID native commands
        private const byte CTAPHID_PING = (CTAPHID_INIT_FRAME | 0x01);   // Echo data through local processor only
        private const byte CTAPHID_INIT = (CTAPHID_INIT_FRAME | 0x06);   // HID Init
        private const byte CTAPHID_MSG = (CTAPHID_INIT_FRAME | 0x03);    // Send U2F message frame
        private const byte CTAPHID_ERROR = (CTAPHID_INIT_FRAME | 0x3f);  // Error response

        // Manadatory FIDO2 New
        private const byte CTAPHID_CBOR = (CTAPHID_INIT_FRAME | 0x10);	// FIDO2 CBOR Message
        private const byte CTAPHID_CANCEL = (CTAPHID_INIT_FRAME | 0x11); // FIDO2 Cancel 
        private const byte CTAPHID_KEEPALIVE = (CTAPHID_INIT_FRAME | 0x3b);  // FIDO2 Keep Alive

        // Optional
        private const byte CTAPHID_WINK = (CTAPHID_INIT_FRAME | 0x08);   // Send device identification wink
        private const byte CTAPHID_LOCK = (CTAPHID_INIT_FRAME | 0x04);	// Send lock channel command

        // Vendor Specific
        private const byte CTAPHID_VENDOR_FIRST = (CTAPHID_INIT_FRAME | 0x40);	// First vendor defined command
        private const byte CTAPHID_VENDOR_EXIT = (CTAPHID_INIT_FRAME | 0x41);    // vendor EXIT
        private const byte CTAPHID_VENDOR_PING = (CTAPHID_INIT_FRAME | 0x43);   // vendor PING
        private const byte CTAPHID_VENDOR_RESET = (CTAPHID_INIT_FRAME | 0x44);	// vendor RESET
        private const byte CTAPHID_VENDOR_LAST = (CTAPHID_INIT_FRAME | 0x7f); // Last vendor defined command

        // U2F Control Byte
        private const byte U2F_UP_ENFORCE = 0x03;  // UP Enforce 
        private const byte U2F_CHECKONLY = 0x07;  // Check-Only

        // U2F native commands
        private const byte U2F_REGISTER = 0x01;	// Registration command
        private const byte U2F_AUTHENTICATE = 0x02;	// Authenticate/sign command
        private const byte U2F_VERSION = 0x03;	// Read version string command
        private const byte U2F_VENDOR_FIRST = 0x40;	// First vendor defined command
        private const byte U2F_VENDOR_LAST = 0x7f;  // Last vendor defined command

        // FIDO2 CBOR native commands
        private const byte FIDO2_MAKE_CREDENTIAL = 0X01;
        private const byte FIDO2_GET_ASSERTION = 0X02;
        private const byte FIDO2_CANCEL = 0X03;
        private const byte FIDO2_GET_INFO = 0X04;
        private const byte FIDO2_CLIENT_PIN = 0X06;
        private const byte FIDO2_RESET = 0X07;
        private const byte FIDO2_GET_NEXT_ASSERTION = 0X08;

        // CTAP1 Error Codes
        private const byte CTAP1_ERR_NONE = 0x00;	// No error
        private const byte CTAP1_ERR_INVALID_CMD = 0x01;	// Invalid command
        private const byte CTAP1_ERR_INVALID_PAR = 0x02;	// Invalid parameter
        private const byte CTAP1_ERR_INVALID_LEN = 0x03;	// Invalid message length
        private const byte CTAP1_ERR_INVALID_SEQ = 0x04;	// Invalid message sequencing
        private const byte CTAP1_ERR_MSG_TIMEOUT = 0x05;	// Message has timed out
        private const byte CTAP1_ERR_CHANNEL_BUSY = 0x06;	// Channel busy
        private const byte CTAP1_ERR_LOCK_REQUIRED = 0x0a;	// Command requires channel lock
        private const byte CTAP1_ERR_INVALID_CID = 0x0b;  // Command not allowed on this cid
        private const byte CTAP1_ERR_IGNORE = 0x7e;    // Ignore this error
        private const byte CTAP1_ERR_OTHER = 0x7f;    // Other unspecified error

        // CTAP2 Error Codes
        private const byte CTAP2_ERR_CBOR_PARSING = 0x10;
        private const byte CTAP2_ERR_CBOR_UNEXPECTED_TYPE = 0x11;
        private const byte CTAP2_ERR_INVALID_CBOR = 0x12;
        private const byte CTAP2_ERR_INVALID_CBOR_TYPE = 0x13;
        private const byte CTAP2_ERR_MISSING_PARAMETER = 0x14;
        private const byte CTAP2_ERR_CREDENTIAL_EXCLUDED = 0x19;
        private const byte CTAP2_ERR_PROCESSING = 0x21;
        private const byte CTAP2_ERR_UPSUPPORTED_ALGORITHM = 0x26;
        private const byte CTAP2_ERR_UPSUPPORTED_OPTION = 0x2B;
        private const byte CTAP2_ERR_INVALID_OPTION = 0x2C;
        private const byte CTAP2_ERR_KEEPALIVE_CANCEL = 0x2D;
        private const byte CTAP2_ERR_NO_CREDENTIALS = 0x2E;

        // Capabilities
        private const byte FIDO_CAPABILITY_WINK = 0x01;
        private const byte FIDO_CAPABILITY_LOCK = 0x02;
        private const byte FIDO_CAPABILITY_CBOR = 0x04;
        private const byte FIDO_CAPABILITY_NMSG = 0x08;

        private int INIT_DELAY = 200;
        private int CBOR_DELAY = 200;

        private const uint CID_BROADCAST = 0xffffffff;  // Broadcast channel id_
        private const uint TIMER_FIDO_MSG_NOT_SATISFIED = 1500;  // Yubico's way to send KEEP_ALIVE
        private const uint TIMER_FIDO_CBOR_KEEP_ALIVE = 250;  // Use this to pass conformance test
        //private const uint TIMER_FIDO_CBOR_KEEP_ALIVE = 500; // per Spec
        private const uint TIMER_FIDO_MAX_COMMAND_TRANSMIT_DELAY = 1500;  // per Spec
        //private const uint TIMER_FIDO_MAX_COMMAND_TRANSMIT_DELAY = 5000;
        private const uint TIMER_FIDO_CHANNEL_PROCESS = 35000;

        // varables
        private const byte supportU2FOnly = FIDO_CAPABILITY_WINK;
        private const byte supportFIDO2Only = FIDO_CAPABILITY_WINK | FIDO_CAPABILITY_CBOR | FIDO_CAPABILITY_NMSG;
        private const byte supportU2FandFIDO2 = FIDO_CAPABILITY_WINK | FIDO_CAPABILITY_CBOR;
        private byte fidoCapability = supportU2FOnly;

        private bool handleHidInfo = true;

        private byte[] FidoVersion;
        private int RequestMaxCount;
        private List<FidoRequest> fidoRequestList = new List<FidoRequest>();
        public ManualResetEvent txDone = new ManualResetEvent(false);

        private DeviceInformationStructure deviceInformation;
        public string DevicePath { get { return deviceInformation.DevicePathName; } }
        private SafeFileHandle ReadHandle;       // Read handle from the device
        private SafeFileHandle WriteHandle;      // Write handle to the device

        uint mChanIdPool = 0;
        FidoRequest curFidoReq;

        private const int hidBufLen = HID_RPT_SIZE + 1;
        private byte[] hidBuf = new byte[hidBufLen];

        byte[] rData = new byte[TXRX_PACKET_SIZE];
        //int rxAppLen;
        //int rxAppDataRecv;
        //int rxDataOffset;
        //int rxDataLen;
        //private byte rxCmd;
        //private int rxSeqNo = -1;
        //private uint rxChanId = 0;

        //byte[] tData = new byte[TXRX_PACKET_SIZE];
        int txAppLen;
        int txAppDataSent;
        int txDataOffset;
        int txDataLen;
        private byte txCmd;
        private int txSeqNo = -1;

        //private uint txChanId = 0;

        public class FidoRequest
        {
            public uint cid = CID_BROADCAST;
            public byte rxCmd = 0x00;
            public int rxSeqNo = -1;  // starting -1
            public int rxAppLen = 0;
            public int rxAppDataRecv = 0;
            public int rxDataOffset = 0;
            public int rxDataLen = 0;
            public uint cborKeepAliveTimeElapsed = 0;
            public bool sendNotSatisfied = true;
            public byte[] responseQueued = null;

            private FidoHidModule fidoModule = null;
            public System.Timers.Timer notSatisfiedTimer = null;
            public System.Timers.Timer waitRequestTimer = null;
            public System.Timers.Timer processTimer = null;

            public void rxReset()
            {
                //rxCmd = 0x00;
                rxSeqNo = -1;  // starting -1
                rxAppLen = 0;
                rxAppDataRecv = 0;
                rxDataOffset = 0;
                rxDataLen = 0;
            }

            public FidoRequest(uint cid, FidoHidModule fido)
            {
                this.cid = cid;
                this.fidoModule = fido;
            }

            ~FidoRequest()
            {
                Cancel();
            }

            public void startWaitRequestTimer()
            {
                waitRequestTimer = new System.Timers.Timer(TIMER_FIDO_MAX_COMMAND_TRANSMIT_DELAY);
                waitRequestTimer.Elapsed += OnWaitRequestTimedEvent;
                waitRequestTimer.Start();
            }

            public void cancelWaitRequestTimer()
            {
                if (waitRequestTimer != null)
                {
                    waitRequestTimer.Stop();
                    waitRequestTimer.Dispose();
                    waitRequestTimer = null;
                }
            }

            public void startTimer()
            {
                cancelWaitRequestTimer();

                if (rxCmd == CTAPHID_MSG)
                {
                    notSatisfiedTimer = new System.Timers.Timer(TIMER_FIDO_MSG_NOT_SATISFIED);
                    notSatisfiedTimer.Elapsed += OnNotSatisfiedTimedEvent;
                    notSatisfiedTimer.Start();
                }
                else
                {
                    notSatisfiedTimer = new System.Timers.Timer(TIMER_FIDO_CBOR_KEEP_ALIVE);
                    notSatisfiedTimer.Elapsed += OnCborNotSatisfiedTimedEvent;
                    notSatisfiedTimer.Start();
                    cborKeepAliveTimeElapsed = 0;
                }

                processTimer = new System.Timers.Timer(TIMER_FIDO_CHANNEL_PROCESS);
                processTimer.AutoReset = false;
                processTimer.Elapsed += OnProcessTimedEvent;
                processTimer.Start();
            }

            public void Cancel()
            {
                if (notSatisfiedTimer != null)
                {
                    notSatisfiedTimer.Stop();
                    notSatisfiedTimer.Dispose();
                    notSatisfiedTimer = null;
                }
                if (waitRequestTimer != null)
                {
                    waitRequestTimer.Stop();
                    waitRequestTimer.Dispose();
                    waitRequestTimer = null;
                }
                if (processTimer != null)
                {
                    processTimer.Stop();
                    processTimer.Dispose();
                    processTimer = null;
                }
            }

            private void OnNotSatisfiedTimedEvent(Object source, ElapsedEventArgs e)
            {
                cborKeepAliveTimeElapsed += TIMER_FIDO_MSG_NOT_SATISFIED;
                Console.WriteLine("{0:MM/dd/yyyy hh:mm:ss.fff} U2FHID_MSG [TIMEOUT]-> NOT SATISFIED, cid=0x{1:X8}, {2:D}", e.SignalTime, cid, cborKeepAliveTimeElapsed);

                if (sendNotSatisfied)
                {
                    byte[] notSatisfied = new byte[2] { 0x69, 0x85 };
                    fidoModule.txDone.WaitOne();
                    fidoModule.sendHidResponse(cid, CTAPHID_MSG, notSatisfied, notSatisfied.Length);
                }
            }

            private void OnCborNotSatisfiedTimedEvent(Object source, ElapsedEventArgs e)
            {
                cborKeepAliveTimeElapsed += TIMER_FIDO_CBOR_KEEP_ALIVE;
                if (cborKeepAliveTimeElapsed > (TIMER_FIDO_CHANNEL_PROCESS+ TIMER_FIDO_CBOR_KEEP_ALIVE))
                {
                    notSatisfiedTimer.Stop();
                    notSatisfiedTimer.Elapsed -= OnCborNotSatisfiedTimedEvent;
                    notSatisfiedTimer.Dispose();
                    notSatisfiedTimer = null;

                    if (rxCmd == CTAPHID_MSG)
                        Console.Write("{0:MM/dd/yyyy hh:mm:ss.fff} CTAPHID_MSG [CBOR_KEEP_ALIVE TIMEOUT]-> PROCESS ABORTED, ", e.SignalTime);
                    else
                        Console.Write("{0:MM/dd/yyyy hh:mm:ss.fff} CTAPHID_CBOR [CBOR_KEEP_ALIVE TIMEOUT]-> PROCESS ABORTED, ", e.SignalTime);
                    //fidoModule.sendHidError(cid, ERR_MSG_TIMEOUT); // ????
                    fidoModule.streamModule.Send(fidoModule.moduleFunction, CTAPHID_CANCEL, cid, null, 0);
                    fidoModule.removeFidoRequest(cid);
                }
                else
                {
                    byte[] notSatisfied = new byte[1] { 0x02 };
                    fidoModule.txDone.WaitOne();

                    Console.WriteLine("{0:MM/dd/yyyy hh:mm:ss.fff} U2FHID_CBOR [TIMEOUT]-> NOT SATISFIED, cid=0x{1:X8}", e.SignalTime, cid);
                    fidoModule.sendHidResponse(cid, CTAPHID_KEEPALIVE, notSatisfied, notSatisfied.Length);
                }
            }

            private void OnWaitRequestTimedEvent(Object source, ElapsedEventArgs e)
            {
                Console.Write("{0:MM/dd/yyyy hh:mm:ss.fff} CTAPHID_MSG/CTAP_CBOR [TIMEOUT]-> LOCK ABORTED, ", e.SignalTime);
                fidoModule.removeFidoRequest(cid);
            }

            private void OnProcessTimedEvent(Object source, ElapsedEventArgs e)
            {
                if (rxCmd == CTAPHID_MSG)
                    Console.Write("{0:MM/dd/yyyy hh:mm:ss.fff} CTAPHID_MSG [TIMEOUT]-> PROCESS ABORTED, ", e.SignalTime);
                else
                    Console.Write("{0:MM/dd/yyyy hh:mm:ss.fff} CTAPHID_CBOR [TIMEOUT]-> PROCESS ABORTED, ", e.SignalTime);
                //fidoModule.sendHidError(cid, ERR_MSG_TIMEOUT); // ????
                fidoModule.streamModule.Send(fidoModule.moduleFunction, CTAPHID_CANCEL, cid, null, 0);
                fidoModule.removeFidoRequest(cid);
            }
        }

        public FidoHidModule()
        {
            moduleType = GTID_TYPE_COMPONENT;
            moduleFunction = GTID_COMPONENT_FIDO;
            Config(25);
        }

        override
        public Task Run()
        {
            Console.WriteLine(getTimeStamp() + "Start FidoHidModule...");
            try
            {
                moduleTask = Task.Factory.StartNew(() => Start(), cts.Token);
                ready = true;
            }
            catch (TaskCanceledException)
            {
                Cancel();
                ready = false;
            }
            return moduleTask;
        }

        private void Config(int requestMax)
        {
            Console.WriteLine(getTimeStamp() + "Configure FidoHidModule ('U2F_V2', {0:D})...", requestMax);
            FidoVersion = new byte[6] { (byte)'U', (byte)'2', (byte)'F', (byte)'_', (byte)'V', (byte)'2' };
            RequestMaxCount = requestMax;
        }

        override
        public void Configure(List<KeyValuePair<string, Object>> kvlist)
        {
            string fidoVer = null;
            int maxReq = 0;
            foreach (KeyValuePair<string, Object>  kvp in kvlist)
            {
                if (kvp.Key == "FidoVersion")
                {
                    fidoVer = (string)kvp.Value;
                }
                if (kvp.Key == "MaxRequest")
                {
                    maxReq = (int)kvp.Value;
                }
            }
            if ((fidoVer != null) && (maxReq != 0))
            {
                //Config(fidoVer, maxReq);
                Config(maxReq);
            }
        }

        override
        public void setStreamModule(GTID_Module module)
        {
            streamModule = module;
        }

        override
        public void Stop()
        {
            //Console.WriteLine(getTimeStamp()+"Stop FidoHidModule...");
            Cancel();
            Console.WriteLine(getTimeStamp()+"Exit FidoHidModule...");
            cts.Cancel();

        }

        override
        public int Send(byte function, byte cmd, uint cid, byte[] packet, int len)
        {
            if (sendBridgeResponse(cid, cmd, packet, len) == true)
                return len;
            return -1;
        }

        public void Cancel()
        {
            //Console.WriteLine(getTimeStamp()+"Cancel FidoHidModule...");
            foreach (FidoRequest req in fidoRequestList)
            {
                req.Cancel();
            }
            Dispose();
        }

        public void Dispose()
        {
            Console.WriteLine(getTimeStamp() + "Exit FidoHidModule...");
            GC.SuppressFinalize(this);
        }

        public void Start()
        {
            Console.WriteLine(getTimeStamp() + "Start FidoHidModule...");
            if (FindHidFidoDevices())
            {
                Console.WriteLine(getTimeStamp() + "Found FIDO HID Device...");
                hidProcessMessage();
            }
            else
            {
                Console.WriteLine(getTimeStamp() + "FIDO HID Device NOT Found...Sleep 5 seconds");
                Thread.Sleep(50000);
            }
            if ((ReadHandle != null) && (!ReadHandle.IsInvalid)) ReadHandle.Close();
            if ((WriteHandle != null) && (!WriteHandle.IsInvalid)) WriteHandle.Close();

            streamModule.Stop();
            Cancel();
        }

        public bool FindHidDevices(ref string[] listOfDevicePathNames, ref int numberOfDevicesFound)
        {
            Debug.WriteLine("usbGenericHidCommunication:findHidDevices() -> Method called");

            // Initialise the internal variables required for performing the search
            var bufferSize = 0;
            var detailDataBuffer = IntPtr.Zero;
            bool deviceFound;
            var deviceInfoSet = new IntPtr();
            var lastDevice = false;
            int listIndex;
            var deviceInterfaceData = new SpDeviceInterfaceData();

            // Get the required GUID
            var systemHidGuid = new Guid();
            Hid.HidD_GetHidGuid(ref systemHidGuid);
            Debug.WriteLine("usbGenericHidCommunication:findHidDevices() -> Fetched GUID for HID devices ("
                + systemHidGuid.ToString() + ")");

            try
            {
                // Here we populate a list of plugged-in devices matching our class GUID (DIGCF_PRESENT specifies that the list
                // should only contain devices which are plugged in)
                Debug.WriteLine("usbGenericHidCommunication:findHidDevices() -> Using SetupDiGetClassDevs to get all devices with the correct GUID");
                deviceInfoSet = SetupApi.SetupDiGetClassDevs(ref systemHidGuid, IntPtr.Zero, IntPtr.Zero, DigcfPresent | DigcfDeviceinterface);

                // Reset the deviceFound flag and the memberIndex counter
                deviceFound = false;
                listIndex = 0;

                deviceInterfaceData.cbSize = Marshal.SizeOf(deviceInterfaceData);

                // Look through the retrieved list of class GUIDs looking for a match on our interface GUID
                do
                {
                    //Debug.WriteLine("usbGenericHidCommunication:findHidDevices() -> Enumerating devices");
                    var success = SetupApi.SetupDiEnumDeviceInterfaces(deviceInfoSet, IntPtr.Zero, ref systemHidGuid, listIndex, ref deviceInterfaceData);

                    if (!success)
                    {
                        //Debug.WriteLine("usbGenericHidCommunication:findHidDevices() -> No more devices left - giving up");
                        lastDevice = true;
                    }
                    else
                    {
                        // The target device has been found, now we need to retrieve the device path so we can open
                        // the read and write handles required for USB communication

                        // First call is just to get the required buffer size for the real request
                        SetupApi.SetupDiGetDeviceInterfaceDetail
                            (deviceInfoSet,
                             ref deviceInterfaceData,
                             IntPtr.Zero,
                             0,
                             ref bufferSize,
                             IntPtr.Zero);

                        // Allocate some memory for the buffer
                        detailDataBuffer = Marshal.AllocHGlobal(bufferSize);
                        Marshal.WriteInt32(detailDataBuffer, (IntPtr.Size == 4) ? (4 + Marshal.SystemDefaultCharSize) : 8);

                        // Second call gets the detailed data buffer
                        //Debug.WriteLine("usbGenericHidCommunication:findHidDevices() -> Getting details of the device");
                        SetupApi.SetupDiGetDeviceInterfaceDetail
                            (deviceInfoSet,
                             ref deviceInterfaceData,
                             detailDataBuffer,
                             bufferSize,
                             ref bufferSize,
                             IntPtr.Zero);

                        // Skip over cbsize (4 bytes) to get the address of the devicePathName.
                        var pDevicePathName = new IntPtr(detailDataBuffer.ToInt32() + 4);

                        // Get the String containing the devicePathName.
                        listOfDevicePathNames[listIndex] = Marshal.PtrToStringUni(pDevicePathName);

                        //Debug.WriteLine(string.Format("usbGenericHidCommunication:findHidDevices() -> Found matching device (memberIndex {0:D})", memberIndex));
                        deviceFound = true;
                    }
                    listIndex = listIndex + 1;
                }
                while (lastDevice != true);
            }
            catch (Exception)
            {
                // Something went badly wrong... output some debug and return false to indicated device discovery failure
                Debug.WriteLine("usbGenericHidCommunication:findHidDevices() -> EXCEPTION: Something went south whilst trying to get devices with matching GUIDs - giving up!");
                return false;
            }
            finally
            {
                // Clean up the unmanaged memory allocations
                if (detailDataBuffer != IntPtr.Zero)
                {
                    // Free the memory allocated previously by AllocHGlobal.
                    Marshal.FreeHGlobal(detailDataBuffer);
                }

                if (deviceInfoSet != IntPtr.Zero)
                {
                    SetupApi.SetupDiDestroyDeviceInfoList(deviceInfoSet);
                }
            }

            if (deviceFound)
            {
                Debug.WriteLine("usbGenericHidCommunication:findHidDevices() -> Found {0:D} devices with matching GUID", (listIndex - 1));
                numberOfDevicesFound = listIndex - 2;
            }
            else Debug.WriteLine("usbGenericHidCommunication:findHidDevices() -> No matching devices found");

            return deviceFound;
        }

        public bool FindHidFidoDevices()
        {
            Debug.WriteLine("usbGenericHidCommunication:findTargetDevice() -> Method called");

            var listOfDevicePathNames = new String[128]; // 128 is the maximum number of USB devices allowed on a single host
            var numberOfDevicesFound = 0;

            try
            {
                // Reset the device detection flag
                var isDeviceDetected = false;
                deviceInformation.IsDeviceAttached = false;

                // Get all the devices with the correct HID GUID
                var deviceFoundByGuid = FindHidDevices(ref listOfDevicePathNames, ref numberOfDevicesFound);

                if (deviceFoundByGuid)
                {
                    Debug.WriteLine("usbGenericHidCommunication:findTargetDevice() -> Devices with matching GUID found...");
                    var listIndex = 0;

                    do
                    {
                        Debug.WriteLine("usbGenericHidCommunication:findTargetDevice() -> Performing CreateFile to listIndex {0:D}", listIndex);
                        Debug.WriteLine("usbGenericHidCommunication:findTargetDevice() -> DevicePathNames=" + listOfDevicePathNames[listIndex]);
                        ReadHandle = Kernel32.CreateFile(listOfDevicePathNames[listIndex], 0, FileShareRead | FileShareWrite, IntPtr.Zero, OpenExisting, 0, 0);

                        if (!ReadHandle.IsInvalid)
                        {
                            deviceInformation.Attributes.Size = Marshal.SizeOf(deviceInformation.Attributes);
                            var success = Hid.HidD_GetAttributes(ReadHandle, ref deviceInformation.Attributes);

                            if (success)
                            {
                                Debug.WriteLine(string.Format("usbGenericHidCommunication:findTargetDevice() -> Found device with VID 0x{0:X}, PID 0x{1:X} and Version number 0x{2:X}",
                                    deviceInformation.Attributes.VendorID,
                                    deviceInformation.Attributes.ProductID,
                                    deviceInformation.Attributes.VersionNumber));

                                //  Do the VID and PID of the device match our target device?
                                if ((deviceInformation.Attributes.VendorID == FidoVendorId) &&
                                    (deviceInformation.Attributes.ProductID == FidoProductId))
                                {
                                    // Matching device found
                                    Debug.WriteLine("usbGenericHidCommunication:findTargetDevice() -> Device with matching VID and PID found!");
                                    if (isDeviceDetected = checkIfFidoDevice(ref deviceInformation, FidoUsageId, FidoUsagePage))
                                    {
                                        // Store the device's pathname in the device information
                                        deviceInformation.DevicePathName = listOfDevicePathNames[listIndex];
                                    }
                                    else
                                    {
                                        ReadHandle.Close();
                                    }

                                }
                                else
                                {
                                    // Wrong device, close the handle
                                    Debug.WriteLine("usbGenericHidCommunication:findTargetDevice() -> Device didn't match... Continuing...");
                                    ReadHandle.Close();
                                }
                            }
                            else
                            {
                                //  Something went rapidly south...  give up!
                                Debug.WriteLine("usbGenericHidCommunication:findTargetDevice() -> Something bad happened - couldn't fill the HIDD_ATTRIBUTES, giving up!");
                                //ReadHandle.Close();
                            }
                        }

                        //  Move to the next device, or quit if there are no more devices to examine
                        listIndex++;
                    }
                    while (!((isDeviceDetected || (listIndex == numberOfDevicesFound + 1))));
                }

                // If we found a matching device then we need discover more details about the attached device
                // and then open read and write handles to the device to allow communication
                if (isDeviceDetected)
                {
                    Debug.WriteLine("usbGenericHidCommunication:findTargetDevice() -> Opening a writeHandle to the device");
                    WriteHandle = Kernel32.CreateFile(
                        deviceInformation.DevicePathName,
                        GenericWrite,
                        FileShareRead | FileShareWrite,
                        IntPtr.Zero,
                        OpenExisting, 0, 0);

                    // Did we open the writeHandle successfully?
                    if (WriteHandle.IsInvalid)
                    {
                        Debug.WriteLine("usbGenericHidCommunication:findTargetDevice() -> Unable to open a writeHandle to the device!");

                        // Attempt to close the ReadHandle
                        ReadHandle.Close();
                        return false;
                    }

                    // Device is now discovered and ready for use, update the status
                    deviceInformation.IsDeviceAttached = true;
                    return true;
                }

                //  The device wasn't detected.
                Debug.WriteLine("usbGenericHidCommunication:findTargetDevice() -> No matching device found!");
                return false;
            }
            catch (Exception)
            {
                Debug.WriteLine("usbGenericHidCommunication:findTargetDevice() -> EXCEPTION: Unknown - device not found");
                return false;
            }
        }

        public bool checkIfFidoDevice(ref DeviceInformationStructure deviceInformation, ushort usage, ushort usagePage)
        {
            var preparsedData = new IntPtr();

            try
            {
                // Get the preparsed data from the HID driver
                Hid.HidD_GetPreparsedData(ReadHandle, ref preparsedData);

                // Get the HID device's capabilities
                var result = Hid.HidP_GetCaps(preparsedData, ref deviceInformation.Capabilities);
                if ((result == 0)) return false;

                if (!(deviceInformation.Capabilities.Usage == usage
                    && deviceInformation.Capabilities.UsagePage == usagePage))
                    return false;

            }
            catch (Exception)
            {
                // Something went badly wrong... this shouldn't happen, so we throw an exception
                Debug.WriteLine("usbGenericHidCommunication:queryDeviceCapabilities() -> EXECEPTION: An unrecoverable error has occurred!");
                //throw;
                return false;
            }
            finally
            {
                // Free up the memory before finishing
                if (preparsedData != IntPtr.Zero)
                {
                    Hid.HidD_FreePreparsedData(preparsedData);
                }
            }
            return true;
        }

        public byte decodeInputReport(byte[] hidBuf, ref uint tmpCid, ref byte tmpCmd)
        {
            // get channel id
            byte[] chid = new byte[4];
            chid[0] = hidBuf[APDU_CID_OFFSET];
            chid[1] = hidBuf[APDU_CID_OFFSET + 1];
            chid[2] = hidBuf[APDU_CID_OFFSET + 2];
            chid[3] = hidBuf[APDU_CID_OFFSET + 3];

            tmpCmd = hidBuf[APDU_INIT_CMD_OFFSET];
            tmpCid = BitConverter.ToUInt32(chid, 0);
            Console.Write("cid=0x{0:X8}, ", tmpCid);

            if (tmpCid == 0)
            {
                Console.WriteLine("ERR_INVALID_CID [cid cannot be 0]");
                return CTAP1_ERR_INVALID_CID;
            }
            
            // get possible app len [if INIT frame]
            int tmpAppLen = (int)(hidBuf[APDU_INIT_BCNTH_OFFSET] << 8 | hidBuf[APDU_INIT_BCNTL_OFFSET]);

            if (tmpCid == CID_BROADCAST)  // Only CTAPHID_INIT and [CTAPHID_VENDOR_PING, CTAPHID_VENDOR_EXIT] is allowed
            {
                switch (tmpCmd)
                {
                    case CTAPHID_INIT:
                        if (tmpAppLen != 8)
                        {
                            Console.WriteLine("[CTAPHID_INIT] ERR_INVALID_LEN - {0:D}", tmpAppLen);
                            return CTAP1_ERR_INVALID_LEN;
                        }
                        // Check RequestMaxCount
                        if (RequestMaxCount <= fidoRequestList.Count)
                        {
                            Console.WriteLine("CTAPHID_INIT -> FIDO max request count reached [ERR_CHANNEL_BUSY] [{0:D}/{1:D}]", fidoRequestList.Count, RequestMaxCount);
                            return CTAP1_ERR_CHANNEL_BUSY;
                        }

                        uint cid = ++mChanIdPool;
                        curFidoReq = new FidoRequest(cid, this);
                        fidoRequestList.Add(curFidoReq);

                        curFidoReq.rxCmd = tmpCmd;
                        curFidoReq.rxAppLen = tmpAppLen;
                        curFidoReq.rxDataOffset = 8; // set to INIT Frame size // cid + cmd + bcnh + bcnl
                        curFidoReq.rxDataLen = HID_RPT_SIZE - curFidoReq.rxDataOffset + 1;
                        Console.Write("Cmd=0x{0:X2}, ", curFidoReq.rxCmd);
                        return CTAP1_ERR_NONE;
/***
                    case CTAPHID_PING:
                        if (tmpAppLen == 1)  // Stupid Microsoft
                        {
                            curFidoReq = new FidoRequest(tmpCid, this);
                            fidoRequestList.Add(curFidoReq);
                        }
                        else
                        {
                            Console.WriteLine("Cmd=0x{0:X2}, ERR_INVALID_CID - CID_BROADCAST can only be used for CTAPHID_INIT", tmpCmd);
                            return CTAP1_ERR_INVALID_CID;
                        }
                        break;
**/
                    // Vendor Specific
                    case CTAPHID_VENDOR_PING:
                        Console.WriteLine("CTAPHID_VENDOR_PING [{0:D}/{1:D}]", fidoRequestList.Count, RequestMaxCount);
                        return CTAP1_ERR_IGNORE;

                    case CTAPHID_VENDOR_EXIT:
                        Console.WriteLine("CTAPHID_VENDOR_EXIT");
                        return CTAP1_ERR_IGNORE;

                    default:
                        Console.WriteLine("Cmd=0x{0:X2}, ERR_INVALID_CID - CID_BROADCAST can only be used for CTAPHID_INIT", tmpCmd);
                        return CTAP1_ERR_INVALID_CID;
                }
            }

            // Channel ID is not CID_BROADCAST, then MUST be a request pending [CTAPHID_INIT previously received]
            if (fidoRequestList.Count > 0)
            {
                curFidoReq = findFidoRequest(tmpCid);
                if (curFidoReq == null)
                {
                    Console.WriteLine("ERR_INVALID_CID [Not in Req List]");
                    // For conformance test, IGNORE this error
                    // return ERR_INVALID_CID;
                    return CTAP1_ERR_IGNORE;
                }
            }
            else
            {
                Console.WriteLine("ERR_INVALID_CID [No CTAPHID_INIT previously received]");
                // For conformance test, IGNORE this error
                // return ERR_INVALID_CID;
                return CTAP1_ERR_IGNORE;
            }

            // Make sure curFidoReq is NOT null
            if (curFidoReq == null)
            {
                Console.WriteLine("ERR_OTHER [No current FIDO request - INTERNAL ERROR]");
                return CTAP1_ERR_OTHER;
            }

            // For Comformance Test, receive CTAPHID_INIT before complete message
            if (tmpCmd == CTAPHID_INIT)
            {
                if (tmpAppLen != 8)
                {
                    Console.WriteLine("[CTAPHID_INIT] ERR_INVALID_LEN - {0:D}", tmpAppLen);
                    return CTAP1_ERR_INVALID_LEN;
                }

                curFidoReq.rxReset();
                curFidoReq.rxCmd = tmpCmd;
                curFidoReq.rxAppLen = tmpAppLen;
                curFidoReq.rxDataOffset = 8; // set to INIT Frame size // cid + cmd + bcnh + bcnl
                curFidoReq.rxDataLen = HID_RPT_SIZE - curFidoReq.rxDataOffset + 1;
                Console.Write("Cmd=0x{0:X2}, ", curFidoReq.rxCmd);
                return CTAP1_ERR_NONE;
            }

            // a regular frame
            if (curFidoReq.rxSeqNo < 0) // Initial Frame
            {

                Console.Write("[INIT_FRAME] Cmd=0x{0:X2}, ", tmpCmd);

                // Check valid command first
                switch (tmpCmd)
                {
                    // Manadatory and Supported
                    case CTAPHID_INIT:   // only 1 frame
                    case CTAPHID_MSG:    // 1 or more frames
                    case CTAPHID_PING:   // 1 or more frames
                        break;

                    // Manadatory but NOT supported - for FIDO2
                    case CTAPHID_CANCEL:
                        if ((fidoCapability & FIDO_CAPABILITY_CBOR) == FIDO_CAPABILITY_CBOR)
                        {
                            //Console.Write("ERR_INVALID_CMD [CTAPHID_CANCEL FAKE supported], ");
                        }
                        else
                        {
                            Console.WriteLine("ERR_INVALID_CMD [CTAPHID_CANCEL not supported]");
                            return CTAP1_ERR_INVALID_CMD;
                        }
                        break;

                    case CTAPHID_CBOR:
                        if ((fidoCapability & FIDO_CAPABILITY_CBOR) == FIDO_CAPABILITY_CBOR)
                        {
                            //Console.Write("ERR_INVALID_CMD [CTAPHID_CBOR FAKE supported], ");
                        }
                        else
                        {
                            Console.Write("ERR_INVALID_CMD [CTAPHID_CBOR NOT supported]");
                            //Thread.Sleep(CBOR_DELAY);
                            return CTAP1_ERR_INVALID_CMD;
                        }
                        break;

                    // Optional
                    case CTAPHID_WINK:  // Wink is supported
                        break;
                    case CTAPHID_LOCK:
                        Console.WriteLine("ERR_INVALID_CMD [CTAPFHID_LOCK not supported]");
                        return CTAP1_ERR_INVALID_CMD;

                    // Default
                    default:
                        Console.WriteLine("ERR_INVALID_CMD [Unsupported Command]", tmpCmd);
                        return CTAP1_ERR_INVALID_CMD;
                }

                if ((tmpAppLen + tmpAppLen % HID_RPT_SIZE) > TXRX_PACKET_SIZE)
                {
                    curFidoReq.rxReset();
                    Console.WriteLine("ERR_INVALID_LEN {0:D}", tmpAppLen);
                    return CTAP1_ERR_INVALID_LEN;
                }

                curFidoReq.rxCmd = tmpCmd;
                curFidoReq.rxAppLen = tmpAppLen;
                curFidoReq.rxDataOffset = 8; // set to INIT Frame size // cid + cmd + bcnh + bcnl
            }
            else // Continuous Frame
            {
                // Chech Sequence Number
                if (hidBuf[APDU_CONT_SEQNO_OFFSET] != curFidoReq.rxSeqNo)
                { 
                    Console.WriteLine("[CONT_FRAME] InSeq={0:D}, ExpSeqNo={1:D} -> ERR_INVALID_SEQ", hidBuf[APDU_CONT_SEQNO_OFFSET], curFidoReq.rxSeqNo);
                    curFidoReq.rxReset();
                    return CTAP1_ERR_INVALID_SEQ;
                }
                Console.Write("[CONT_FRAME] Seq={0:D}, ", hidBuf[APDU_CONT_SEQNO_OFFSET]);
                curFidoReq.rxDataOffset = 6; // set to CONT Frame size // cid + seq
            }

            curFidoReq.rxDataLen = HID_RPT_SIZE - curFidoReq.rxDataOffset + 1;

            return CTAP1_ERR_NONE;
        }

        private void displayHexDump(byte[] buf)
        {
            Console.WriteLine("{0:X2} {1:X2} {2:X2} {3:X2} {4:X2} {5:X2} {6:X2} {7:X2} {8:X2} {9:X2} {10:X2} {11:X2} {12:X2} {13:X2} {14:X2} {15:X2} {16:X2} {17:X2} {18:X2} {19:X2} {20:X2} {21:X2} {22:X2} {23:X2} {24:X2} {25:X2} {26:X2} {27:X2} {28:X2} {29:X2} {30:X2} {31:X2} ",
                    buf[1], buf[2], buf[3], buf[4], buf[5], buf[6], buf[7], buf[8], 
                    buf[9], buf[10], buf[11], buf[12], buf[13], buf[14], buf[15], buf[16], 
                    buf[17], buf[18], buf[19], buf[20], buf[21], buf[22], buf[23], buf[24], 
                    buf[25], buf[26], buf[27], buf[28], buf[29], buf[30], buf[31], buf[32]);

            Console.WriteLine(getTimeStamp() + "             {0:X2} {1:X2} {2:X2} {3:X2} {4:X2} {5:X2} {6:X2} {7:X2} {8:X2} {9:X2} {10:X2} {11:X2} {12:X2} {13:X2} {14:X2} {15:X2} {16:X2} {17:X2} {18:X2} {19:X2} {20:X2} {21:X2} {22:X2} {23:X2} {24:X2} {25:X2} {26:X2} {27:X2} {28:X2} {29:X2} {30:X2} {31:X2} ",
                    buf[33], buf[34], buf[35], buf[36], buf[37], buf[38], buf[39], buf[40], 
                    buf[41], buf[42], buf[43], buf[44], buf[45], buf[46], buf[47], buf[48], 
                    buf[49], buf[50], buf[51], buf[52], buf[53], buf[54], buf[55], buf[56], 
                    buf[57], buf[58], buf[59], buf[60], buf[61], buf[62], buf[63], buf[64]);
        }

        public void hidProcessMessage()
        {
            bool bContinue = true;
            bool bHidSuccess = true;
            uint tmpCid = 0;
            byte tmpCmd = 0;

            while (bContinue)  // Process next HID message
            {
                do // Read ONE HID message loop
                {
                    bHidSuccess = Hid.HidD_GetInputReport(ReadHandle, hidBuf, hidBufLen);
                    if (bHidSuccess)
                    {
                        Console.Write(getTimeStamp() + "InputReport: ");
                        displayHexDump(hidBuf);
                        Console.Write(getTimeStamp() + "===========> ");
                        tmpCid = 0;
                        byte errCode = decodeInputReport(hidBuf, ref tmpCid, ref tmpCmd);
                        if (errCode != CTAP1_ERR_NONE)
                        {
                            if (errCode != CTAP1_ERR_IGNORE)
                            {
                                sendHidError(tmpCid, errCode);
                            }
                            else
                            {
                                switch (tmpCmd)
                                {
                                    case CTAPHID_VENDOR_PING: // Ping
                                        break;
                                    case CTAPHID_VENDOR_EXIT: // Exit
                                        Console.WriteLine(getTimeStamp() + "CTAPHID_VENDOR_EXIT");
                                        bContinue = false;
                                        break;
                                    default:
                                        // IGNORE intentionally
                                        break;
                                }
                            }

                            bHidSuccess = false;
                            break; // from Do loop
                        }

                        if ((curFidoReq.rxAppLen - curFidoReq.rxAppDataRecv) < curFidoReq.rxDataLen)
                            curFidoReq.rxDataLen = curFidoReq.rxAppLen - curFidoReq.rxAppDataRecv;
                        System.Buffer.BlockCopy(hidBuf, (int)curFidoReq.rxDataOffset, rData, (int)curFidoReq.rxAppDataRecv, (int)curFidoReq.rxDataLen); // data
                        curFidoReq.rxAppDataRecv += curFidoReq.rxDataLen;
                        Console.WriteLine("rxAppDataRecv={0:D}", curFidoReq.rxAppDataRecv);
                        curFidoReq.rxSeqNo++;
                    }
                    else
                    {
                        Console.Write(getTimeStamp() + "InputReport: FAILED...");
                        bContinue = false;
                        break;
                    }
                } while (curFidoReq.rxAppLen > curFidoReq.rxAppDataRecv);

                if (bHidSuccess) // Handle this HID Message
                {
                    curFidoReq.cancelWaitRequestTimer();
                    switch (curFidoReq.rxCmd)
                    {
                        case CTAPHID_INIT:
                            if (tmpCid == CID_BROADCAST)
                            {
                                Console.WriteLine(getTimeStamp() + "CTAPHID_INIT -> FIDO request added [cid=0x{0:X8}] [{1:D}/{2:D}]", curFidoReq.cid, fidoRequestList.Count, RequestMaxCount);
                                sendHidInitToGtid(tmpCid);
                            }
                            else
                            {
                                Console.WriteLine(getTimeStamp() + "CTAPHID_INIT -> RE-SYNC", tmpCid);
                                //removeFidoRequest(tmpCid);
                                sendHidInitResync(curFidoReq.cid, rData, curFidoReq.rxAppLen);
                                curFidoReq.startWaitRequestTimer();
                            }
                            break;

                        case CTAPHID_MSG:
                            if (curFidoReq.notSatisfiedTimer == null)
                            {
                                // In case Client to resend the request with another Channel id, need to cancel the
                                // pending request first
                                FidoRequest pendingReq = findPendingFidoRequest(tmpCid);
                                if (pendingReq != null)
                                {
                                    pendingReq.notSatisfiedTimer.Stop();
                                    pendingReq.notSatisfiedTimer.Dispose();
                                    pendingReq.notSatisfiedTimer = null;

                                    Console.Write(getTimeStamp() + "CTAPHID_MSG [NEW:{0}|OLD:{1}]-> PENDING PROCESS ABORTED, ", tmpCid, pendingReq.cid);
                                    streamModule.Send(moduleFunction, CTAPHID_CANCEL, pendingReq.cid, null, 0);
                                    removeFidoRequest(pendingReq.cid);
                                }

                                sendHidMsgToGtid(tmpCid, rData, curFidoReq.rxAppLen, null, null);
                            }
                            else
                            {
                                if (curFidoReq.responseQueued != null)
                                {
                                    if (removeFidoRequest(tmpCid) == true)
                                        sendHidResponse(tmpCid, CTAPHID_MSG, curFidoReq.responseQueued, curFidoReq.responseQueued.Length);
                                }
                                else
                                {
                                    Console.WriteLine(getTimeStamp() + "CTAPHID_MSG -> REQUEST PENDING cid [{0:X8}]!", tmpCid);
                                }
                            }
                            break;

                        case CTAPHID_PING:
                            if (curFidoReq.cid == CID_BROADCAST)  // Stupid Microsoft
                            {
                                removeFidoRequest(tmpCid);
                                Console.WriteLine(getTimeStamp() + "CTAPHID_PING ({0:D}) [{1:D}/{2:D}]", curFidoReq.rxAppLen, fidoRequestList.Count, RequestMaxCount);
                                sendHidResponse(curFidoReq.cid, CTAPHID_PING, rData, curFidoReq.rxAppLen);
                            }
                            else
                            {
                                txDone.WaitOne();
                                Console.WriteLine(getTimeStamp() + "CTAPHID_PING ({0:D})", curFidoReq.rxAppLen);
                                sendHidResponse(curFidoReq.cid, CTAPHID_PING, rData, curFidoReq.rxAppLen);
                                curFidoReq.startWaitRequestTimer();
                            }
                            break;

                        case CTAPHID_WINK:
                            txDone.WaitOne();
                            Console.WriteLine(getTimeStamp() + "CTAPHID_WINK ({0:D})", curFidoReq.rxAppLen);
                            sendHidResponse(curFidoReq.cid, CTAPHID_WINK, rData, curFidoReq.rxAppLen);
                            curFidoReq.startWaitRequestTimer();
                            break;

                        case CTAPHID_CANCEL:
                            Console.Write(getTimeStamp() + "CTAPHID_CANCEL ({0:D}), ", curFidoReq.rxAppLen);
                            if (curFidoReq.notSatisfiedTimer != null)
                            {
                                streamModule.Send(moduleFunction, CTAPHID_CANCEL, curFidoReq.cid, null, 0);
                                //removeFidoRequest(curFidoReq.cid);
                                sendHidCborError(curFidoReq.cid, CTAP2_ERR_KEEPALIVE_CANCEL);
                            }
                            else
                            {
                                removeFidoRequest(curFidoReq.cid);
                            }
                            break;

                        case CTAPHID_CBOR:
                            if (curFidoReq.notSatisfiedTimer == null)
                            {
                                sendHidCborToGtid(tmpCid, rData, curFidoReq.rxAppLen);
                            }
                            else
                            {
                                Console.WriteLine(getTimeStamp() + "CTAPHID_CBOR -> REQUEST PENDING cid [{0:X8}]!", tmpCid);
                            }
                            break;

                        default:
                            Console.WriteLine(getTimeStamp() + "UNKNOWN U2FHID COMMAND - 0x{0:X2}", curFidoReq.rxCmd);
                            bHidSuccess = sendHidError(tmpCid, CTAP1_ERR_INVALID_CMD);
                            break;
                    }
                    curFidoReq.rxReset();
                }
            }
        }

        public bool sendHidError(uint cid, byte err)
        {
            byte[] errCode = new byte[1] { err };

            sendHidResponse(cid, CTAPHID_ERROR, errCode, 1);
            return false;
        }

        public bool sendHidCborError(uint cid, byte err)
        {
            byte[] errCode = new byte[1] { err };
            removeFidoRequest(cid);
            sendHidResponse(cid, CTAPHID_CBOR, errCode, 1);
            return false;
        }

        public bool sendBridgeResponse(uint cid, byte cmd, byte[] respData, int respLen)
        {
            Console.Write(getTimeStamp() + "BRIDGE_FIDO_RESPPONSE ({0:D}-> ", cid);
            FidoRequest fidoRequest = findFidoRequest(cid);
            if (fidoRequest == null)
                return false;

            if (fidoRequest.rxCmd == CTAPHID_CBOR)
            {
                return sendCborResponse(cid, respData, respLen);
            }
            else  // CTAPHID_MSG
            {

#if false
                txDone.WaitOne();
                if (((respData[0] == 0x69) && (respData[1] == 0x85))
                   || ((respData[0] == 0x6A) && (respData[1] == 0x80)))
                {  // Check-Only response
                    FidoRequest req = findFidoRequest(cid);
                    if (req != null)
                    {
                        if (req.notSatisfiedTimer != null)
                        {
                            req.notSatisfiedTimer.Stop();
                            req.notSatisfiedTimer.Dispose();
                            req.notSatisfiedTimer = null;
                        }
                        req.startWaitRequestTimer();
                        return sendHidResponse(cid, CTAPHID_MSG, respData, respLen);
                    }
                    else
                        return false;
                }
                else
                {
                    if (removeFidoRequest(cid) == true)
                        return sendHidResponse(cid, CTAPHID_MSG, respData, respLen);
                    else
                        return false;
                }
#else
                FidoRequest req = findFidoRequest(cid);
                if (req == null)
                    return false;

                if (((respData[0] == 0x69) && (respData[1] == 0x85))
                   || ((respData[0] == 0x6A) && (respData[1] == 0x80)))
                {  // Check-Only response
                    if (req.notSatisfiedTimer != null)
                    {
                        req.notSatisfiedTimer.Stop();
                        req.notSatisfiedTimer.Dispose();
                        req.notSatisfiedTimer = null;
                    }
                    req.startWaitRequestTimer();
                    txDone.WaitOne();
                    return sendHidResponse(cid, CTAPHID_MSG, respData, respLen);
                }
                else
                {
                    req.responseQueued = new byte[respLen];
                    Array.Copy(respData, req.responseQueued, respLen);
                    return true;
                }
#endif
            }
        }

        public bool sendCborResponse(uint cid, byte[] respData, int respLen)
        {
            txDone.WaitOne();
            if (removeFidoRequest(cid) == true)
                return sendHidResponse(cid, CTAPHID_CBOR, respData, respLen);
            else
                return false;
        }

        public bool sendHidResponse(uint cid, byte cmd, byte[] reqData, int reqLen)
        {
            txDone.Reset();  // LOCK

            //txChanId = cid;
            txCmd = cmd;
            txSeqNo = -1;  // starting from 0 or -1????
            txAppLen = reqLen;
            txAppDataSent = 0;

            bool bSuccess = false;
            do
            {
                Array.Clear(hidBuf, 0, hidBuf.Length);
                Console.Write(getTimeStamp() + "OutputReport:");
                encodeLayerSession(cid);
                encodeLayerTransEncap();
                encodeLayerTransFrame();

                if (reqLen > 0)
                {
                    if ((reqLen - txAppDataSent) < txDataLen)
                        txDataLen = reqLen - txAppDataSent;
                    System.Buffer.BlockCopy(reqData, txAppDataSent, hidBuf, txDataOffset, txDataLen); // data
                }
                txAppDataSent += txDataLen;

                try
                {
                    bSuccess = Hid.HidD_SetOutputReport(WriteHandle, hidBuf, hidBufLen);
                    if (bSuccess)
                    {
                        Console.WriteLine("txAppDataSent={0:D}", (int)txAppDataSent);
                        //displayHexDump(pTxHIDFrame);
                    }
                    else
                    {
                        Console.WriteLine("txAppDataSent={0:D} -> FAILED", (int)txAppDataSent);
                        break;
                    }
                    Console.Write(getTimeStamp() + "===========> ");
                    displayHexDump(hidBuf);

                    txSeqNo++;
                    Thread.Sleep(50);
                }
                catch (ObjectDisposedException e)
                {
                    Console.WriteLine("[ObjectDisposedException] ", e.Message);
                    break;
                }
            } while (reqLen > txAppDataSent);

            //TRACE("Finished WRITE, reqLen=%d\n", (int)reqLen);
            txSeqNo = -1;  // starting from 0 or -1???
            txDone.Set(); // UNLOCK
            return bSuccess;
        }

        bool encodeLayerSession(uint cid)
        {
            Console.Write("cid=0x{0:X8}, ", cid);
            byte[] cidBytes = BitConverter.GetBytes(cid);
            System.Buffer.BlockCopy(cidBytes, 0, hidBuf, 1, 4); // cid
            return true;
        }

        bool encodeLayerTransFrame()
        {
            hidBuf[0] = 0; // set Report ID to 0
            return true;
        }

        bool encodeLayerTransEncap()
        {
            if (txSeqNo < 0) // Initial Frame
            {
                txDataOffset = APDU_INIT_DATA_OFFSET; // cid + cmd + bcnth + bcntl
                hidBuf[APDU_INIT_CMD_OFFSET] = txCmd;
                hidBuf[APDU_INIT_BCNTH_OFFSET] = (byte)((txAppLen >> 8) & 0xff);
                hidBuf[APDU_INIT_BCNTL_OFFSET] = (byte)(txAppLen & 0xff);
                Console.Write("Cmd=0x{0:X2}, ", hidBuf[APDU_INIT_CMD_OFFSET]);
            }
            else // Continuous Frame
            {
                txDataOffset = APDU_CONT_DATA_OFFSET; // cid + seq
                hidBuf[APDU_CONT_SEQNO_OFFSET] = (byte)txSeqNo;
                Console.Write("seq={0:D}, ", hidBuf[APDU_CONT_SEQNO_OFFSET]);
            }
            txDataLen = HID_RPT_SIZE - txDataOffset + 1;
            return true;
        }

        public void sendHidInitResponse(uint cid, byte[] hidMsg, int hidMsgLen)
        {
            byte[] cidBytes = BitConverter.GetBytes(cid);
            byte[] initResp = new byte[17] { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                             0x00, 0x00, 0x00, 0x00, 0x02, 0x01, 0x01, 0x00, fidoCapability };

            System.Buffer.BlockCopy(hidMsg, 0, initResp, 0, 8); // nounce
            System.Buffer.BlockCopy(cidBytes, 0, initResp, 8, 4); // cid

            sendHidResponse(CID_BROADCAST, CTAPHID_INIT, initResp, initResp.Length);
        }

        public void sendHidInitResync(uint cid, byte[] hidMsg, int hidMsgLen)
        {
            byte[] cidBytes = BitConverter.GetBytes(cid);
            byte[] initResp = new byte[17] { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                             0x00, 0x00, 0x00, 0x00, 0x02, 0x01, 0x01, 0x00, fidoCapability };

            System.Buffer.BlockCopy(hidMsg, 0, initResp, 0, 8); // copy nounce, but set cid to 0
            System.Buffer.BlockCopy(cidBytes, 0, initResp, 8, 4); // cid

            sendHidResponse(cid, CTAPHID_INIT, initResp, initResp.Length);
        }

        private bool removeFidoRequest(uint cid)
        {
            FidoRequest reqFound = null;
            foreach (FidoRequest req in fidoRequestList)
            {
                if (req.cid == cid)
                {
                    reqFound = req;
                    reqFound.Cancel();
                    break;
                }
            }
            if (reqFound != null)
            {
                fidoRequestList.Remove(reqFound);
                reqFound = null;
                Console.WriteLine("request removed [cid=0x{0:X8}] [{1:D}/{2:D}]", cid, fidoRequestList.Count, RequestMaxCount);
                return true;
            }
            Console.WriteLine(getTimeStamp() + "request NOT FOUND [cid=0x{0:X8}]", cid);
            return false;
        }

        private FidoRequest findFidoRequest(uint cid)
        {
            foreach (FidoRequest req in fidoRequestList)
            {
                if (req.cid == cid)
                    return req;
            }
            return null;
        }

        private FidoRequest findPendingFidoRequest(uint cid)
        {
            foreach (FidoRequest req in fidoRequestList)
            {
                // Should check if it's the AppId and Client Data too later
                if ((req.notSatisfiedTimer != null) && (req.rxCmd == CTAPHID_MSG))
                {
                    if (req.cid != cid)
                        return req;
                }

            }
            return null;
        }

        /// <summary>
        /// 
        /// Modify this for the BT module, Cooper & Abnerl
        /// 
        /// </summary>
        /// 

        public void sendHidInitToGtid(uint rxCid)
        {
            if (streamModule.isReady() == false)
            {
                Console.Write(getTimeStamp() + "CTAPHID_INIT -> FIDO bridge not UP yet [ERR_CHANNEL_BUSY], ");
                removeFidoRequest(curFidoReq.cid);
                sendHidError(rxCid, CTAP1_ERR_CHANNEL_BUSY);
                return;
            }

            if (streamModule.Send(moduleFunction, CTAPHID_INIT, rxCid, null, 0) < 0)
            {
                Console.Write(getTimeStamp() + "CTAPHID_INIT -> Transport Module Send ERROR, ");
                removeFidoRequest(curFidoReq.cid);
                sendHidError(rxCid, CTAP1_ERR_CHANNEL_BUSY);
            }
            else
            {
                //Thread.Sleep(INIT_DELAY);
                sendHidInitResponse(curFidoReq.cid, rData, curFidoReq.rxAppLen);
                curFidoReq.startWaitRequestTimer();
            }
        }

        public void sendHidMsgToGtid(uint cid, byte[] hidMsg, int hidMsgLen, byte[] rpidHash, byte[] clientHash)
        {
            if (streamModule.isReady() == false)
            {
                Console.Write(getTimeStamp() + "CTAPHID_MSG -> FIDO bridge not UP yet [ERR_CHANNEL_BUSY], ");
                removeFidoRequest(cid);
                sendHidError(cid, CTAP1_ERR_CHANNEL_BUSY);
                return;
            }

            // Will be late to process in GTID FIDO module
            if ((hidMsg[0] == 0x00) && (hidMsg[1] == U2F_VERSION) && (handleHidInfo == true))
            {
                if (hidMsgLen != 7)
                {
                    byte[] invalidLength = new byte[2] { 0x67, 0x00 };
                    removeFidoRequest(cid);
                    sendHidResponse(cid, CTAPHID_MSG, invalidLength, invalidLength.Length);
                }
                else
                {
                    //byte[] verRsp = new byte[8] { (byte)'U', (byte)'2', (byte)'F', (byte)'_', (byte)'V', (byte)'2', 0x90, 0x00 };
                    byte[] verRsp = new byte[FidoVersion.Length + 2];
                    System.Buffer.BlockCopy(FidoVersion, 0, verRsp, 0, FidoVersion.Length);
                    verRsp[verRsp.Length - 2] = 0x90;
                    verRsp[verRsp.Length - 1] = 0x00;
                    sendHidResponse(cid, CTAPHID_MSG, verRsp, verRsp.Length);
                    curFidoReq.startWaitRequestTimer();
                }
            }
            else
            {
                if (streamModule.Send(moduleFunction, CTAPHID_MSG, cid, hidMsg, hidMsgLen) < 0)
                {
                    byte[] abortProcess = new byte[2] { 0x6f, 0x00 };
                    Console.Write(getTimeStamp() + "CTAPHID_MSG -> Transport Module Send ERROR, ");
                    removeFidoRequest(cid);
                    sendHidResponse(cid, CTAPHID_MSG, abortProcess, abortProcess.Length);
                }
                else
                {
                    Console.WriteLine(getTimeStamp() + "CTAPHID_MSG [0x{0:X2}] len={1:D}", hidMsg[1], hidMsgLen);
                    switch (hidMsg[1]) // Check FIDO INS
                    {
                        case U2F_REGISTER: // FIDO Registration Messages
                            if (curFidoReq.notSatisfiedTimer == null)
                                curFidoReq.startTimer();
                            break;
                        case U2F_AUTHENTICATE: // FIDO Authentication Messages
                            if (hidMsg[2] == U2F_UP_ENFORCE)
                            {
                                if (curFidoReq.notSatisfiedTimer == null)
                                    curFidoReq.startTimer();
                            }
                            break;
                    }
                }
            }
        }

        public void sendHidCborToGtid(uint cid, byte[] hidMsg, int hidMsgLen)
        {
            if (streamModule.isReady() == false)
            {
                Console.Write(getTimeStamp() + "CTAPHID_CBOR -> FIDO bridge not UP yet [ERR_CHANNEL_BUSY], ");
                //removeFidoRequest(cid);
                sendHidCborError(cid, CTAP1_ERR_CHANNEL_BUSY);
                return;
            }

            // This should be processed by GTID FIDO module
            if ((hidMsg[0] == FIDO2_GET_INFO) && (handleHidInfo == true))
            {
                byte[] infoRspOnly = new byte[] { 0x00,
                    0xa3, 0x01, 0x81, 0x68, 0x46, 0x49, 0x44, 0x4f, 0x5f, 0x32,
                    0x5f, 0x30, 0x03, 0x50, 0x01, 0x32, 0xd1, 0x10, 0xbf, 0x4e,
                    0x42, 0x08, 0xa4, 0x03, 0xab, 0x4f, 0x5f, 0x12, 0xef, 0xe5,
                    0x04, 0xa1, 0x62, 0x75, 0x76, 0xf4 };

                byte[] infoRspBoth = new byte[] {   0x00,
                                                    0xa3,0x01,0x82,0x68,0x46,0x49,0x44,0x4f,0x5f,0x32,
                                                    0x5f,0x30,0x66,0x55,0x32,0x46,0x5f,0x56,0x32,0x03,
                                                    0x50,0x01,0x32,0xd1,0x10,0xbf,0x4e,0x42,0x08,0xa4,
                                                    0x03,0xab,0x4f,0x5f,0x12,0xef,0xe5,0x04,0xa1,0x62,
                                                    0x75,0x76,0xf4 };
                if (fidoCapability == supportFIDO2Only)
                    sendHidResponse(cid, CTAPHID_CBOR, infoRspOnly, infoRspOnly.Length);
                else
                    sendHidResponse(cid, CTAPHID_CBOR, infoRspBoth, infoRspBoth.Length);
                curFidoReq.startWaitRequestTimer();
            }
            else
            {
                if (streamModule.Send(moduleFunction, CTAPHID_CBOR, cid, hidMsg, hidMsgLen) < 0)
                {
                    Console.Write(getTimeStamp() + "CTAPHID_CBOR -> Transport Module Send ERROR, ");
                    removeFidoRequest(cid);
                    sendHidCborError(cid, CTAP1_ERR_CHANNEL_BUSY);
                }
                else
                {
                    Console.WriteLine(getTimeStamp() + "CTAPHID_CBOR [0x{0:X2}] len={1:D}", hidMsg[1], hidMsgLen);
                    switch (hidMsg[0]) // Check FIDO2 Command`
                    {
                        case U2F_REGISTER: // FIDO Registration Messages
                        case U2F_AUTHENTICATE: // FIDO Authentication Messages
                            if (curFidoReq.notSatisfiedTimer == null)
                                curFidoReq.startTimer();
                            break;
                    }
                }
            }
        }

         public override void streamDown()
        {
            foreach (FidoRequest req in fidoRequestList)
            {
                req.Cancel();
                // Send out message???
            }
            fidoRequestList.Clear();
            Console.WriteLine(getTimeStamp() + "Stream Down - Remove all Fido Request [{0:D}/{1:D}]", fidoRequestList.Count, RequestMaxCount);

        }
    }
}
