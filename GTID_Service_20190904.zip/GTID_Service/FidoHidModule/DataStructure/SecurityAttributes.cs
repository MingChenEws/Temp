using System.Runtime.InteropServices;

namespace GTID_FidoHid.DataStructure
{
    [StructLayout(LayoutKind.Sequential)]
    public struct SecurityAttributes
    {
        public int nLength;
        public int lpSecurityDescriptor;
        public int bInheritHandle;
    }
}