﻿using System;
using Microsoft.Win32.SafeHandles;

namespace GTID_FidoHid.DataStructure
{
    public struct DeviceInformationStructure
    {
        public HiddAttributes Attributes;      // HID Attributes
        public HidpCaps Capabilities;          // HID Capabilities

        // The device's path name
        private string _devicePathName;
        public string DevicePathName
        {
            get { return _devicePathName; }
            set
            {
                _devicePathName = value;
                if (string.IsNullOrEmpty(_devicePathName))
                {
                    //DeviceChangeNotifier.Stop();
                }
                else
                {
                    //DeviceChangeNotifier.Start(_devicePathName);
                }
            }
        }

        // Device attachment state flag
        private bool _isDeviceAttached;

        public bool IsDeviceAttached
        {
            get { return _isDeviceAttached; }
            set {
                if (_isDeviceAttached == value) return;
                _isDeviceAttached = value;
            }
        }
    }
}
