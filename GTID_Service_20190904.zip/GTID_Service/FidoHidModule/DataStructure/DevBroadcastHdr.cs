using System;
using System.Runtime.InteropServices;

namespace GTID_FidoHid.DataStructure
{
    [StructLayout(LayoutKind.Sequential)]
    public class DevBroadcastHdr
    {
        internal Int32 dbch_size;
        internal Int32 dbch_devicetype;
        internal Int32 dbch_reserved;
    }
}