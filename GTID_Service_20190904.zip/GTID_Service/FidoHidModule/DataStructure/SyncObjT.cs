using System;
using System.IO;

namespace GTID_FidoHid.DataStructure
{
    public struct SyncObjT
    {
        public FileStream Fs;
        public Byte[] Buf;
    };
}