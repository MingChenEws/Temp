using System.Runtime.InteropServices;

namespace GTID_FidoHid.DataStructure
{
    [StructLayout(LayoutKind.Sequential)]
    public struct Overlapped
    {
        public int Internal;
        public int InternalHigh;
        public int Offset;
        public int OffsetHigh;
        public int hEvent;
    }
}