﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace GTID_Class
{
    public abstract class GTID_Module : GTID_ModuleInterface
    {
        public const byte GTID_TYPE_COMPONENT = 0x00;
        public const byte GTID_TYPE_TRANSPORT = 0x01;

        public const byte GTID_COMPONENT_GTID = 0x00;
        public const byte GTID_COMPONENT_FIDO = 0x01;
        public const byte GTID_COMPONENT_SMARTCARD = 0x02;

        public const byte GTID_TRANSPORT_SOCKET = 0x00;
        public const byte GTID_TRANSPORT_BLUETOOTH = 0x01;
        public const byte GTID_TRANSPORT_FILEPIPE = 0x02;

        public CancellationTokenSource cts = new CancellationTokenSource();
        public GTID_Module streamModule = null;
        public Task moduleTask = null;
        public bool ready = false;
        public byte moduleType = 0;
        public byte moduleFunction = 0;

        public abstract void Configure(List<KeyValuePair<string, Object>> kvlist);
        public abstract Task Run();
        //public abstract int Send(byte[] packet, int len);
        public abstract int Send(byte function, byte cmd, uint cid, byte[] packet, int len);
        public abstract void setStreamModule(GTID_Module module);
        public abstract void Stop();
        public abstract void streamDown();

        public bool isReady()
        {
            return ready;
        }

        public string getTimeStamp()
        {
            return DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff ");
        }
    }
}
