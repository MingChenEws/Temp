﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GTID_Class
{
    public interface GTID_ModuleInterface
    {
        void Configure(List<KeyValuePair<string, Object>> kv);
        Task Run();
        //int Send(byte[] packet, int len);
        int Send(byte function, byte cmd, uint cid, byte[] packet, int len);
        void setStreamModule(GTID_Module module);
        void Stop();
        void streamDown();
        bool isReady();
    }
}
