﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using GTID_Class;
using System.Diagnostics;
using Windows.Devices.Bluetooth;
using Windows.Foundation;
using Windows.Devices.Bluetooth.Rfcomm;
using Windows.Networking.Sockets;
using Windows.Storage.Streams;



namespace GTID_BlueTooth
{
    public class BlueToothModule : GTID_Module
    {
        bool bContinue = true;
        private uint readLength = 0;
        private uint MSGHDRLEN = 4;
        private uint mCurrentChanId = 0;
        private byte mCurrentReq = 0;
        private byte[] appId = new byte[32];
        List<AppIdKeyHandle> listAppIdKeyHandle = new List<AppIdKeyHandle>();

        public ManualResetEvent connectDone = new ManualResetEvent(false);
        public ManualResetEvent bindDone = new ManualResetEvent(false);
        public ManualResetEvent readDone = new ManualResetEvent(false);
        public ManualResetEvent loadDone = new ManualResetEvent(false);
        public ManualResetEvent storeDone = new ManualResetEvent(false);

        // The Chat Server's custom service Uuid: 34B1CF4D-1069-4AD6-89B6-E161D79BE4D8
        private static readonly Guid RfcommChatServiceUuid = Guid.Parse("34B1CF4D-1069-4AD6-89B6-E161D79BE4D9");

        // The Id of the Service Name SDP attribute
        private const UInt16 SdpServiceNameAttributeId = 0x100;

        // The SDP Type of the Service Name SDP attribute.
        // The first byte in the SDP Attribute encodes the SDP Attribute Type as follows :
        //    -  the Attribute Type size in the least significant 3 bits,
        //    -  the SDP Attribute Type value in the most significant 5 bits.
        private const byte SdpServiceNameAttributeType = (4 << 3) | 5;

        // The value of the Service Name SDP attribute
        private const string SdpServiceName = "Bluetooth Rfcomm Chat Service";

        private StreamSocket socket;
        private DataWriter writer;
        private RfcommServiceProvider rfcommProvider;
        private StreamSocketListener socketListener;

        private class AppIdKeyHandle
        {
            public byte[] mAppId;
            public byte[] mKeyHandle;

            public AppIdKeyHandle(byte[] a, byte[] k)
            {
                this.mAppId = a;
                this.mKeyHandle = k;
            }
        }

        public BlueToothModule()
        {
            moduleType = GTID_TYPE_TRANSPORT;
            moduleFunction = GTID_TRANSPORT_BLUETOOTH;
        }

        override
        public void Configure(List<KeyValuePair<string, Object>> kvlist)
        {

        }

        override
        public Task Run()
        {
            Console.WriteLine(getTimeStamp() + "Start BlueToothModule...");
            try
            {
                moduleTask = Task.Factory.StartNew(() => Start(), cts.Token);
            }
            catch (TaskCanceledException)
            {
                ready = false;
            }

            return moduleTask;
        }

        private void Start()
        {
            // Start BlueToothModule task, then staty in a loop
            // ready flag is the status for BlueToothModule task, not the BT link up or down
            do {
                readDone.Reset();
                initRfcomm();
                readDone.WaitOne();
            } while (bContinue);
            linkDown(2);
        }

        private void linkDown(int step)
        {
            Console.WriteLine(getTimeStamp() + "BlueToothModule Link is DOWN......[{0:D}]", step);
            ready = false;
            //listAppIdKeyHandle.Clear();
            if (streamModule != null) streamModule.streamDown();
        }

        override
        public int Send(byte function, byte cmd, uint cid, byte[] packet, int len)
        {
            // Used my stream module to send data thru BT link
            mCurrentChanId = cid;
            if (packet != null)
                Console.WriteLine(getTimeStamp() + "BridgeSocketModule.Send: cmd=0x{0:X2}, INS=0x{1:X2}, INS=0x{2:X2}",
                    cmd, packet[1], packet[2]);
            if (cmd == 0x83) //CTAPHID_MSG
            {
                mCurrentReq = packet[1];
                if ((packet[1] == 0x01) || (packet[1] == 0x02))
                {
                    System.Buffer.BlockCopy(packet, 39, appId, 0, 32); // appID
                    if (packet[2] == 0x07) // Check Only
                    {
                        int keyHandleLen = packet[71];
                        byte[] keyHandle = new byte[keyHandleLen];
                        System.Buffer.BlockCopy(packet, 72, keyHandle, 0, keyHandleLen); // keyHandle
                        return checkKeyHandle(appId, keyHandle);
                    }
                }
            }

            if (writer != null)
            {

                //byte[] hdr = new byte[8] { function, cmd, (byte)(len % 256), (byte)(len >> 8),
                //                        (byte)(cid % 256), (byte)(cid >> 8), (byte)(cid >> 16), (byte)(cid >> 24) };
                byte[] hdr = new byte[8] { function, cmd, (byte)(len >> 8), (byte)(len % 256),
                                        (byte)(cid >> 24), (byte)(cid >> 16), (byte)(cid >> 8), (byte)(cid % 256) };
                byte[] message = null;
                if (len > 0)
                {
                    message = new byte[len + MSGHDRLEN];
                    System.Buffer.BlockCopy(hdr, 0, message, 0, (int)MSGHDRLEN);
                    System.Buffer.BlockCopy(packet, 0, message, (int)MSGHDRLEN, len);
                }
                else
                {
                    message = new byte[MSGHDRLEN];
                    System.Buffer.BlockCopy(hdr, 0, message, 0, (int)MSGHDRLEN);
                }
                RFCommSend(message);
                return len;
            }
            return -1;
        }

        override
        public void setStreamModule(GTID_Module module)
        {
            // set stream module
            streamModule = module;
        }

        override
        public void Stop()
        {
            // Shutdown BT links and close Bluetooth device
            Disconnect();
            Console.WriteLine(getTimeStamp() + "Exit BlueToothModule...");
            cts.Cancel();
            bContinue = false;
            readDone.Set();
        }
        private void Disconnect()
        {
            if (rfcommProvider != null)
            {
                rfcommProvider.StopAdvertising();
                rfcommProvider = null;
            }

            if (socketListener != null)
            {
                socketListener.Dispose();
                socketListener = null;
            }

            if (writer != null)
            {
                writer.DetachStream();
                writer = null;
            }

            if (socket != null)
            {
                socket.Dispose();
                socket = null;
            }
        }

        override
        public void streamDown()
        {
            // called by stream module
        }

        public void ConnectCompleted(IAsyncOperation<RfcommServiceProvider> asyncInfo, AsyncStatus asyncStatus)
        {
            if (asyncStatus != AsyncStatus.Completed)
            {
                Console.WriteLine(getTimeStamp() + "BlueToothModule: Failed to CreateAsync RfcommServiceProvider");
            }
            else
            {
                rfcommProvider = asyncInfo.GetResults();
                if (rfcommProvider != null)
                {
                    Console.WriteLine(getTimeStamp() + "BlueToothModule: Successfully CreateAsync RfcommServiceProvider");
                }
                else
                {
                    Console.WriteLine(getTimeStamp() + "BlueToothModule: Failed to CreateAsync RfcommServiceProvider");
                }
            }
            connectDone.Set();
        }

        public void BindCompleted(IAsyncAction asyncInfo, AsyncStatus asyncStatus)
        {
            if (asyncStatus != AsyncStatus.Completed)
            {
                Console.WriteLine(getTimeStamp() + "BlueToothModule: Failed to Bind RfcommServiceProvider");
            }
            bindDone.Set();
        }

        public void LoadCompleted(IAsyncOperation<uint> asyncInfo, AsyncStatus asyncStatus)
        {
            if (asyncStatus != AsyncStatus.Completed)
            {
                Console.WriteLine(getTimeStamp() + "BlueToothModule: Failed to Bind RfcommServiceProvider");
                readLength = 0;
            }
            else
            {
                readLength = asyncInfo.GetResults();
            }
            loadDone.Set();
        }

        public void StoreCompleted(IAsyncOperation<uint> asyncInfo, AsyncStatus asyncStatus)
        {
            if (asyncStatus != AsyncStatus.Completed)
            {
                Console.WriteLine(getTimeStamp() + "BlueToothModule: Failed to writer.StoreAsync");
                //readLength = 0;
            } else
            {
                //readLength = asyncInfo.GetResults();
            }
            storeDone.Set();
        }

        void initRfcomm()
        {
            try
            {
                IAsyncOperation<RfcommServiceProvider> statusCreate = RfcommServiceProvider.CreateAsync(
                    RfcommServiceId.FromUuid(RfcommChatServiceUuid));
                if (statusCreate == null)
                {
                    Console.WriteLine(getTimeStamp() + "BlueToothModule: Failed to CreateAsync RfcommServiceProvider");
                }
                else
                {
                    connectDone.Reset();
                    statusCreate.Completed = ConnectCompleted;
                    connectDone.WaitOne();

                    // Create a listener for this service and start listening
                    socketListener = new StreamSocketListener();
                    socketListener.ConnectionReceived += OnConnectionReceived;

                    IAsyncAction statusBind = socketListener.BindServiceNameAsync(rfcommProvider.ServiceId.AsString(),
                        SocketProtectionLevel.BluetoothEncryptionAllowNullAuthentication);
                    if (statusBind == null)
                    {
                        Console.WriteLine(getTimeStamp() + "BlueToothModule: Failed to CreateAsync RfcommServiceProvider");
                    }
                    else
                    {
                        bindDone.Reset();
                        statusBind.Completed = BindCompleted;
                        bindDone.WaitOne();
                        // Set the SDP attributes and start Bluetooth advertising
                        InitializeServiceSdpAttributes(rfcommProvider);
                        rfcommProvider.StartAdvertising(socketListener);
                        Console.WriteLine(getTimeStamp() + "BlueToothModule: Listening for incoming connections");
                    }
                }
            }
            catch (InvalidOperationException e)
            {
                Console.WriteLine(getTimeStamp() + "BlueToothModule: CreateAsync[InvalidOperationException] " + e.Message);
            }

        }

        private void RFCommSend(byte[] data)
        {
            DataWriterStoreOperation statusStore;
            writer.WriteBytes(data);
            statusStore = writer.StoreAsync();
            if (statusStore == null)
            {
                Console.WriteLine(getTimeStamp() + "BlueToothModule: Failed to writer.StoreAsync");
            }
            else
            {
                storeDone.Reset();
                statusStore.Completed = StoreCompleted;
                storeDone.WaitOne();
                //statusStore = writer.StoreAsync();
                //storeDone.WaitOne();
            }
        }

        /// <summary>
        /// Initialize the Rfcomm service's SDP attributes.
        /// </summary>
        /// <param name="rfcommProvider">The Rfcomm service provider to initialize.</param>
        private void InitializeServiceSdpAttributes(RfcommServiceProvider rfcommProvider)
        {
            var sdpWriter = new DataWriter();

            // Write the Service Name Attribute.

            sdpWriter.WriteByte(SdpServiceNameAttributeType);

            // The length of the UTF-8 encoded Service Name SDP Attribute.
            sdpWriter.WriteByte((byte)SdpServiceName.Length);

            // The UTF-8 encoded Service Name value.
            sdpWriter.UnicodeEncoding = Windows.Storage.Streams.UnicodeEncoding.Utf8;
            sdpWriter.WriteString(SdpServiceName);

            // Set the SDP Attribute on the RFCOMM Service Provider.
            rfcommProvider.SdpRawAttributes.Add(SdpServiceNameAttributeId, sdpWriter.DetachBuffer());
        }

        /// <summary>
        /// Invoked when the socket listener accepted an incoming Bluetooth connection.
        /// </summary>
        /// <param name="sender">The socket listener that accecpted the connection.</param>
        /// <param name="args">The connection accept parameters, which contain the connected socket.</param>
        private void OnConnectionReceived(
            StreamSocketListener sender, StreamSocketListenerConnectionReceivedEventArgs args)
        {
            try
            {
                ready = true;
                Console.WriteLine(getTimeStamp() + "BT RfComm socket connected");

                // Don't need the listener anymore
                socketListener.Dispose();
                socketListener = null;

                socket = args.Socket;

                writer = new DataWriter(socket.OutputStream);
                var reader = new DataReader(socket.InputStream);

                bool remoteDisconnection = false;
                DataReaderLoadOperation statusLoad;
                Thread.Sleep(3000);
                //retrieve stored appId & keyHandle
                RFCommSend(new byte[5] { 0x01, 0x88, 0x00, 0x01, 0x00 });

                do
                {
                    Thread.Sleep(1000);
                    statusLoad = reader.LoadAsync(MSGHDRLEN);
                    if (statusLoad == null)
                    {
                        Console.WriteLine(getTimeStamp() + "BlueToothModule: Failed to reader.LoadAsync Header");
                    }
                    else
                    {
                        loadDone.Reset();
                        statusLoad.Completed = LoadCompleted;
                        loadDone.WaitOne();

                        if (readLength == 0) break;

                        if (readLength < MSGHDRLEN)
                        {
                            remoteDisconnection = true;
                            break;
                        }
                        byte[] hdr = new byte[readLength];
                        reader.ReadBytes(hdr);
                        uint currentLength = (uint)((hdr[2] << 8) + hdr[3]);

                        statusLoad = reader.LoadAsync(currentLength);
                        if (statusLoad == null)
                        {
                            statusLoad = reader.LoadAsync(currentLength);
                            Console.WriteLine(getTimeStamp() + "BlueToothModule: Failed to reader.LoadAsync Packet[{0:D}]", currentLength);
                        }
                        else
                        {
                            loadDone.Reset();
                            statusLoad.Completed = LoadCompleted;
                            loadDone.WaitOne();

                            if (readLength < currentLength)
                            {
                                remoteDisconnection = true;
                                break;
                            }
                            byte[] bdy = new byte[readLength];
                            reader.ReadBytes(bdy);
                            byte[] msgRcvd = new byte[MSGHDRLEN + readLength];
                            System.Buffer.BlockCopy(hdr, 0, msgRcvd, 0, (int)MSGHDRLEN);
                            System.Buffer.BlockCopy(bdy, 0, msgRcvd, (int)MSGHDRLEN, (int)readLength);

                            Console.Write(getTimeStamp() + "RFCOMME_SOCKET ");

                            //displayHexDump(msgRcvd.data);

                            if (msgRcvd[1] == 0x88) // WINK to retrieve stored appId & keyHandle
                            {
                                int len = (int)((msgRcvd[2] << 8) + msgRcvd[3]);
                                //(int)((msgRcvd[3] << 8) + msgRcvd[2]));
                                int idx = 0;
                                while (idx < len)
                                {
                                    byte[] appId = new byte[32];
                                    System.Buffer.BlockCopy(msgRcvd, idx + 1 + (int)MSGHDRLEN, appId, 0, 32);
                                    int keyHandleLen = msgRcvd[idx + MSGHDRLEN];
                                    byte[] keyHandle = new byte[keyHandleLen];
                                    System.Buffer.BlockCopy(msgRcvd, idx + 33 + (int)MSGHDRLEN, keyHandle, 0, keyHandleLen);
                                    listAppIdKeyHandle.Add(new AppIdKeyHandle(appId, keyHandle));
                                    idx += (33 + keyHandleLen);
                                }
                                Console.WriteLine("[U2FHID_WINK]: rcvd {0:D} 0x{1:X2}{2:X2}{3:X2}{4:X2}, len={5:D}, LIST cnt={6:D}",
                                        readLength, msgRcvd[0], msgRcvd[1], msgRcvd[2], msgRcvd[3], len, listAppIdKeyHandle.Count);
                            }
                            else
                            {

                                byte[] respData = new byte[readLength];
                                System.Buffer.BlockCopy(msgRcvd, (int)MSGHDRLEN, respData, 0, respData.Length);

                                uint cid = mCurrentChanId;
                                if (MSGHDRLEN > 4)
                                {
                                    // Needs to add cid in the Bridge protocol to support more than 1 request
                                    //cid = (uint)((msgRcvd[7] << 24) + (msgRcvd[6] << 16) + (msgRcvd[5] << 8) + msgRcvd[4]);
                                    cid = (uint)((msgRcvd[4] << 24) + (msgRcvd[5] << 16) + (msgRcvd[6] << 8) + msgRcvd[7]);
                                }
                                if (mCurrentReq == 0x01)
                                {
                                    if (respData.Length > 2) // Success
                                    {
                                        int keyHandleLen = respData[66];
                                        byte[] keyHandle = new byte[keyHandleLen];
                                        System.Buffer.BlockCopy(respData, 67, keyHandle, 0, keyHandleLen); // keyHandle
                                        bool found = false;
                                        foreach (AppIdKeyHandle p in listAppIdKeyHandle)
                                        {
                                            if (appId.SequenceEqual(p.mAppId))
                                            {
                                                p.mKeyHandle = keyHandle;
                                                found = true;
                                                break;
                                            }
                                        }
                                        if (!found)
                                            listAppIdKeyHandle.Add(new AppIdKeyHandle(appId, keyHandle));
                                    }
                                }
                                Console.WriteLine("[U2FHID_MSG]: rcvd {0:D} 0x{1:X2}{2:X2}{3:X2}{4:X2}, len={5:D}, cid={6:D}, LIST cnt={7:D}",
                                    readLength, msgRcvd[0], msgRcvd[1], msgRcvd[2], msgRcvd[3],
                                    (int)((msgRcvd[2] << 8) + msgRcvd[3]), mCurrentChanId, listAppIdKeyHandle.Count);
                                //(int)((msgRcvd[3] << 8) + msgRcvd[2]));
                                streamModule.Send(msgRcvd[0], msgRcvd[1], cid, respData, respData.Length);
                            }
                        }
                    }
                } while (!remoteDisconnection);

                reader.DetachStream();
                if (remoteDisconnection)
                {
                    Disconnect();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(getTimeStamp() + "BlueToothModule: Failed with Exception[{0}]", e.Message);
            }
            linkDown(1);
            readDone.Set();
        }

        private int checkKeyHandle(byte[] appId, byte[] keyHandle)
        {
            byte[] success = new byte[] { 0x69, 0x85 };
            byte[] fail = new byte[] { 0x6A, 0x80 };

            Console.Write(getTimeStamp() + "BridgeSocketModule: checkKeyHandle [0x{0:X2}{1:X2}{2:X2}{3:X2}], ",
                keyHandle[0], keyHandle[1], keyHandle[2], keyHandle[3]);
            foreach (AppIdKeyHandle p in listAppIdKeyHandle)
            {
                if ((appId.SequenceEqual(p.mAppId)) && (keyHandle.SequenceEqual(p.mKeyHandle)))
                {
                    Console.WriteLine("return [0x{0:X2}{1:X2}]", success[0], success[1]);
                    streamModule.Send(0, 0x83, mCurrentChanId, success, success.Length);
                    return 2;
                }
            }
            Console.WriteLine("return [0x{0:X2}{1:X2}]", fail[0], fail[1]);
            streamModule.Send(0, 0x83, mCurrentChanId, fail, fail.Length);
            return 2;
        }
    }
}
