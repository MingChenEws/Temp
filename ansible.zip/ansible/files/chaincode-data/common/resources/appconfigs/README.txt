Each .json file in this directory defines an application.

Optionally, a corresponding .pem file can be provided containing either a certificate or a public key.
If a .pem file is not provided, the .json MUST contains the "publicKey" attribute whose value is a base64-url encoded SHA-256 hash of the public key (in DER-encoded PKIX form)


