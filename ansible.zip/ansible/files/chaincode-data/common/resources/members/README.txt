Each .json file in this directory defines an member.

if a member has enckeyjwk, two ways are accepted:
1) provide full jwk fields, including kid, kty, x, y, crv and use
2) only provide kid, also provide a corresponding <filename>_enckeyjwk.pem file that contain a certificate or a public key.


