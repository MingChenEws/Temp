
MYAM_IMAGE=${1}
USERS_FILE=/tmp/myam_additional_users.json
# docker.securekey.com/internal/vme/demo/my-am:13.0.15

for c in `docker ps --filter "ancestor=${MYAM_IMAGE}" --format "{{.ID}}"`; do

  echo "DOING CONTAINER WITH ID: ${c}..."
  docker cp ${USERS_FILE} ${c}:/tmp/myam_additional_users.json && \
  docker exec -t -e USERS_REST_ENDPOINT=http://localhost:8080/myam/oidc/json/users \
    ${c} \
    /usr/local/bin/myam_store_users -userfile /tmp/myam_additional_users.json

done
