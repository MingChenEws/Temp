package com.ews.mock.rp.services;

import com.ews.mock.rp.config.OpenIdConfig;
import com.ews.mock.rp.models.accessToken.GetAccessTokenResponse;
import com.ews.mock.rp.models.complete.BaseIdentity;
import com.ews.mock.rp.utils.JwtHelper;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;

@Service
@Slf4j
public class XidService {
    private static final String RETRY_STATUS_CODE = "7000";

    private final RestTemplate restTemplate;
    private final URI xidTokenUrl;
    private final URI xidUserInfoUrl;
    private final JwtHelper jwtHelper;
    private final RetryTemplate retryTemplate;

    public XidService(RestTemplate restTemplate,
                      JwtHelper jwtHelper,
                      RetryTemplate retryTemplate,
                      OpenIdConfig openIdConfig) {
        val openIdMetadata = openIdConfig.getOpenIdConfig();

        this.restTemplate = restTemplate;
        this.xidUserInfoUrl = openIdMetadata.getUserInfoEndpointURI();
        this.xidTokenUrl = openIdMetadata.getTokenEndpointURI();
        this.jwtHelper = jwtHelper;
        this.retryTemplate = retryTemplate;
    }

    // region get access token
    public GetAccessTokenResponse callXidToken(final String payload) {
//        return retryTemplate.execute(context -> {
        val response = restTemplate.postForEntity(xidTokenUrl, payload, GetAccessTokenResponse.class);
        if (response.getBody() == null) {
            throw new XidException("Null response body, response: " + response.toString());
        }
        return response.getBody();
//        });
    }
    // endregion

    // region get userData
    public BaseIdentity callXidUserInfo(final String accessToken) {
//        return retryTemplate.execute(context -> {
        //populate Authorization header
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(accessToken);

        val entity = new HttpEntity<String>(headers);

        val response = restTemplate.exchange(xidUserInfoUrl, HttpMethod.GET, entity, String.class);
        if (response.getBody() == null) {
            throw new XidException("Null response body, response: " + response.toString());
        }

        val xidResponse = jwtHelper.parseJWE(response.getBody());

        val xidData = xidResponse.getData();
        if (xidData == null) {
            throw new XidException("Null response data, response: " + xidResponse);
        }

        val xidEwsIdVerification = xidData.getEwsIdVerification();
        if (xidEwsIdVerification == null) {
            throw new XidException("Null response ewsIdVerification, response: " + xidResponse);
        }

        if (xidEwsIdVerification.getBaseId() == null) {
            throw new XidException("Null response baseId, response: " + xidResponse);
        }

        return xidEwsIdVerification.getBaseId();
//        });
    }

    // endregion
}
