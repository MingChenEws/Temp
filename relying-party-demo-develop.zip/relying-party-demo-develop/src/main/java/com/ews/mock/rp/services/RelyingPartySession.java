package com.ews.mock.rp.services;


import com.ews.mock.rp.models.RpSession;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class RelyingPartySession {
    private final Map<String, RpSession> sessions = new ConcurrentHashMap<>();

    public RpSession get(final String ewSID) {
        return sessions.get(ewSID);
    }

    public void saveSession(final String ewSID, final RpSession rpSession) {
        sessions.put(ewSID, rpSession);
    }
}
