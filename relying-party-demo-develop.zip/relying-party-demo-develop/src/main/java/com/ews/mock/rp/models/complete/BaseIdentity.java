package com.ews.mock.rp.models.complete;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Value;

@Value
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BaseIdentity {
    @JsonProperty("given_name")
    String firstName;
    @JsonProperty("family_name")
    String lastName;
    @JsonProperty("middle_name")
    String middleName;
    String suffix;
    String prefix;
    String birthdate;
    String email;
    Address address;
    @JsonProperty("phone_number")
    String phoneNumber;
}
