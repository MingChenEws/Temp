package com.ews.mock.rp.controllers;

import com.ews.mock.rp.models.RpSession;
import com.ews.mock.rp.models.UserData;
import com.ews.mock.rp.models.UserView;
import com.ews.mock.rp.services.CreateRedirectUseCase;
import com.ews.mock.rp.services.RelyingPartySession;
import lombok.SneakyThrows;
import lombok.val;
import org.jetbrains.annotations.Nullable;
import org.springframework.security.crypto.keygen.Base64StringKeyGenerator;
import org.springframework.security.crypto.keygen.StringKeyGenerator;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.UUID;

@Service
public class SignUpUseCase {
    private final CreateRedirectUseCase createRedirectUseCase;
    private final RelyingPartySession relyingPartySession;
    private final StringKeyGenerator secureKeyGenerator =
            new Base64StringKeyGenerator(Base64.getUrlEncoder().withoutPadding(), 32);
    private final MessageDigest sha256MessageDigest;

    @SneakyThrows
    public SignUpUseCase(CreateRedirectUseCase createRedirectUseCase,
                         RelyingPartySession relyingPartySession) {
        this.createRedirectUseCase = createRedirectUseCase;
        this.relyingPartySession = relyingPartySession;
        this.sha256MessageDigest = MessageDigest.getInstance("SHA-256");
    }

    public String handleRequest(@Nullable final String initiator, @Nullable final String bankId, final boolean nativeApp) {
        val rpState = UUID.randomUUID().toString();
        val codeVerifier = secureKeyGenerator.generateKey();
        val codeChallenge = createHash(codeVerifier);
        //console.log(">>> handleRequest: initiator="+initiator);
        relyingPartySession.saveSession(rpState, new RpSession(codeVerifier, initiator));

        val callBackPath = nativeApp ? "/handleAppRedirect" : "/handleRedirect";

        return createRedirectUseCase.createRedirectToDiWebAuth(
                rpState,
                callBackPath,
                "/",
                codeChallenge,
                bankId);
    }

    public String[] handleUserVerificationRequest(@Nullable final String initiator, @Nullable final String bankId, @Nullable final UserView userDataView, final boolean nativeApp) {
        val rpState = UUID.randomUUID().toString();
        val codeVerifier = secureKeyGenerator.generateKey();
        val codeChallenge = createHash(codeVerifier);
        relyingPartySession.saveSession(rpState, new RpSession(codeVerifier, initiator, new UserData(userDataView), null));

        String[] params = new String[2];
        params[0] = rpState;
        val callBackPath = nativeApp ? "/handleAppRedirect" : "/handleRedirect";
        params[1] = createRedirectUseCase.createRedirectToDiWebAuth(
                rpState,
                callBackPath,
                "/",
                codeChallenge,
                bankId);

        return params;
    }

    private String createHash(String value) {
        byte[] digest = sha256MessageDigest.digest(value.getBytes(StandardCharsets.US_ASCII));
        return Base64.getUrlEncoder().withoutPadding().encodeToString(digest);
    }
}
