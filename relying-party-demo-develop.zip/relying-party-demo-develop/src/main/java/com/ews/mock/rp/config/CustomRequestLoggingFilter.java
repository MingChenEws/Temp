package com.ews.mock.rp.config;

import org.springframework.web.filter.CommonsRequestLoggingFilter;

import javax.servlet.http.HttpServletRequest;
import java.util.Arrays;
import java.util.List;

public class CustomRequestLoggingFilter extends CommonsRequestLoggingFilter {

    private static final List<String> FILTER = Arrays.asList(
            ".svg", ".woff", ".jpg", ".png", ".ico"
    );

    @Override
    protected boolean shouldLog(HttpServletRequest request) {
        for (String ext : FILTER) {
            if (request.getRequestURI().endsWith(ext)) {
                return false;
            }
        }
        return super.shouldLog(request);
    }
}
