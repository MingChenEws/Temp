package com.ews.mock.rp.services;

public class XidException extends RuntimeException {
    public XidException(String message) {
        super(message);
    }
}
