package com.ews.mock.rp.config;

import com.github.benmanes.caffeine.cache.CacheLoader;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;
import com.nimbusds.openid.connect.sdk.op.OIDCProviderMetadata;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.apache.commons.lang3.StringUtils;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.concurrent.TimeUnit;

@Service
@Slf4j
public class OpenIdConfig {

    private final String openIdConfigUrl;
    private final RestTemplate restTemplate;

    private final CacheLoader<String, OIDCProviderMetadata> cacheLoader = new CacheLoader<>() {
        @Override
        public @Nullable OIDCProviderMetadata load(@NonNull String key) {
            return doGetOpenidConfig();
        }
    };

    private final LoadingCache<String, OIDCProviderMetadata> cache = Caffeine.newBuilder()
            .refreshAfterWrite(1, TimeUnit.HOURS)
            .maximumSize(1)
            .build(cacheLoader);

    public OpenIdConfig(RpConfig rpConfig, RestTemplate restTemplate) {
        this.openIdConfigUrl = rpConfig.getXid().getOpenidConfig();
        this.restTemplate = restTemplate;
    }

    public OIDCProviderMetadata getOpenIdConfig() {
        val result = cache.get("openidConfig");
        log.debug("Returning cached result {}", result);
        return result;
    }

    @SneakyThrows
    private OIDCProviderMetadata doGetOpenidConfig() {
        log.debug("calling doGetOpenidConfig()");
        log.debug("proxy config: {}", System.getProperty("java.net.useSystemProxies"));
        if (!StringUtils.isBlank(openIdConfigUrl)) {
            val response = restTemplate.getForEntity(openIdConfigUrl, String.class);
            return OIDCProviderMetadata.parse(response.getBody());
        }
        return null;
    }

}