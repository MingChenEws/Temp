package com.ews.mock.rp.controllers;

import org.jetbrains.annotations.Nullable;

public class AppErrorException extends RuntimeException {
    private final String error;
    @Nullable
    private final String errorDescription;

    public @Nullable String getErrorDescription() {
        return errorDescription;
    }

    public AppErrorException(String error, @Nullable String errorDescription) {
        this.error = error;
        this.errorDescription = errorDescription;
    }

    public String getError() {
        return error;
    }
}