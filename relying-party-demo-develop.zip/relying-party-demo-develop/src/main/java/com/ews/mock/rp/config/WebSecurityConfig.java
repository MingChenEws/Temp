package com.ews.mock.rp.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration(proxyBeanMethods = false)
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
    private final RpConfig rpConfig;

    public WebSecurityConfig(RpConfig rpConfig) {
        this.rpConfig = rpConfig;
    }


    @Override
    protected void configure(HttpSecurity http) throws Exception {
        if (rpConfig.getPasswordRequired()) {
            http
                    .csrf().disable()
                    .authorizeRequests()
                    .antMatchers("/", "/continue").authenticated()
                    .anyRequest().permitAll()
                    .and()
                    .httpBasic();
        } else {
            http.csrf().disable().authorizeRequests().anyRequest().permitAll();
        }
    }

    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
        if (rpConfig.getPasswordRequired()) {
            auth.inMemoryAuthentication()
                    .withUser("rpuser")
                    .password("{noop}" + rpConfig.getPassword())
                    .roles("USER");
        }
    }
}