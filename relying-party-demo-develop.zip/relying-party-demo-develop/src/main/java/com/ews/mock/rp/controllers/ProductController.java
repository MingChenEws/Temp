package com.ews.mock.rp.controllers;

import com.ews.mock.rp.models.Faqs;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ProductController {

    private final Faqs faqs;

    public ProductController(Faqs faqs) {
        this.faqs = faqs;
    }

    @GetMapping("/product")
    public String getMarketingPage(final Model model) {
        model.addAttribute("faqs", faqs.getFaqs());
        return "product.html";
    }
}
