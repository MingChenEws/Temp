package com.ews.mock.rp.models.rsa;

import lombok.Value;
import net.minidev.json.JSONObject;

import java.util.List;

@Value
public class PublicKey {
    List<JSONObject> keys;
}
