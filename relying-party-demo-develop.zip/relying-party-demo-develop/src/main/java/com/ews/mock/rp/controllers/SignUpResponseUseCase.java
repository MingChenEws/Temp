package com.ews.mock.rp.controllers;

import com.ews.mock.rp.models.UserView;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;

@Component
@Slf4j
public class SignUpResponseUseCase {

    String handleXidUserInfoResponse(final Model model, final UserView userInfo) {
        if (userInfo == null) {
            return null;
        }
        log.info("Xid complete response: {}", userInfo);
        model.addAttribute("userInfo", userInfo);
        return "complete.html";
    }
}
