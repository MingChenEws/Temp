package com.ews.mock.rp.controllers;

import com.ews.mock.rp.models.UserData;
import com.ews.mock.rp.models.UserView;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;
import org.jetbrains.annotations.Nullable;

@Component
@Slf4j
public class SignUpResponseUseCase {

    String handleXidUserInfoResponse(final Model model, final UserView userInfo, final UserData userData, @Nullable final String initiator) {
        log.info(">>> handleXidUserInfoResponse::: initiator="+initiator);

        if (userInfo == null) {
            return null;
        }
        log.info("Xid complete response: {}", userInfo);
        if (initiator.equalsIgnoreCase("ageVerification"))
        {
            if (userInfo.isAgeOver(21)) {
                log.info(">>> handleXidUserInfoResponse::successful: initiator="+initiator);
                return "age-verification-successful.html";
            }
            else {
                log.info(">>> handleXidUserInfoResponse::failed: initiator="+initiator);
                return "age-verification-failed.html";
            }
        }
        else if (initiator.equalsIgnoreCase("userVerification")) {
            log.info(">>> handleXidUserInfoResponse::failed: initiator="+initiator);
            boolean allVerified = userInfo.compareUserData(userData);
            model.addAttribute("userData", userData);
            log.info("compareUserData:: allVerified ["+allVerified+"]");
            log.info("compareUserData::"+ "["+userInfo.getFirstName()+"]["+userData.userView.getFirstName()+"]["+userData.verified[0]+"]");
            log.info("compareUserData::"+ "["+userInfo.getLastName()+"]["+userData.userView.getLastName()+"]["+userData.verified[1]+"]");
            log.info("compareUserData::"+"["+userInfo.getBirthdate()+"]["+userData.userView.getBirthdate()+"]["+userData.verified[5]+"]");
            log.info("compareUserData::"+ "["+userInfo.getPhoneNumber()+"]["+userData.userView.getPhoneNumber()+"]["+userData.verified[8]+"]");
            if (allVerified)
                return "user-verification-successful.html";
            else
                return "user-verification-failed.html";
        } else { // Insurance.co
            log.info(">>> handleXidUserInfoResponse::NOT equal: initiator="+initiator);
            model.addAttribute("userInfo", userInfo);
            return "complete.html";
        }

    }
}
