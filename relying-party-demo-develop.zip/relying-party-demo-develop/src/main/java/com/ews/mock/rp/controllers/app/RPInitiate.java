package com.ews.mock.rp.controllers.app;

import com.ews.mock.rp.controllers.SignUpUseCase;
import com.ews.mock.rp.models.XidStart;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RPInitiate {

    private final SignUpUseCase signUpUseCase;

    private RPInitiate(final SignUpUseCase signUpUseCase) {
        this.signUpUseCase = signUpUseCase;
    }

    @GetMapping("/xid-start")
    public XidStart getAuthUrl(final @RequestParam(required = false) String initiator, final @RequestParam(required = false) String bankId) {
        return new XidStart(signUpUseCase.handleRequest(initiator, bankId, true));
    }
}
