package com.ews.mock.rp.controllers.app;

import com.ews.mock.rp.controllers.AppErrorException;
import com.ews.mock.rp.controllers.OauthUseCase;
import com.ews.mock.rp.models.XidComplete;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
public class RPComplete {
    private final OauthUseCase oauthUseCase;


    public RPComplete(OauthUseCase oauthUseCase) {
        this.oauthUseCase = oauthUseCase;
    }

    @PostMapping("/xid-complete")
    public ResponseEntity<XidComplete> getUserInfo(
            @RequestParam(required = false) final String state,
            @RequestParam(value = "session_state", required = false) final String sessionState,
            @RequestParam(required = false) final String code,
            @RequestParam(required = false) final String error,
            @RequestParam(value = "error_description", required = false) final String errorDescription
    ) {
        if (StringUtils.equals("access_denied", error)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(
                    new XidComplete(error, errorDescription, null));
        }
        if (StringUtils.equals("user_cancelled", error)) {
            return ResponseEntity.status(HttpStatus.RESET_CONTENT).body(
                    new XidComplete(error, errorDescription, null));
        }

        try {
            val response = oauthUseCase.getUserInfo(state, code);
            log.info("Xid complete response: {}", response);
            return ResponseEntity.ok(new XidComplete(
                    null,
                    null,
                    response
            ));
        } catch (AppErrorException ex) {
            if (StringUtils.equals("invalid_userinfo", ex.getError())) {
                return ResponseEntity.notFound().build();
            }
            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new XidComplete(ex.getError(), ex.getErrorDescription(), null)
                    );
        }
    }
}
