package com.ews.mock.rp.services;

import com.ews.mock.rp.models.rsa.PublicKey;
import com.nimbusds.jose.jwk.RSAKey;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import net.minidev.json.JSONObject;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
@Slf4j
public class JWKService {

    private final RSAKey rsaKey;

    public JWKService(RSAKey rsaKey) {
        this.rsaKey = rsaKey;
    }

    public PublicKey getJwks() {
        val keys = new ArrayList<JSONObject>();
        keys.add(rsaKey.toJSONObject());
        return new PublicKey(keys);
    }
}
