package com.ews.mock.rp.models;

import lombok.Value;

@Value
public class XidStart {
    String authUrl;
}
