package com.ews.mock.rp.config;

import com.ews.mock.rp.models.Faqs;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.retry.backoff.FixedBackOffPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.web.client.RestTemplate;

import java.util.function.Supplier;

@Configuration(proxyBeanMethods = false)
@Slf4j
@EnableCaching
public class AppConfig {

    @Bean
    public RetryTemplate retryTemplate(RpConfig rpConfig) {
        val retryTemplate = new RetryTemplate();

        val fixedBackOffPolicy = new FixedBackOffPolicy();
        fixedBackOffPolicy.setBackOffPeriod(rpConfig.getXid().getRetryWait());
        retryTemplate.setBackOffPolicy(fixedBackOffPolicy);

        val retryPolicy = new SimpleRetryPolicy();
        retryPolicy.setMaxAttempts(rpConfig.getXid().getMaxtries());
        retryTemplate.setRetryPolicy(retryPolicy);

        return retryTemplate;
    }

    @Bean
    public RestTemplate restTemplate(RestTemplateBuilder restTemplateBuilder) {
        Supplier<ClientHttpRequestFactory> requestFactorySupplier =
                () -> new BufferingClientHttpRequestFactory(new SimpleClientHttpRequestFactory());

        return restTemplateBuilder.requestFactory(requestFactorySupplier)
                .interceptors(new LoggingRequestInterceptor()).build();
    }

    @Bean
    @SneakyThrows
    public Faqs faqList(final ObjectMapper om) {
        try (val faqStream = getClass().getResourceAsStream("/faqs.json")) {
            return om.readValue(faqStream, Faqs.class);
        }
    }

}
