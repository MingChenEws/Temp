package com.ews.mock.rp.controllers;

import com.ews.mock.rp.config.RpConfig;
import com.ews.mock.rp.models.RpSession;
import com.ews.mock.rp.models.UserData;
import com.ews.mock.rp.models.complete.BaseIdentity;
import com.ews.mock.rp.services.RelyingPartySession;
import com.ews.mock.rp.services.XidService;
import com.ews.mock.rp.utils.JwtHelper;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class OauthUseCase {
    private final XidService xidService;
    private final RelyingPartySession relyingPartySession;
    private final JwtHelper jwtHelper;
    private final RpConfig rpConfig;

    public OauthUseCase(XidService xidService,
                        RelyingPartySession relyingPartySession,
                        JwtHelper jwtHelper,
                        RpConfig rpConfig) {
        this.xidService = xidService;
        this.relyingPartySession = relyingPartySession;
        this.jwtHelper = jwtHelper;
        this.rpConfig = rpConfig;
    }

    public RpSession getSession(final String state) {
        log.info(">>> getSession");
        val session = relyingPartySession.get(state);
        if (session == null) {
            throw new AppErrorException("missing_session", null);
        }
        return session;
    }

    public String getInitiator(final String state) {
        log.info(">>> getInitiator");
        val session = relyingPartySession.get(state);
        if (session == null) {
            throw new AppErrorException("missing_session", null);
        }
        String initiator = session.getInitiator();
        log.info(">>> getInitiator: initiator="+initiator);
        return initiator;
    }

    public UserData getUserData(final String state) {
        log.info(">>> getUserData");
        val session = relyingPartySession.get(state);
        if (session == null) {
            throw new AppErrorException("missing_session", null);
        }
        UserData userData = session.getUserData();
        log.info(">>> getUserData: userData="+userData);
        return userData;
    }

    public BaseIdentity getUserInfo(final String state, final String code) {
        log.info(">>> BaseIdentity getUserInfo");
        val session = relyingPartySession.get(state);
        if (session == null) {
            throw new AppErrorException("missing_session", null);
        }
        if (StringUtils.isBlank(code)) {
            throw new AppErrorException("missing_code", null);
        }

        val codeVerifier = session.getCodeVerifier();
        val jwtIvnToken = jwtHelper.createJWTIvnToken();
        val requestBody = "code=" + code + "&code_verifier=" + codeVerifier
                + "&client_assertion=" + jwtIvnToken
                + "&client_assertion_type=" + rpConfig.getXid().getClientAssertionType();
        val tokenResponse = xidService.callXidToken(requestBody);
        if (StringUtils.isEmpty(tokenResponse.getAccessToken())) {
            throw new AppErrorException("empty_access_token", "Empty access token");
        }

        log.info("Got ewsAuthToken: {}", tokenResponse.getAccessToken());
        val result = xidService.callXidUserInfo(tokenResponse.getAccessToken());
        if (result == null) {
            throw new AppErrorException("invalid_userinfo", "Invalid userinfo response");
        }
        return result;
    }
}
