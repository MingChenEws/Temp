package com.ews.mock.rp.config;

import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.apache.commons.io.IOUtils;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

@Slf4j
public class LoggingRequestInterceptor implements ClientHttpRequestInterceptor {

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body,
                                        ClientHttpRequestExecution execution) throws IOException {
        traceRequest(request, body);
        val response = execution.execute(request, body);
        traceResponse(response);
        return response;
    }

    private void traceRequest(HttpRequest request, byte[] body) {
        log.info("Request -- URI: {}, Method: {}, Headers: {}, Request body: {}",
                request.getURI(),
                request.getMethod(),
                request.getHeaders(),
                new String(body)
        );
    }

    private void traceResponse(ClientHttpResponse response) throws IOException {
        val body = IOUtils.toString(response.getBody(), StandardCharsets.UTF_8);
        log.info(
                "Response -- Status code: {}, Status text: {}, Headers: {}, Response body: {}",
                response.getStatusText(),
                response.getStatusText(),
                response.getHeaders(),
                body
        );
    }
}
