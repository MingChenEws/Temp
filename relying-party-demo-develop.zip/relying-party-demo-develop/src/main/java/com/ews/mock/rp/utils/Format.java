package com.ews.mock.rp.utils;

import lombok.val;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Format {

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("MM/dd/yyyy");

    public static String formatPhone(final String phone) {
        if (StringUtils.isBlank(phone)) {
            return null;
        }
        val phoneStripped = stripPhone(phone);
        if (phoneStripped.length() != 10) {
            return phoneStripped;
        }
        val part1 = phoneStripped.substring(0, 3);
        val part2 = phoneStripped.substring(3, 6);
        val part3 = phoneStripped.substring(6, 10);
        return String.format("(%s) %s-%s", part1, part2, part3);

    }

    private static String stripPhone(final String phone) {
        val phoneStripped = phone.replaceAll("\\D", "");
        if (phoneStripped.startsWith("1")) {
            return phoneStripped.substring(1);
        }
        return phoneStripped;
    }

    public static String formatDate(final String date) {
        if (StringUtils.isBlank(date)) {
            return null;
        }
        val theDate = LocalDate.parse(date, DateTimeFormatter.BASIC_ISO_DATE);
        return theDate.format(FORMATTER);
    }
}
