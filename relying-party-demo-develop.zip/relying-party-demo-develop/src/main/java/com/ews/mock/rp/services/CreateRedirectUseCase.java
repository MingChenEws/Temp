package com.ews.mock.rp.services;

import com.ews.mock.rp.config.OpenIdConfig;
import com.ews.mock.rp.config.RpConfig;
import com.ews.mock.rp.utils.JwtHelper;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Component
@Slf4j
public class CreateRedirectUseCase {
    private final String callbackUrl;
    private final JwtHelper jwtHelper;
    private final OpenIdConfig openIdConfig;
    private final String authorizeEndpoint;

    @SneakyThrows
    public CreateRedirectUseCase(RpConfig rpConfig,
                                 JwtHelper jwtHelper,
                                 OpenIdConfig openIdConfig) {
        this.authorizeEndpoint = rpConfig.getXid().getAuthorizeEndpoint();
        this.callbackUrl = rpConfig.getCallbackUrl();
        this.jwtHelper = jwtHelper;
        this.openIdConfig = openIdConfig;
    }

    public String createRedirectToDiWebAuth(
            final String rpState,
            final String callbackPath,
            final String cancelPath,
            final String codeChallenge,
            @Nullable final String bankId) {
        val callbackUri = UriComponentsBuilder.fromHttpUrl(callbackUrl)
                .path(callbackPath)
                .build().toUriString();

        UriComponentsBuilder uri;
        if (StringUtils.isBlank(authorizeEndpoint)) {
            val oIConfig = openIdConfig.getOpenIdConfig();
            uri = UriComponentsBuilder.fromUri(oIConfig.getAuthorizationEndpointURI());
        } else {
            uri = UriComponentsBuilder.fromUriString(authorizeEndpoint);
        }

        val cancelUri = UriComponentsBuilder.fromHttpUrl(callbackUrl)
                .path(cancelPath)
                .build().toUriString();

        String nonce = "qwerty12345678900";
        val rpJws = jwtHelper.createJWT(nonce, rpState, callbackUri, codeChallenge, cancelUri, bankId);
        log.info("rp jwt is: {}", rpJws);

        val redirectUriBuilder = uri.queryParam("request", rpJws);
        val redirectUri = redirectUriBuilder.encode().build();

        val redirect = redirectUri.toUriString();
        log.info("Generated redirectUri {}", redirect);
        return redirect;
    }

}
