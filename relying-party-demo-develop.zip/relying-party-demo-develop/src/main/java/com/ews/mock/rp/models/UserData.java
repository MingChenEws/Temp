package com.ews.mock.rp.models;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
public class UserData {
    public UserView userView;
    public boolean[] verified = new boolean[9];

    public UserData(UserView userView) {
        this.userView = userView;
        for(int i=0; i<verified.length; i++) {
            verified[i] = true;
        }
    }
}
