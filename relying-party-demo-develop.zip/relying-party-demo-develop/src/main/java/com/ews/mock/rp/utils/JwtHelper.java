package com.ews.mock.rp.utils;


import com.ews.mock.rp.config.JWKSAuthConfig;
import com.ews.mock.rp.config.OpenIdConfig;
import com.ews.mock.rp.config.RpConfig;
import com.ews.mock.rp.models.complete.XidCompleteResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nimbusds.jose.JWEObject;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.crypto.RSADecrypter;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.Nullable;
import org.springframework.stereotype.Service;

import java.security.PrivateKey;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.UUID;

@Slf4j
@Service
public class JwtHelper {

    private final String rpDisplayName;
    private final String clientId;
    private final String rpScope;
    private final String audience;
    private final RSASSASigner signer;
    private final RSAKey publicKey;
    private final String rpPrompt;
    private ObjectMapper om;
    private JWKSAuthConfig jwksAuthConfig;

    @SneakyThrows
    public JwtHelper(RpConfig rpConfig,
                     PrivateKey jwtPrivateKey,
                     RSAKey publicKey,
                     ObjectMapper objectMapper,
                     JWKSAuthConfig jwksAuthConfig,
                     OpenIdConfig openIdConfig) {
        this.rpDisplayName = rpConfig.getDisplayName();
        this.clientId = rpConfig.getXid().getClientId();
        this.audience = openIdConfig.getOpenIdConfig().getTokenEndpointURI().toString();
        this.rpScope = rpConfig.getScope();
        this.rpPrompt = rpConfig.getPrompt();
        this.signer = new RSASSASigner(jwtPrivateKey);
        this.publicKey = publicKey;
        this.om = objectMapper;
        this.jwksAuthConfig = jwksAuthConfig;
    }

    @SneakyThrows
    public String createJWT(final String nonce,
                            final String state,
                            final String callbackUri,
                            final String codeChallenge,
                            final String cancelPath,
                            @Nullable final String bankId
    ) {

        val now = Instant.now();

        val claimsSetBuilder = new JWTClaimsSet.Builder()
                .subject(this.rpDisplayName)
                .issuer(this.rpDisplayName)
                .issueTime(Date.from(now))
                .jwtID(UUID.randomUUID().toString())
                .expirationTime(Date.from(now.plus(5L, ChronoUnit.MINUTES)))
                .claim("state", state)
                .claim("response_type", "code")
                .claim("client_id", clientId)
                .claim("nonce", nonce)
                .claim("prompt", rpPrompt)
                .claim("scope", rpScope)
                .claim("redirect_uri", callbackUri)
                .claim("code_challenge", codeChallenge)
                .claim("code_challenge_method", "S256")
                .claim("cancelUrl", cancelPath);

        if (!StringUtils.isBlank(bankId)) {
            claimsSetBuilder.claim("bankId", bankId);
        }

        val signedJWT = new SignedJWT(
                new JWSHeader.Builder(JWSAlgorithm.RS256).build(),
                claimsSetBuilder.build());

        signedJWT.sign(signer);

        return signedJWT.serialize();
    }

    @SneakyThrows
    public String createJWTIvnToken() {

        val now = Instant.now();

        val claimsSetBuilder = new JWTClaimsSet.Builder()
                .issuer(clientId)
                .subject(clientId)
                .audience(audience)
                .issueTime(Date.from(now))
                .jwtID(UUID.randomUUID().toString())
                .expirationTime(Date.from(now.plus(5L, ChronoUnit.MINUTES)));

        val signedJWT = new SignedJWT(
                new JWSHeader.Builder(JWSAlgorithm.RS256).build(),
                claimsSetBuilder.build());

        signedJWT.sign(signer);

        return signedJWT.serialize();
    }

    @SneakyThrows
    public XidCompleteResponse parseJWE(final String rpJwt) {
        val jweObject = JWEObject.parse(rpJwt);
        val decrypter = new RSADecrypter(signer.getPrivateKey());
        jweObject.decrypt(decrypter);

        val jwsResponse = jweObject.getPayload().toJWSObject();
        val verifier = new RSASSAVerifier(jwksAuthConfig.getXidPublicKey());
        if (!jwsResponse.verify(verifier)) {
            throw new SecurityException("Jwt verification failed");
        }

        val jsonResponse = jwsResponse.getPayload().toString();
        return om.readValue(jsonResponse, XidCompleteResponse.class);
    }
}