package com.ews.mock.rp.config;


import com.nimbusds.jose.jwk.RSAKey;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.apache.commons.io.IOUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.crypto.EncryptedPrivateKeyInfo;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.UUID;

@Configuration(proxyBeanMethods = false)
@Slf4j
public class CertConfig {

    private static final Base64.Decoder DECODER = Base64.getDecoder();

    @Bean
    @SneakyThrows
    public PrivateKey jwtPrivateKey(RpConfig rpConfig) {
        //load private cert from pem file
        val privateKeyPath = rpConfig.getKey().getPrivateKey();
        val stream = getClass().getResourceAsStream("/" + privateKeyPath);
        if (stream == null) {
            throw new RuntimeException("Unable to load " + privateKeyPath);
        }
        val privateKey = IOUtils.toString(stream, StandardCharsets.UTF_8);
        if (privateKey == null || privateKey.length() == 0) {
            throw new RuntimeException("Unable to load " + privateKeyPath);
        }
        val privateKeyContent = privateKey.replaceAll("\\n", "")
                .replace("-----BEGIN ENCRYPTED PRIVATE KEY-----", "")
                .replace("-----END ENCRYPTED PRIVATE KEY-----", "");
        val pkInfo = new EncryptedPrivateKeyInfo(DECODER.decode(privateKeyContent));
        val keySpec = new PBEKeySpec(rpConfig.getKey().getPassword().toCharArray());
        val pbeKeyFactory = SecretKeyFactory.getInstance(pkInfo.getAlgName());
        val keyFactory = KeyFactory.getInstance("RSA");
        val encodedKeySpec = pkInfo.getKeySpec(pbeKeyFactory.generateSecret(keySpec));
        return keyFactory.generatePrivate(encodedKeySpec);
    }

    @Bean
    @SneakyThrows
    public RSAKey publicKey(RpConfig rpConfig) {
        val stream = CertConfig.class.getResourceAsStream("/" + rpConfig.getKey().getPublicKey());
        val publicKeyContent = IOUtils.toString(stream, StandardCharsets.UTF_8)
                .replaceAll("\\n", "")
                .replace("-----BEGIN PUBLIC KEY-----", "")
                .replace("-----END PUBLIC KEY-----", "");

        val keyFactory = KeyFactory.getInstance("RSA");

        val keySpecPKCS8 = new X509EncodedKeySpec(DECODER.decode(publicKeyContent));
        val publicKey = keyFactory.generatePublic(keySpecPKCS8);

        return new RSAKey.Builder((RSAPublicKey) publicKey)
                .keyID(UUID.randomUUID().toString()).build();
    }
}
