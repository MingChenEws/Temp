package com.ews.mock.rp.controllers;

import com.ews.mock.rp.models.rsa.PublicKey;
import com.ews.mock.rp.services.JWKService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JWKController {

    private final JWKService jwkService;

    public JWKController(final JWKService jwkService) {
        this.jwkService = jwkService;
    }

    @GetMapping("/jwks.json")
    public PublicKey getPublicJWKS() {
        return jwkService.getJwks();
    }
}
