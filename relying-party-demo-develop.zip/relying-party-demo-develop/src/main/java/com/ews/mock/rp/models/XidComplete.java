package com.ews.mock.rp.models;

import com.ews.mock.rp.models.complete.BaseIdentity;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Value;

@Value
public class XidComplete {
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String error;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty("error_description")
    private String errorDescription;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private BaseIdentity userInfo;
}
