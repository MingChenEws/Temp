package com.ews.mock.rp.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.jetbrains.annotations.Nullable;

@Data
@AllArgsConstructor
public class RpSession {
    @Nullable
    private String codeVerifier;
    private String initiator;
    private UserData userData;
    private String code = null;
    public RpSession(String codeVerifier, String initiator) {
        this.codeVerifier = codeVerifier;
        this.initiator = initiator;
        this.userData = null;
        this.code = null;
    }

    public UserData getUserData() {
        return this.userData;
    }

}
