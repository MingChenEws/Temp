package com.ews.mock.rp.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.jetbrains.annotations.Nullable;

@Data
@AllArgsConstructor
public class RpSession {
    @Nullable
    private String codeVerifier;
}
