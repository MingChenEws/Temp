package com.ews.mock.rp.config;

import lombok.Value;
import lombok.experimental.NonFinal;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConstructorBinding;

@Value
@ConstructorBinding
@NonFinal
@ConfigurationProperties("rp")
public class RpConfig {
    Boolean bankWidget;
    String widgetUrl;
    String callbackUrl;
    String displayName;
    String password;
    Boolean passwordRequired;
    String scope;
    String prompt;
    XidConfig xid;
    Key key;

    @Value
    @NonFinal
    @ConstructorBinding
    public static class XidConfig {
        String baseUrl;
        String openidConfig;
        int jwksConnectTimeout;
        int jwksReadTimeout;
        String clientId;
        String clientAssertionType;
        String clientAcctId;
        String license;
        Integer maxtries;
        Long retryWait;
        String app;
        String authorizeEndpoint;
    }

    @Value
    @ConstructorBinding
    public static class Key {
        String publicKey;
        String privateKey;
        String password;
    }
}
