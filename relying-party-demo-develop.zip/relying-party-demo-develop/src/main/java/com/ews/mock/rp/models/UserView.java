package com.ews.mock.rp.models;

import com.ews.mock.rp.models.complete.Address;
import com.ews.mock.rp.models.complete.BaseIdentity;
import lombok.Value;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

import static com.ews.mock.rp.utils.Format.formatDate;
import static com.ews.mock.rp.utils.Format.formatPhone;

@Value

public class UserView {
    String firstName;
    String lastName;
    String middleName;
    String suffix;
    String prefix;
    String birthdate;
    String email;
    AddressView address;
    String phoneNumber;

    public static UserView fromBaseIdentity(final BaseIdentity baseIdentity) {
        return new UserView(
                baseIdentity.getFirstName(),
                baseIdentity.getLastName(),
                baseIdentity.getMiddleName(),
                baseIdentity.getSuffix(),
                baseIdentity.getPrefix(),
                formatDate(baseIdentity.getBirthdate()),
                baseIdentity.getEmail(),
                AddressView.fromAddress(baseIdentity.getAddress()),
                formatPhone(baseIdentity.getPhoneNumber())
        );
    }

    public UserView(String firstName, String lastName, String middleName, String suffix, String prefix, String birthday, String email, AddressView address, String phoneNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.middleName = middleName;
        this.suffix = suffix;
        this.prefix = prefix;
        this.birthdate = birthday;
        this.email = email;
        this.address = address;
        this.phoneNumber = phoneNumber;
    }

    byte firstNameIdx = 0;
    byte lastNameIdx = 1;
    byte birthdayIdx = 5;
    byte phoneNumberIdx = 8;

    public boolean compareUserData(UserData userData) {
        if (userData.userView.firstName == null) {
            if (this.firstName == null) {
                userData.verified[firstNameIdx] = true;
            } else {
                userData.verified[firstNameIdx] = false;
            }
        } else {
            userData.verified[firstNameIdx] = this.firstName.equalsIgnoreCase(userData.userView.firstName);
        }

        if (userData.userView.lastName == null) {
            if (this.lastName == null) {
                userData.verified[lastNameIdx] = true;
            } else {
                userData.verified[lastNameIdx] = false;
            }
        } else {
            userData.verified[lastNameIdx] = this.lastName.equalsIgnoreCase(userData.userView.lastName);
        }

        if (userData.userView.birthdate == null) {
            if (this.birthdate == null) {
                userData.verified[birthdayIdx] = true;
            } else {
                userData.verified[birthdayIdx] = false;
            }
        } else {
            userData.verified[birthdayIdx] = this.birthdate.equalsIgnoreCase(userData.userView.birthdate);
        }

        String phone = "";
        if (userData.userView.phoneNumber == null) {
            if (this.phoneNumber == null) {
                userData.verified[phoneNumberIdx] = true;
            } else {
                userData.verified[phoneNumberIdx] = false;
            }
        } else {
            phone = formatPhone(userData.userView.phoneNumber);
            userData.verified[phoneNumberIdx] = this.phoneNumber.equalsIgnoreCase(phone);
        }

        for(boolean b : userData.verified) {
            if (b == false) return false;
        }
        return true;
    }

    public boolean isAgeOver(int targetAge) {
        LocalDate dt = LocalDate.parse(birthdate, DateTimeFormatter.ofPattern("MM/dd/yyyy"));
        return Period.between(dt, LocalDate.now()).getYears() >= targetAge;
    }

    @Value
    public static class AddressView {
        String country;
        String locality;
        String region;
        String postalCode;
        String streetAddress;
        String streetAddress2;
        String streetAddress3;
        String type;

        public static AddressView fromAddress(final Address address) {
            return new AddressView(
                    address.getCountry(),
                    address.getLocality(),
                    address.getRegion(),
                    address.getPostalCode(),
                    address.getStreetAddress(),
                    address.getStreetAddress2(),
                    address.getStreetAddress3(),
                    address.getType()
            );
        }
    }
}
