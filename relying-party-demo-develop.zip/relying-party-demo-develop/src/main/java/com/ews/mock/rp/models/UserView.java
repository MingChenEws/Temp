package com.ews.mock.rp.models;

import com.ews.mock.rp.models.complete.Address;
import com.ews.mock.rp.models.complete.BaseIdentity;
import lombok.Value;

import static com.ews.mock.rp.utils.Format.formatDate;
import static com.ews.mock.rp.utils.Format.formatPhone;

@Value
public class UserView {
    String firstName;
    String lastName;
    String middleName;
    String suffix;
    String prefix;
    String birthdate;
    String email;
    AddressView address;
    String phoneNumber;

    public static UserView fromBaseIdentity(final BaseIdentity baseIdentity) {
        return new UserView(
                baseIdentity.getFirstName(),
                baseIdentity.getLastName(),
                baseIdentity.getMiddleName(),
                baseIdentity.getSuffix(),
                baseIdentity.getPrefix(),
                formatDate(baseIdentity.getBirthdate()),
                baseIdentity.getEmail(),
                AddressView.fromAddress(baseIdentity.getAddress()),
                formatPhone(baseIdentity.getPhoneNumber())
        );
    }

    @Value
    public static class AddressView {
        String country;
        String locality;
        String region;
        String postalCode;
        String streetAddress;
        String streetAddress2;
        String streetAddress3;
        String type;

        public static AddressView fromAddress(final Address address) {
            return new AddressView(
                    address.getCountry(),
                    address.getLocality(),
                    address.getRegion(),
                    address.getPostalCode(),
                    address.getStreetAddress(),
                    address.getStreetAddress2(),
                    address.getStreetAddress3(),
                    address.getType()
            );
        }
    }
}
