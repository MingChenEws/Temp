package com.ews.mock.rp.config;

import com.github.benmanes.caffeine.cache.CacheLoader;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.openid.connect.sdk.op.OIDCProviderMetadata;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.security.interfaces.RSAPublicKey;
import java.util.concurrent.TimeUnit;

@Slf4j
@Service
public class JWKSAuthConfig {

    private static final int SIZE_LIMIT = 100000;

    private final URI jwksUrl;
    private final int jwksConnectTimeout;
    private final int jwksReadTimeout;

    private final CacheLoader<String, RSAPublicKey> cacheLoader = new CacheLoader<>() {
        @Override
        public @Nullable RSAPublicKey load(@NonNull String key) {
            return doGetXidPublicKey();
        }
    };

    private final LoadingCache<String, RSAPublicKey> cache =  Caffeine.newBuilder()
            .refreshAfterWrite(6, TimeUnit.HOURS)
            .maximumSize(1)
            .build(cacheLoader);

    public JWKSAuthConfig(RpConfig rpConfig, OpenIdConfig openIdConfig) {
        this.jwksUrl = openIdConfig.getOpenIdConfig().getJWKSetURI();
        this.jwksConnectTimeout = rpConfig.getXid().getJwksConnectTimeout();
        this.jwksReadTimeout = rpConfig.getXid().getJwksReadTimeout();
        cache.get("authJwks");
    }

    @SneakyThrows
    public RSAPublicKey getXidPublicKey() {
        val result = cache.get("authJwks");
        log.debug("Returning cached authJwks {}", result);
        return result;
    }

    private RSAPublicKey doGetXidPublicKey() {
        try {
            log.debug("Loading {}", jwksUrl);
            val publicKeys = JWKSet.load(jwksUrl.toURL(), jwksConnectTimeout, jwksReadTimeout, SIZE_LIMIT);
            val sigKey = publicKeys.getKeys().stream().
                    filter(keyItem -> keyItem.getKeyUse().identifier().equalsIgnoreCase("sig")).findFirst();

            if (sigKey.isPresent()) {
                log.debug("[sig] key found");
                val keyRSA = sigKey.get().toRSAKey();
                return keyRSA.toRSAPublicKey();
            }

            log.error("JWK [sig] not found from url {}", jwksUrl);
            return null;
        } catch (Exception ex) {
            log.error("Error loading {}: {}", jwksUrl, ex.getMessage());
            return null;
        }
    }
}
