package com.ews.mock.rp.controllers;

import com.ews.mock.rp.config.RpConfig;
import com.ews.mock.rp.models.UserView;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.UriComponentsBuilder;

@Controller
@Slf4j
public class SignUpController {

    private final SignUpResponseUseCase signUpResponseUseCase;
    private final SignUpUseCase signUpUseCase;
    private final RpConfig rpConfig;
    private final OauthUseCase oauthUseCase;

    public SignUpController(SignUpResponseUseCase signUpResponseUseCase,
                            SignUpUseCase signUpUseCase,
                            RpConfig rpConfig,
                            OauthUseCase oauthUseCase) {
        this.signUpResponseUseCase = signUpResponseUseCase;
        this.signUpUseCase = signUpUseCase;
        this.rpConfig = rpConfig;
        this.oauthUseCase = oauthUseCase;
    }

    @GetMapping(value = "/")
    public ModelAndView homePageLoader(
            final @RequestParam(value = "w", required = false) Boolean useWidget) {
        val finalWidgetDecision = useWidget == null ? rpConfig.getBankWidget() : useWidget;
        val modelAndView = new ModelAndView("index.html");
        modelAndView.addObject("bankWidgetURL", rpConfig.getWidgetUrl());
        modelAndView.addObject("bankWidget", finalWidgetDecision);
        return modelAndView;
    }

    @GetMapping(value = "/continue")
    public String continueHandler(final @RequestParam(required = false) String bankId, final Model model) {
        try {
            return "redirect:" + signUpUseCase.handleRequest(bankId, false);
        } catch (Throwable t) {
            log.error("Error handleRequest", t);
            model.addAttribute("errorMsg", t.getMessage());
            return "app-error";
        }
    }

    @GetMapping(value = "/handleAppRedirect")
    public String handleAppRedirect(
            @RequestParam(required = false) final String code,
            @RequestParam(required = false) final String state,
            @RequestParam(required = false) final String error,
            @RequestParam(required = false, value = "error_description") final String errorDescription) {
        val redirectUri = UriComponentsBuilder.fromPath("/completeAppRedirect");
        if (!StringUtils.isBlank(code)) {
            redirectUri.queryParam("code", code);
        }
        if (!StringUtils.isBlank(state)) {
            redirectUri.queryParam("state", state);
        }
        if (!StringUtils.isBlank(error)) {
            redirectUri.queryParam("error", error);
        }
        if (!StringUtils.isBlank(errorDescription)) {
            redirectUri.queryParam("error_description", errorDescription);
        }
        return "redirect:" + redirectUri.build(1);
    }

    @GetMapping(value = "/handleRedirect")
    public String handleRedirect(
            @RequestParam(required = false) final String state,
            @RequestParam(value = "session_state", required = false) final String sessionState,
            @RequestParam(required = false) final String code,
            @RequestParam(required = false) final String error,
            @RequestParam(value = "error_description", required = false) final String errorDescription,
            final Model model) {
        if (StringUtils.equals("access_denied", error)) {
            return "app-error";
        }
        if (StringUtils.equals("user_cancelled", error)) {
            return "redirect:/";
        }
        if (StringUtils.isBlank(code)) {
            return handleError(model, "missing_code", errorDescription);
        }

        model.addAttribute("code", code);
        model.addAttribute("state", state);
        return "wait-information.html";
    }

    @PostMapping(value = "/handleResponse")
    public String handleResponse(@RequestParam final String state,
                                 @RequestParam(required = false) final String code,
                                 final Model model) {
        try {
            val response = oauthUseCase.getUserInfo(state, code);
            return signUpResponseUseCase.handleXidUserInfoResponse(model, UserView.fromBaseIdentity(response));
        } catch (AppErrorException ex) {
            return handleError(model, ex.getError(), ex.getErrorDescription());
        } catch (Throwable t) {
            log.error("Unexpected exception", t);
            return handleError(model, "unknown_error", null);
        }
    }

    private String handleError(@NotNull final Model model,
                               @NotNull final String error,
                               @Nullable final String errorDescription) {
        val errorDescriptionToUse =
                StringUtils.isBlank(errorDescription) ? "An unknown error occurred" : errorDescription;
        log.error("Got error '{}' and errorDescription '{}'", error, errorDescriptionToUse);
        model.addAttribute("errorMsg", errorDescriptionToUse);
        return "app-error";
    }

}