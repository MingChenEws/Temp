package com.ews.mock.rp.controllers;

import com.ews.mock.rp.config.RpConfig;
import com.ews.mock.rp.models.RpSession;
import com.ews.mock.rp.models.UserData;
import com.ews.mock.rp.models.UserView;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.UriComponentsBuilder;

@Controller
@Slf4j
public class SignUpController {

    private final SignUpResponseUseCase signUpResponseUseCase;
    private final SignUpUseCase signUpUseCase;
    private final RpConfig rpConfig;
    private final OauthUseCase oauthUseCase;

    public SignUpController(SignUpResponseUseCase signUpResponseUseCase,
                            SignUpUseCase signUpUseCase,
                            RpConfig rpConfig,
                            OauthUseCase oauthUseCase) {
        this.signUpResponseUseCase = signUpResponseUseCase;
        this.signUpUseCase = signUpUseCase;
        this.rpConfig = rpConfig;
        this.oauthUseCase = oauthUseCase;
    }

    @GetMapping(value = "/")
    public ModelAndView homePageLoader(
            final @RequestParam(value = "w", required = false) Boolean useWidget) {
        val finalWidgetDecision = useWidget == null ? rpConfig.getBankWidget() : useWidget;
        val modelAndView = new ModelAndView("index.html");
        modelAndView.addObject("bankWidgetURL", rpConfig.getWidgetUrl());
        modelAndView.addObject("bankWidget", finalWidgetDecision);
        return modelAndView;
    }

    @GetMapping(value = "/continue")
    public String continueHandler(final @RequestParam(required = false) String initiator, final @RequestParam(required = false) String bankId, final Model model) {
        try {
            log.info(">>> continueHandler: initiator="+initiator);
            return "redirect:" + signUpUseCase.handleRequest(initiator, bankId, false);
        } catch (Throwable t) {
            log.error("Error handleRequest", t);
            model.addAttribute("errorMsg", t.getMessage());
            return "app-error";
        }
    }

    @GetMapping(value = "/continueUserVerification")
    public String continueUserVerificationHandler(final @RequestParam(required = false) String bankId, final @RequestParam(required = false) String phoneNumber, final @RequestParam(required = false) String firstName, final @RequestParam(required = false) String lastName, final @RequestParam(required = false) String birthday, final Model model) {
        try {
            String initiator = "userVerification";
            UserView userDataView = new UserView(firstName, lastName, null, null, null, birthday, null, null, phoneNumber);
            String[] params = signUpUseCase.handleUserVerificationRequest(initiator, bankId, userDataView, false);
            String state = params[0];
            log.info(">>> continueUserVerification: initiator ["+initiator+"] state ["+state+"]");
            model.addAttribute("state", state);
            model.addAttribute("redirectUrl", params[1]);
            return "wait-for-confirmation.html";
            //return "redirect:" + signUpUseCase.handleUserVerificationRequest(initiator, bankId, userDataView, false);
       } catch (Throwable t) {
            log.error("Error handleRequest", t);
            model.addAttribute("errorMsg", t.getMessage());
            return "app-error";
        }
    }

    @GetMapping(value = "/handleAppRedirect")
    public String handleAppRedirect(
            @RequestParam(required = false) final String code,
            @RequestParam(required = false) final String state,
            @RequestParam(required = false) final String error,
            @RequestParam(required = false, value = "error_description") final String errorDescription) {
        val redirectUri = UriComponentsBuilder.fromPath("/completeAppRedirect");
        if (!StringUtils.isBlank(code)) {
            redirectUri.queryParam("code", code);
        }
        if (!StringUtils.isBlank(state)) {
            redirectUri.queryParam("state", state);
        }
        if (!StringUtils.isBlank(error)) {
            redirectUri.queryParam("error", error);
        }
        if (!StringUtils.isBlank(errorDescription)) {
            redirectUri.queryParam("error_description", errorDescription);
        }
        return "redirect:" + redirectUri.build(1);
    }

    @GetMapping(value = "/handleRedirect")
    public String handleRedirect(
            @RequestParam(required = false) final String state,
            @RequestParam(value = "session_state", required = false) final String sessionState,
            @RequestParam(required = false) final String code,
            @RequestParam(required = false) final String error,
            @RequestParam(value = "error_description", required = false) final String errorDescription,
            final Model model) {
        if (StringUtils.equals("access_denied", error)) {
            return "app-error";
        }
        if (StringUtils.equals("user_cancelled", error)) {
            return "redirect:/";
        }
        if (StringUtils.isBlank(code)) {
            return handleError(model, "missing_code", errorDescription);
        }

        RpSession session = oauthUseCase.getSession(state);
        String initiator = session.getInitiator();

        log.info(">>> /handleRedirect::: initiator ["+initiator+"] code ["+code+"] state ["+state+"]");

        if (initiator.equalsIgnoreCase("userVerification")) {
            session.setCode(code);
            return "user-verification-confirmed.html";
        } else {
            model.addAttribute("code", code);
            model.addAttribute("state", state);
            return "wait-information.html";
        }
    }

    @GetMapping(value = "/handleUserVerificationRedirect")
    public String handleUserVerificationRedirect(
            @RequestParam(required = false) final String state,
            @RequestParam(value = "session_state", required = false) final String sessionState,
            @RequestParam(required = false) final String code,
            @RequestParam(required = false) final String error,
            @RequestParam(value = "error_description", required = false) final String errorDescription,
            final Model model) {
        if (StringUtils.equals("access_denied", error)) {
            return "app-error";
        }
        if (StringUtils.equals("user_cancelled", error)) {
            return "redirect:/";
        }
        if (StringUtils.isBlank(code)) {
            return handleError(model, "missing_code", errorDescription);
        }

        model.addAttribute("code", code);
        model.addAttribute("state", state);
        return "wait-information.html";
    }

    @PostMapping(value = "/handleResponse")
    public String handleResponse(@RequestParam final String state,
                                 @RequestParam(required = false) final String code,
                                 final Model model) {
        try {
            log.info(">>> /handleResponse");
            val response = oauthUseCase.getUserInfo(state, code);
            RpSession session = oauthUseCase.getSession(state);
            return signUpResponseUseCase.handleXidUserInfoResponse(model, UserView.fromBaseIdentity(response), session.getUserData(), session.getInitiator());
        } catch (AppErrorException ex) {
            return handleError(model, ex.getError(), ex.getErrorDescription());
        } catch (Throwable t) {
            log.error("Unexpected exception", t);
            return handleError(model, "unknown_error", null);
        }
    }

    @GetMapping(value = "/checkConfirmation")
    public String checkConfirmation(@RequestParam final String state, @RequestParam int duration,
                                    final Model model) {
        log.info(">>> /checkConfirmation state ["+state+"] duration ["+duration+"]");
        try {
            Thread.sleep(10000);
        } catch (Exception e) {

        }
        while(duration > 0) {
            try {
                Thread.sleep(2000);
                RpSession session = oauthUseCase.getSession(state);
                String initiator = session.getInitiator();
                String code = session.getCode();
                if (code == null) {
                    log.info(">>> /checkConfirmation code [NULL] ... continue to wait");
                } else {
                    log.info(">>> /checkConfirmation code [" + code + "]");
                    val redirectUri = UriComponentsBuilder.fromPath("/handleUserVerificationRedirect");
                    redirectUri.queryParam("state", state);
                    redirectUri.queryParam("code", code);
                    return "redirect:" + redirectUri.build(1);
                }
                duration -= 2;
            } catch (AppErrorException ex) {
                return handleError(model, ex.getError(), ex.getErrorDescription());
            } catch (InterruptedException iex) {
                log.error("InterruptedException");
                return null;
            } catch (Throwable t) {
                log.error("Unexpected exception", t);
                return handleError(model, "unknown_error", null);
            }
        }
        return "age-verification-failed.html";
    }

    @GetMapping(value = "/insuranceCo")
    public String insuranceCo(@NotNull final Model model) {
        model.addAttribute("initiator", "insuranceCo");
        return "insurance-co.html";
    }

    @GetMapping(value = "/ageVerification")
    public String ageVerification(@NotNull final Model model) {
        model.addAttribute("initiator", "ageVerification");
        return "age-verification.html";
    }


    @GetMapping(value = "/userVerification")
    public String userVerification(@NotNull final Model model) {
        model.addAttribute("initiator", "userVerification");
        return "user-verification.html";
    }

    @GetMapping(value = "/ageVerificationSuccessful")
    public String ageVerificationSuccessful(@NotNull final Model model) {
        return "age-verification-successful.html";
    }

    @GetMapping(value = "/ageVerificationFailed")
    public String ageVerificationFailed(@NotNull final Model model) {
        return "age-verification-failed.html";
    }

    private String handleError(@NotNull final Model model,
                               @NotNull final String error,
                               @Nullable final String errorDescription) {
        val errorDescriptionToUse =
                StringUtils.isBlank(errorDescription) ? "An unknown error occurred" : errorDescription;
        log.error("Got error '{}' and errorDescription '{}'", error, errorDescriptionToUse);
        model.addAttribute("errorMsg", errorDescriptionToUse);
        return "app-error";
    }

}