package com.ews.mock.rp.models.complete;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Value;

@Value
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Address {
    String country;
    String locality;
    String region;
    @JsonProperty("postal_code")
    String postalCode;
    @JsonProperty("street_address")
    String streetAddress;
    @JsonProperty("street_address2")
    String streetAddress2;
    @JsonProperty("street_address3")
    String streetAddress3;
    String type;
}
