package com.ews.mock.rp.models.complete;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Value;

@Value
@JsonInclude(JsonInclude.Include.NON_NULL)
public class XidCompleteResponse {
    String clientId;
    String clientContext;
    String app;
    String ewSID;
    String replyTo;
    String timestampISO8601;
    String event;
    String statusCode;
    Data data;
}
