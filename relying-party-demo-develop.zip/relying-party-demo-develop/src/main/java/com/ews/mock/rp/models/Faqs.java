package com.ews.mock.rp.models;

import lombok.Value;

import java.util.List;

@Value
public class Faqs {
    List<Faq> faqs;

    @Value
    public static class Faq {
        String question;
        String answer;
    }
}
