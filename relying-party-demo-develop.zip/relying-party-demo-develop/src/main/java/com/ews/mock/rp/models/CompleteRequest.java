package com.ews.mock.rp.models;

import lombok.Value;

@Value
public class CompleteRequest {
    String ewSID;
    String decryptionKeys;
}
