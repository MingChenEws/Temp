package com.ews.mock.rp.controllers;

import com.ews.mock.rp.models.UserView;
import com.ews.mock.rp.models.complete.BaseIdentity;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.val;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.ui.ExtendedModelMap;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ExtendWith(SpringExtension.class)
public class SignUpResponseUseCaseTest {
    @Autowired
    SignUpResponseUseCase signUpResponseUseCase;
    @Autowired
    ObjectMapper objectMapper;

    @Test
    public void handleXidResponse() throws Exception {
        val model = new ExtendedModelMap();
        val is = getClass().getResourceAsStream("/sampleSuccess.json");
        val xidCompleteResponse = objectMapper.readValue(is, BaseIdentity.class);
        assertThat(xidCompleteResponse).isNotNull();
        val userView = UserView.fromBaseIdentity(xidCompleteResponse);
        val response = signUpResponseUseCase.handleXidUserInfoResponse(model, userView, null, null);
        val baseId = (UserView) model.get("userInfo");
        assertThat(baseId.getFirstName()).isEqualTo("Trinity");
        assertThat(baseId.getMiddleName()).isNull();
        assertThat(baseId.getLastName()).isEqualTo("Thompson");
        assertThat(baseId.getBirthdate()).isEqualTo("04/29/1974");
        assertThat(baseId.getPhoneNumber()).isEqualTo("(735) 635-7136");
        assertThat(baseId.getEmail()).isEqualTo("Tara.Smith63@yahoo.com");
        assertThat(baseId.getAddress().getStreetAddress()).isEqualTo("67038 Gaylord Rapid");
        assertThat(baseId.getAddress().getLocality()).isEqualTo("North Ellisshire");
        assertThat(baseId.getAddress().getRegion()).isEqualTo("CA");
        assertThat(baseId.getAddress().getPostalCode()).isEqualTo("21778");
        assertThat(response).isEqualTo("complete.html");
        System.out.println(model.toString());
    }
}
