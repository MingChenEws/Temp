package com.ews.mock.rp.services;

import com.ews.mock.rp.config.OpenIdConfig;
import com.ews.mock.rp.config.RpConfig;
import com.ews.mock.rp.utils.JwtHelper;
import com.nimbusds.openid.connect.sdk.op.OIDCProviderMetadata;
import lombok.val;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.net.URI;
import java.net.URISyntaxException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CreateRedirectUseCaseTest {

    @Test
    void createRedirect_hasCorrectParameters(@Mock JwtHelper jwtHelper) throws URISyntaxException {
        when(jwtHelper.createJWT(eq("qwerty12345678900"),
                eq("rpState"),
                eq("https://relying.party.com/complete"),
                anyString(),
                eq("https://relying.party.com/cancel"),
                eq("theBankId"))).thenReturn("theJWT");

        val rpConfig = mock(RpConfig.class);
        val authConfig = mock(RpConfig.XidConfig.class);
        when(rpConfig.getXid()).thenReturn(authConfig);
        when(rpConfig.getCallbackUrl()).thenReturn("https://relying.party.com");

        val openidConfig = mock(OpenIdConfig.class);
        val openidMetadata = mock(OIDCProviderMetadata.class);
        when(openidMetadata.getAuthorizationEndpointURI()).thenReturn(new URI("https://di-web.com/invAuthorization"));
        when(openidConfig.getOpenIdConfig()).thenReturn(openidMetadata);

        val subject =
                new CreateRedirectUseCase(rpConfig, jwtHelper, openidConfig);

        val url = subject.createRedirectToDiWebAuth("rpState", "/complete", "/cancel",
                "theCoeChallenge", "theBankId");

        assertThat(url).isEqualTo("https://di-web.com/invAuthorization?request=theJWT");
    }
}