package com.ews.mock.rp.utils;

import org.junit.jupiter.api.Test;

import static com.ews.mock.rp.utils.Format.formatDate;
import static com.ews.mock.rp.utils.Format.formatPhone;
import static org.assertj.core.api.Assertions.assertThat;

class FormatTest {

    @Test
    void testFormatPhone() {
        assertThat(formatPhone("+13334445555")).isEqualTo("(333) 444-5555");
        assertThat(formatPhone("3334445555")).isEqualTo("(333) 444-5555");
        assertThat(formatPhone("1-333-444-5555")).isEqualTo("(333) 444-5555");
        assertThat(formatPhone("+1 (333) 444-5555")).isEqualTo("(333) 444-5555");
    }

    @Test
    void testFormatDate() {
        assertThat(formatDate("19990301")).isEqualTo("03/01/1999");
        assertThat(formatDate("19990728")).isEqualTo("07/28/1999");
    }
}