package com.ews.mock.rp.services;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.val;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
@ExtendWith(SpringExtension.class)
class JWKServiceTest {

    @Autowired
    private JWKService subject;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void getJwks() throws IOException {
        val result = subject.getJwks();

        assertNotNull(result);
        assertNotNull(result.getKeys());
        assertNotEquals(result.getKeys().size(), 0);

        val factory = objectMapper.getFactory();
        val jsonString = result.getKeys().get(0).toJSONString();
        System.out.println(jsonString);
        val parser = factory.createParser(jsonString);
        ObjectNode jsonNode = objectMapper.readTree(parser);

        assertThat(jsonNode.get("kty")).isNotNull();
        assertThat(jsonNode.get("e")).isNotNull();
        assertThat(jsonNode.get("n").asText()).isEqualTo(
                "uFHDfxPOffzbcT9GkokW8kgoA7GyoHyBouNB__Y2qsaUu7xwlJuUR-RBv2snNuhbHB_A2WijlBqtLdlG_MkRi5KPWxDdAaPijQn5y0MT9b0P2os2Froh7UcRD2FBDnpZ4gSsAeWs1q9p8lEFMQScygyfMq608NpwtH3brwvqAiIm-qWM-XLiJ92mkbqCeEgMQAArhNyWr58AFiYCS0qxVkmrO3hnUEPkBLOpvwcBrrZ9X1Ne35l5G2GwLUO_KdazROSt8YQVFDRgP-K4yT3Wvg4kKGO8sLxafVexONZRHHctF5Pm7tii-h3GnTxkQvh8DMXNaJgfF-a7qXDJ2MdKMQ");
        assertThat(jsonNode.get("kid")).isNotNull();
    }
}