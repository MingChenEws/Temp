To test /complete locally with fake data

Visit http://localhost:4242/complete?ewSID=blah&decryptionKeys=blah



certmanager.k8s.io/issuer: gitlab-issuer

kubernetes.io/ingress.class: gitlab-nginx

kubernetes.io/ingress.provider: nginx
