#pragma once
#include "CryptoClient.h"
class CCryptoDeviceNonTPM :
	public CCryptoDevice
{
public:
	CCryptoDeviceNonTPM(HWND hw);
	~CCryptoDeviceNonTPM();
	HRESULT hCreateRSAAsymmetricKey(PCWSTR keyType, PCWSTR keyName, PCWSTR usageAuth, DWORD dwKeyUsage);
	HRESULT hCreateAttestationIdentityKey(PCWSTR keyName, PCWSTR usageAuth);
	HRESULT hCreateStorageKey(PCWSTR keyName, PCWSTR usageAuth);
	HRESULT hCreateRelationKey(PCWSTR keyName, PCWSTR usageAuth);
};


