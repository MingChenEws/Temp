
// xFACryptoClientDlg.cpp : implementation file
//

#include "stdafx.h"

#include "CryptoClient.h"

#include "xFACryptoClient.h"
#include "xFACryptoClientDlg.h"
#include "afxdialogex.h"
#include "DialogRelation.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// Ugly but fast
CStringList glErrMsg;

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CxFACryptoClientDlg dialog



CxFACryptoClientDlg::CxFACryptoClientDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CxFACryptoClientDlg::IDD, pParent)
	, mConfigFile(_T(""))
	, mNounce(_T(""))
	, mNounceHashed(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CxFACryptoClientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_CONFIG_FILE, mConfigFile);
	DDX_Text(pDX, IDC_NOUNCE, mNounce);
	DDV_MaxChars(pDX, mNounce, 20);
	DDX_Control(pDX, IDC_TRACEMSG, mTraceMsg);
	DDX_Text(pDX, IDC_HASH_NOUNCE, mNounceHashed);
}

BEGIN_MESSAGE_MAP(CxFACryptoClientDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_MESSAGE(WM_XFA_TRACE_MSG, OnTraceMessage)
	ON_BN_CLICKED(IDC_ENCRYPT, &CxFACryptoClientDlg::OnBnClickedEncrypt)
	ON_BN_CLICKED(IDC_DECRYPT, &CxFACryptoClientDlg::OnBnClickedDecrypt)
	ON_BN_CLICKED(IDC_INIT_CLIENT, &CxFACryptoClientDlg::OnBnClickedInitClient)
	ON_BN_CLICKED(IDC_CREATE_STORAGE_KEY, &CxFACryptoClientDlg::OnBnClickedCreateStorageKey)
	ON_BN_CLICKED(IDC_CREATE_AIK_KEY, &CxFACryptoClientDlg::OnBnClickedCreateAikKey)
	ON_BN_CLICKED(IDC_CREATE_RELATION_KEY, &CxFACryptoClientDlg::OnBnClickedCreateRelationKey)
	ON_BN_CLICKED(IDC_GET_FILE, &CxFACryptoClientDlg::OnBnClickedGetFile)
	ON_BN_CLICKED(IDCANCEL, &CxFACryptoClientDlg::OnBnClickedCancel)
	ON_BN_CLICKED(IDC_SAVE_CONFIG, &CxFACryptoClientDlg::OnBnClickedSaveConfig)
	ON_BN_CLICKED(IDC_SIGN, &CxFACryptoClientDlg::OnBnClickedSign)
	ON_BN_CLICKED(IDC_VERIFY_SIGNATURE, &CxFACryptoClientDlg::OnBnClickedVerifySignature)
	ON_BN_CLICKED(IDC_SHOW_KEYS, &CxFACryptoClientDlg::OnBnClickedShowKeys)
	ON_BN_CLICKED(IDC_DELETE_KEY, &CxFACryptoClientDlg::OnBnClickedDeleteKey)
END_MESSAGE_MAP()


// CxFACryptoClientDlg message handlers

BOOL CxFACryptoClientDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	CRect rect;
	mTraceMsg.GetClientRect(&rect);
	int iWidth = rect.Width();

	mTraceMsg.InsertColumn(0, _T("Trace Message"), 0, iWidth*3);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CxFACryptoClientDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CxFACryptoClientDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CxFACryptoClientDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

LRESULT CxFACryptoClientDlg::OnTraceMessage(WPARAM wParam, LPARAM lParam)
{
	while (!glErrMsg.IsEmpty())
	{
		mTraceMsg.InsertItem(mTraceMsg.GetItemCount(), glErrMsg.GetTail());
		glErrMsg.RemoveTail();
	}
	mTraceMsg.EnsureVisible(mTraceMsg.GetItemCount()-1, FALSE);

	return S_OK;
}

void CxFACryptoClientDlg::OnBnClickedInitClient()
{
	// TODO: Add your control notification handler code here
	mCryptoClient.hwnd = GetActiveWindow()->m_hWnd;
	mCryptoClient.vInitClient();

	GetDlgItem(IDC_CREATE_STORAGE_KEY)->EnableWindow(TRUE);
	GetDlgItem(IDC_CREATE_AIK_KEY)->EnableWindow(TRUE);
	GetDlgItem(IDC_CREATE_RELATION_KEY)->EnableWindow(TRUE);
	GetDlgItem(IDC_SHOW_KEYS)->EnableWindow(TRUE);
	GetDlgItem(IDC_DELETE_KEY)->EnableWindow(TRUE);
	GetDlgItem(IDC_SAVE_CONFIG)->EnableWindow(TRUE);
	GetDlgItem(IDC_ENCRYPT)->EnableWindow(TRUE);
	GetDlgItem(IDC_DECRYPT)->EnableWindow(TRUE);
	GetDlgItem(IDC_SIGN)->EnableWindow(TRUE);
	GetDlgItem(IDC_VERIFY_SIGNATURE)->EnableWindow(TRUE);
}

void CxFACryptoClientDlg::OnBnClickedCreateStorageKey()
{
	// TODO: Add your control notification handler code here
	mCryptoClient.hCreateStorageKey();
}

void CxFACryptoClientDlg::OnBnClickedCreateRelationKey()
{
	// TODO: Add your control notification handler code here
	CString mRelationName;
	int mRelationIndex;

	CDialogRelation dlgRelation(GetActiveWindow(), L"Create", &mRelationName, &mRelationIndex);
	if (dlgRelation.DoModal() == IDOK)
		mCryptoClient.hCreateRelationKey(mRelationName, mRelationIndex);
}

void CxFACryptoClientDlg::OnBnClickedCreateAikKey()
{
	// TODO: Add your control notification handler code here
	mCryptoClient.hCreateAttestationIdentityKey();
}

void CxFACryptoClientDlg::OnBnClickedEncrypt()
{
	// TODO: Add your control notification handler code here
	mCryptoClient.bEncryptCfgData(mConfigFile);
}

void CxFACryptoClientDlg::OnBnClickedDecrypt()
{
	// TODO: Add your control notification handler code here
	mCryptoClient.bDecryptCfgData(mConfigFile);
}


#define CFGFILEPATH L"C:\\Authentify\\Work\\TPM\\Sample Codes\\xFACryptoClient\\xFA.cfg"

void CxFACryptoClientDlg::OnBnClickedGetFile()
{
	// TODO: Add your control notification handler code here
	{
		CFileDialog dlg(TRUE);

		dlg.m_ofn.lpstrInitialDir = CFGFILEPATH;
		dlg.m_ofn.lpstrFilter = L"CFG Files (*.cfg)\0*.cfg\0Text Files (*.txt)\0*.txt\0All Files (*.*)\0*.*\0\0";
		dlg.m_ofn.lpstrTitle = L"Select xFA Configuration Data File";

		if (dlg.DoModal() == IDOK)
		{
			mConfigFile = dlg.GetPathName(); // return full path and filename
			UpdateData(FALSE);
		}
	}
}

void CxFACryptoClientDlg::OnBnClickedSaveConfig()
{
	// TODO: Add your control notification handler code here
	mCryptoClient.bSaveCfgData(mConfigFile);

}

void CxFACryptoClientDlg::OnBnClickedCancel()
{
	// TODO: Add your control notification handler code here
	CDialogEx::OnCancel();
}


void CxFACryptoClientDlg::OnBnClickedSign()
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	mCryptoClient.bCreateSignature(mNounce);
	mNounceHashed = L"";
	for (int i = 0; i < SHA1_DIGEST_SIZE; i++)
		mNounceHashed.AppendFormat(L"%02X", mCryptoClient.nounceHashed[i]);
	UpdateData(FALSE);
}


void CxFACryptoClientDlg::OnBnClickedVerifySignature()
{
	// TODO: Add your control notification handler code here
	mCryptoClient.bVerifySignature(mNounce);
}


void CxFACryptoClientDlg::OnBnClickedShowKeys()
{
	// TODO: Add your control notification handler code here
	mCryptoClient.vShowKeys();
}


void CxFACryptoClientDlg::OnBnClickedDeleteKey()
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	if (!mNounce.IsEmpty())
	{
		CString msg;

		msg.Format(L"Delete \"%s\" Key in the \"Request:\" filed?", mNounce);
		MessageBox(msg, L"Delete Key", MB_YESNO);
	}
	else
	{
		MessageBox(L"Enter Key Name in the \"Request:\" filed", L"Delete Key", 0);
	}

	mCryptoClient.bDeleteKey(mNounce.GetString());
}
