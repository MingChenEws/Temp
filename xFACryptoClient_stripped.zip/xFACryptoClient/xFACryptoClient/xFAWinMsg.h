#define WM_XFA_TRACE_MSG	WM_APP + 0xF00
#define DISPLAY_TRACE()    PostMessage(hwnd, WM_XFA_TRACE_MSG, NULL, NULL)

#define SHA1_DIGEST_SIZE 20
#define CFGDATASIZE 4096
//#define RSA_BLOCK_SIZE 128 // Non-TPM
//#define RSA_BLOCK_SIZE 256 // TPM

