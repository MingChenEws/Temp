
// xFACryptoClientDlg.h : header file
//

#pragma once

#include "CryptoClient.h"
#include "xFAWinMsg.h"
#include "afxwin.h"
#include "afxcmn.h"

// CxFACryptoClientDlg dialog
class CxFACryptoClientDlg : public CDialogEx
{
// Construction
public:
	CxFACryptoClientDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_XFACRYPTOCLIENT_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg LRESULT OnTraceMessage(WPARAM wParam, LPARAM lParam);

	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

public:
	CCryptoClient mCryptoClient;
	CListCtrl mTraceMsg;
	CString mConfigFile;
	CString mNounce;

	afx_msg void OnBnClickedEncrypt();
	afx_msg void OnBnClickedDecrypt();
	afx_msg void OnBnClickedInitClient();
	afx_msg void OnBnClickedCreateStorageKey();
	afx_msg void OnBnClickedCreateAikKey();
	afx_msg void OnBnClickedCreateRelationKey();
	afx_msg void OnBnClickedGetFile();
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedSaveConfig();
	CString mNounceHashed;
	afx_msg void OnBnClickedSign();
	afx_msg void OnBnClickedVerifySignature();
	afx_msg void OnBnClickedShowKeys();
	afx_msg void OnBnClickedDeleteKey();
};
