#include "stdafx.h"

#include "xFAWinMsg.h"
#include "CryptoDevice.h"
#include <bcrypt.h>
#include <ncrypt.h>
#include "InlineFn.h"
#include <Iphlpapi.h>

#pragma comment(lib, "iphlpapi.lib")

// Global hash handles are kept open for performance reasons
BCRYPT_ALG_HANDLE g_hSHA1HashAlg = NULL;
BCRYPT_ALG_HANDLE g_hSHA1HmacAlg = NULL;
BCRYPT_ALG_HANDLE g_hSHA256HashAlg = NULL;
BCRYPT_ALG_HANDLE g_hSHA256HmacAlg = NULL;
BCRYPT_ALG_HANDLE g_hSHA384HashAlg = NULL;
BCRYPT_ALG_HANDLE g_hSHA384HmacAlg = NULL;

#ifndef STATUS_SUCCESS
#define STATUS_SUCCESS                  ((NTSTATUS)0x00000000L)
#define STATUS_UNSUCCESSFUL             ((NTSTATUS)0xC0000001L)
#endif

// Ugly but fast
extern CStringList glErrMsg;

bool CCryptoDevice::bGetUniqDeviceIdentity()
{
	// Get Primary MAC Address from Window
	bool bRet = FALSE;
	PIP_ADAPTER_INFO AdapterInfo = NULL;
	DWORD dwBufLen = 0;
	PIP_ADAPTER_INFO pPrimaryAdapterInfo = NULL;
	UINT iPrimaryAdapterIdx = 0xFFFFFFFF;


	// Make an initial call to GetAdaptersInfo to get the necessary size into the dwBufLen variable
	if (GetAdaptersInfo(NULL, &dwBufLen) == ERROR_BUFFER_OVERFLOW) {
		if (dwBufLen > (10 * sizeof(IP_ADAPTER_INFO)))
			return FALSE;

		AdapterInfo = (IP_ADAPTER_INFO *)new(std::nothrow) char[dwBufLen];
		if (AdapterInfo == NULL)
		{
			return FALSE;
		}
	}

	if (GetAdaptersInfo(AdapterInfo, &dwBufLen) == NO_ERROR) {
		PIP_ADAPTER_INFO pAdapter = AdapterInfo;// Contains pointer to current adapter info
		while (pAdapter)
		{
			// Primary Adapter has the smallest Index
			if (pAdapter->Index < iPrimaryAdapterIdx)
			{
				iPrimaryAdapterIdx = pAdapter->Index;
				pPrimaryAdapterInfo = pAdapter;
			}
			pAdapter = pAdapter->Next;
		};
	}

	if (pPrimaryAdapterInfo)
	{
		for (UINT i = 0; i < pPrimaryAdapterInfo->AddressLength; i++)
		{
			UDID.AppendFormat(L"%02X", (int)pPrimaryAdapterInfo->Address[i]);
		}
		bRet = TRUE;
	}
	glErrMsg.AddHead(UDID.GetString());
	DISPLAY_TRACE();

	if (AdapterInfo)
		delete(AdapterInfo);

	return bRet;
}

HRESULT CCryptoDevice::hCreateStorageKey(PCWSTR keyName, PCWSTR usageAuth)
{
	return S_OK;
}

HRESULT CCryptoDevice::hCreateAttestationIdentityKey(PCWSTR keyName, PCWSTR usageAuth)
{
	return S_OK;
}

HRESULT CCryptoDevice::hCreateRelationKey(PCWSTR keyName, PCWSTR usageAuth)
{
	return S_OK;
}

bool CCryptoDevice::bDeleteKey(PCWSTR keyName)
/*++
Delete a user key from the PCP storage.
--*/
{
	HRESULT hr = S_OK;
	NCRYPT_PROV_HANDLE hProv = NULL;
	NCRYPT_KEY_HANDLE hKey = NULL;

	// Open the key
	if (FAILED(hr = (NCryptOpenStorageProvider(
		&hProv, strKeyProvider,

		0))))
	{
		goto Cleanup;
	}

	if (FAILED(hr = (NCryptOpenKey(
		hProv,
		&hKey,
		keyName,
		0,
		0))))
	{
		goto Cleanup;
	}

	// Delete the key
	if (FAILED(hr = (NCryptDeleteKey(hKey, 0))))
	{
		goto Cleanup;
	}
	hKey = NULL;

	errMsg.Format(L"\"%s\" Key Deleted!!!", keyName);
	DISPLAY_TRACE();

Cleanup:
	if (hKey != NULL)
	{
		NCryptFreeObject(hKey);
		hKey = NULL;
	}
	if (hProv != NULL)
	{
		NCryptFreeObject(hProv);
		hProv = NULL;
	}

	vHelperResult(L"bDeleteKey()", hr);

	return SUCCEEDED(hr) ? TRUE : FALSE;
}

bool CCryptoDevice::bEncryptBlob(PCWSTR keyName, PCWSTR usageAuth, PCWSTR cfgFile)
{
	BYTE cfgData[CFGDATASIZE];
	UINT32 cfgDataLen = CFGDATASIZE;

	memset(cfgData, 0, cfgDataLen);
	HelperReadFile(cfgFile, cfgData, cfgDataLen, &cfgDataLen);
	if (cfgDataLen == 0)
		return FALSE;

	errMsg.Format(L"Cfg Data Read (%d)", cfgDataLen);
	DISPLAY_TRACE();

	return(bEncryptBlob(keyName, usageAuth, cfgFile, cfgData, cfgDataLen));
}

bool CCryptoDevice::bEncryptBlob(PCWSTR keyName, PCWSTR usageAuth, PCWSTR cfgFile, PBYTE cfgData, UINT32 cfgDataLen)
{
	HRESULT hr = S_OK;
	NCRYPT_PROV_HANDLE hProv = NULL;
	NCRYPT_KEY_HANDLE hKey = NULL;
	int encBlockSize = 0;
	int readBlockSize = 0;
	UINT32 cbBlob = 0;
//	PBYTE pbBlob = NULL;
	CString encryptFileName;
	CFile	oFileToCrypt;

	// Open key
	if (FAILED(hr = HRESULT_FROM_WIN32(NCryptOpenStorageProvider(
		&hProv, strKeyProvider,
		0))))
	{
		goto Cleanup;
	}

	if (FAILED(hr = HRESULT_FROM_WIN32(NCryptOpenKey(
		hProv,
		&hKey,
		keyName,
		0,
		(usageAuth != 0) ? NCRYPT_SILENT_FLAG : 0))))
	{
		goto Cleanup;
	}

	if ((usageAuth != NULL) && (wcslen(usageAuth) != 0))
	{
		if (FAILED(hr = HRESULT_FROM_WIN32(NCryptSetProperty(
			hKey,
			NCRYPT_PIN_PROPERTY,
			(PBYTE)usageAuth,
			(DWORD)((wcslen(usageAuth) + 1) * sizeof(WCHAR)),
			0))))
		{
			eMsg.Format(L"");
			// goto Cleanup;  // MS_KEY_STORAGE_PROVIDER not supported
		}
	}

	if (FAILED(hr = HRESULT_FROM_WIN32(NCryptGetProperty(
		hKey,
		strBlockLengthProperty,           // TPM and Non-TPM use diffenert property string
		(PBYTE)&encBlockSize,
		sizeof(encBlockSize),
		(DWORD *)&cbBlob,
		0))))
	{
		encBlockSize = RSABlockSize;  // Not sure why it failed here
	}

	PBYTE pbBlob = NULL;
	if (FAILED(hr = AllocateAndZero((PVOID*)&pbBlob, encBlockSize * 2))) // get extra space for encryption
	{
		goto Cleanup;
	}

	readBlockSize = encBlockSize - sizeof(DWORD)*NoOfWordsForPadding;  // Output block size - padding needs

	encryptFileName.Format(L"%s.enc", cfgFile);
	if (oFileToCrypt.Open(encryptFileName, CFile::modeWrite | CFile::shareExclusive | CFile::modeCreate) == FALSE)
	{
		errMsg.Format(_T("Error opening the file '%s'"), encryptFileName);
		goto Cleanup;
	}

	UINT32 rSize = 0, wSize=0;
	DWORD dwFlag = 0;
	for (int bufIdx = 0, remainedSize = cfgDataLen; remainedSize > 0; bufIdx += readBlockSize, remainedSize -= readBlockSize)
	{
		// Somehow both TPM and Non-TPM RSA Algorithm always need padding; therefore,
		// the readBlockSize is always smaller than encBlockSize property,
		// so dwFalg is always set to NCRYPT_PAD_PKCS1_FLAG
		if (remainedSize > readBlockSize)
		{
			rSize = readBlockSize;
			dwFlag = NCRYPT_PAD_PKCS1_FLAG;
		}
		else
		{
			rSize = remainedSize;
			dwFlag = NCRYPT_PAD_PKCS1_FLAG;
		}

		if (FAILED(hr = HRESULT_FROM_NT(NCryptEncrypt(
			hKey,
			(PBYTE)&cfgData[bufIdx],
			(DWORD)rSize,
			NULL,
			NULL,
			0,
			(PULONG)&cbBlob,
			dwFlag))))
		{
			goto Cleanup;
		}

		if (FAILED(hr = HRESULT_FROM_NT(NCryptEncrypt(
			hKey,
			(PBYTE)&cfgData[bufIdx],
			(DWORD)rSize,
			NULL,
			pbBlob,
			cbBlob,
			(PULONG)&cbBlob,
			dwFlag))))
		{
			goto Cleanup;
		}
		oFileToCrypt.Write(pbBlob, cbBlob);
		wSize += cbBlob;
	}

	errMsg.Format(L"Encrypted Data (%d)", wSize);
	DISPLAY_TRACE();

Cleanup:
	if (hKey != NULL)
	{
		NCryptFreeObject(hKey);
		hKey = NULL;
	}
	if (hProv != NULL)
	{
		NCryptFreeObject(hProv);
		hProv = NULL;
	}

	if (oFileToCrypt != CFile::hFileNull)
		oFileToCrypt.Close();

	ZeroAndFree((PVOID*)&pbBlob, encBlockSize * 2);
	vHelperResult(L"bEncryptBlob()", hr);
	
	return SUCCEEDED(hr) ? TRUE : FALSE;
}

bool CCryptoDevice::bDecryptBlob(PCWSTR keyName, PCWSTR usageAuth, PCWSTR cfgFile, PBYTE cfgData, UINT32 cfgDataLen)
{
	HRESULT hr = S_OK;
	CFile oFileToOpen;
	CFile oFileToCrypt;
	NCRYPT_PROV_HANDLE hProv = NULL;
	NCRYPT_KEY_HANDLE hKey = NULL;


	int rSize = 0;
	PBYTE	pbufFileToOpen;
	PBYTE	pbufFileToSave;

	DWORD readBlockSize = 0;

	CString encryptFileName;
	CString decryptFileName;

	encryptFileName.Format(L"%s.enc", cfgFile);
	if (oFileToOpen.Open(encryptFileName, CFile::modeRead | CFile::typeBinary) == FALSE)
	{
		errMsg.Format(_T("Error opening the file '%s'"), encryptFileName);
		goto Cleanup;;
	}

	decryptFileName.Format(L"%s.dec", cfgFile);
	if (oFileToCrypt.Open(decryptFileName, CFile::modeWrite | CFile::shareExclusive | CFile::modeCreate) == FALSE)
	{
		errMsg.Format(_T("Error opening the file '%s'"), decryptFileName);
		goto Cleanup;;
	}

	errMsg.Format(L"Encrypted Data (%d)", oFileToOpen.GetLength());
	DISPLAY_TRACE();

	// Open key
	if (FAILED(hr = HRESULT_FROM_WIN32(NCryptOpenStorageProvider(
		&hProv, strKeyProvider,
		0))))
	{
		goto Cleanup;
	}

	if (FAILED(hr = HRESULT_FROM_WIN32(NCryptOpenKey(
		hProv,
		&hKey,
		keyName,
		0,
		(usageAuth != 0) ? NCRYPT_SILENT_FLAG : 0))))
	{
		goto Cleanup;
	}

	if ((usageAuth != NULL) && (wcslen(usageAuth) != 0))
	{
		if (FAILED(hr = HRESULT_FROM_WIN32(NCryptSetProperty(
			hKey,
			NCRYPT_PIN_PROPERTY,
			(PBYTE)usageAuth,
			(DWORD)((wcslen(usageAuth) + 1) * sizeof(WCHAR)),
			0))))
		{
			eMsg.Format(L"");
			// goto Cleanup;  // MS_KEY_STORAGE_PROVIDER not supported
		}
	}
	
	if (FAILED(hr = HRESULT_FROM_WIN32(NCryptGetProperty(
		hKey,
//		NCRYPT_BLOCK_LENGTH_PROPERTY,
		strBlockLengthProperty,           // TPM and Non-TPM use diffenert property string
		(PBYTE)&readBlockSize,
		sizeof(readBlockSize),
		(DWORD *)&rSize,
		0))))
	{
		readBlockSize = RSABlockSize;  // Not sure why it failed here
	}

	// Read buffer
	if (FAILED(hr = AllocateAndZero((PVOID*)&pbufFileToOpen, readBlockSize)))
	{
		goto Cleanup;
	}
	//Write Buffer
	if (FAILED(hr = AllocateAndZero((PVOID*)&pbufFileToSave, readBlockSize)))
	{
		goto Cleanup;
	}

	int remainedSize = (int) oFileToOpen.GetLength();
	DWORD dqFlag = 0;
	for (int readSize = 0, cbSize = 0; readSize < remainedSize;)
	{
		rSize = oFileToOpen.Read(pbufFileToOpen, readBlockSize);
		readSize += rSize;

		if (FAILED(hr = HRESULT_FROM_WIN32(NCryptDecrypt(
			hKey,
			pbufFileToOpen,
			rSize,
			NULL,
			NULL,
			0,
			(PDWORD)&cbSize,
			NCRYPT_PAD_PKCS1_FLAG))))
		{
			goto Cleanup;
		}

		if (FAILED(hr = HRESULT_FROM_WIN32(NCryptDecrypt(
			hKey,
			pbufFileToOpen,
			rSize,
			NULL,
			pbufFileToSave,
			cbSize,
			(PDWORD)&cbSize,
			NCRYPT_PAD_PKCS1_FLAG))))
		{
			goto Cleanup;
		}

		oFileToCrypt.Write(pbufFileToSave, cbSize);
	}

	errMsg.Format(L"Decrypted Data (%d)", oFileToCrypt.GetLength());
	DISPLAY_TRACE();

	if (oFileToCrypt != CFile::hFileNull)
	{
		oFileToCrypt.Close();
	}
	HelperReadFile(decryptFileName.GetString(), cfgData, CFGDATASIZE, &cfgDataLen);
	cfgData[cfgDataLen] = 0;

Cleanup:
	if (hKey != NULL)
	{
		NCryptFreeObject(hKey);
		hKey = NULL;
	}
	if (hProv != NULL)
	{
		NCryptFreeObject(hProv);
		hProv = NULL;
	}

	ZeroAndFree((PVOID*)&pbufFileToOpen, readBlockSize);
	ZeroAndFree((PVOID*)&pbufFileToSave, readBlockSize);

	if (oFileToOpen != CFile::hFileNull)
		oFileToOpen.Close();
	if (oFileToCrypt != CFile::hFileNull)
		oFileToCrypt.Close();
	vHelperResult(L"bDecryptBlob()", hr);

	return SUCCEEDED(hr) ? TRUE : FALSE;
}


void CCryptoDevice::vHelperResult(_In_ WCHAR* func, HRESULT hr)
{
	PWSTR Buffer = NULL;
	DWORD result = 0;

	if (FAILED(hr))
	{
		result = FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER |
			FORMAT_MESSAGE_FROM_SYSTEM |
			FORMAT_MESSAGE_IGNORE_INSERTS,
			(PVOID)GetModuleHandle(NULL),
			hr,
			MAKELANGID(LANG_NEUTRAL, SUBLANG_NEUTRAL),
			(PTSTR)&Buffer,
			0,
			NULL);

		if (result != 0)
		{
			errMsg.Format(L"ERROR - %s: (0x%08lx) %s", func, hr, Buffer);
			LocalFree(Buffer);
		}
		else
		{
			errMsg.Format(L"ERROR - %s: (0x%08lx)", func, hr);
		}

		DISPLAY_TRACE();
	}
}

HRESULT CCryptoDevice::hHelperDisplayKey(_In_ PCWSTR lpKeyName, _In_reads_(cbKey) PBYTE pbKey, DWORD cbKey)
{
	HRESULT hr = S_OK;
	BCRYPT_RSAKEY_BLOB* pKey = (BCRYPT_RSAKEY_BLOB*)pbKey;
	BYTE pubKeyDigest[SHA1_DIGEST_SIZE] = { 0 };
	UINT32 cbRequired = 0;

	// Parameter check
	if ((pbKey == NULL) ||
		(cbKey < sizeof(BCRYPT_RSAKEY_BLOB)) ||
		(cbKey < (sizeof(BCRYPT_RSAKEY_BLOB) +
		pKey->cbPublicExp +
		pKey->cbModulus +
		pKey->cbPrime1 +
		pKey->cbPrime2)))
	{
		hr = E_INVALIDARG;
		goto Cleanup;
	}

	if (FAILED(hr = hHelperShaHash(BCRYPT_SHA1_ALGORITHM,
		NULL,
		0,
		&pbKey[sizeof(BCRYPT_RSAKEY_BLOB) +
		pKey->cbPublicExp],
		pKey->cbModulus,
		pubKeyDigest,
		sizeof(pubKeyDigest),
		&cbRequired)))
	{
		hr = E_INVALIDARG;
		goto Cleanup;
	}

	eMsg.Format(L"  <RSAKey size=\"%u\"", cbKey);
	if ((lpKeyName != NULL) &&
		(wcslen(lpKeyName) != 0))
	{
		eMsg.AppendFormat(L" keyName=\"%s\"", lpKeyName);
	}
	errMsg.Format(L"%s", eMsg);

	errMsg.Format(L"    <Magic>%c%c%c%c<!-- 0x%08x --></Magic>",
		((PBYTE)&pKey->Magic)[0],
		((PBYTE)&pKey->Magic)[1],
		((PBYTE)&pKey->Magic)[2],
		((PBYTE)&pKey->Magic)[3],
		pKey->Magic);

	errMsg.Format(L"    <BitLength>%u</BitLength>", pKey->BitLength);
	errMsg.Format(L"    <PublicExp size=\"%u\">", pKey->cbPublicExp);

	eMsg = L"      ";
	for (UINT32 n = 0; n < pKey->cbPublicExp; n++)
	{
		eMsg.AppendFormat(L"%02x", pbKey[sizeof(BCRYPT_RSAKEY_BLOB) + n]);
	}
	errMsg.Format(L"%s", eMsg);

	errMsg.Format(L"    </PublicExp>");

	eMsg.Format(L"    <Modulus size=\"%u\" digest=\"", pKey->cbModulus);
	for (UINT32 n = 0; n < sizeof(pubKeyDigest); n++)
	{
		eMsg.AppendFormat(L"%02x", pubKeyDigest[n]);
	}
	errMsg.Format(L"%s\">", eMsg);

	eMsg = L"      ";
	for (UINT32 n = 0; n < pKey->cbModulus; n++)
	{
		eMsg.AppendFormat(L"%02x", pbKey[sizeof(BCRYPT_RSAKEY_BLOB) +
			pKey->cbPublicExp +
			n]);
	}
	errMsg.Format(L"%s", eMsg);

	errMsg.Format(L"    </Modulus>");

	if (pKey->cbPrime1 == 0)
	{
		errMsg.Format(L"    <Prime1/>\n");
	}
	else
	{
		errMsg.Format(L"    <Prime1 size=\"%u\">", pKey->cbPrime1);
		eMsg = L"      ";
		for (UINT32 n = 0; n < pKey->cbPrime1; n++)
		{
			eMsg.AppendFormat(L"%02x", pbKey[sizeof(BCRYPT_RSAKEY_BLOB) +
				pKey->cbPublicExp +
				pKey->cbModulus +
				n]);
		}
		errMsg.Format(L"%s", eMsg);
		errMsg.Format(L"    </Prime1>");
	}

	if (pKey->cbPrime2 == 0)
	{
		errMsg.Format(L"    <Prime2/>");
	}
	else
	{
		errMsg.Format(L"     <Prime2 size=\"%u\">", pKey->cbPrime2);
		eMsg = L"      ";
		for (UINT32 n = 0; n < pKey->cbPrime2; n++)
		{
			eMsg.AppendFormat(L"%02x", pbKey[sizeof(BCRYPT_RSAKEY_BLOB) +
				pKey->cbPublicExp +
				pKey->cbModulus +
				pKey->cbPrime1 +
				n]);
		}
		errMsg.Format(L"%s", eMsg);

		errMsg.Format(L"    </Prime2>");
	}

	errMsg.Format(L"  </RSAKey>");

Cleanup:
	return hr;
}


HRESULT CCryptoDevice::hHelperShaHash(LPCWSTR pszAlgId, _In_reads_opt_(cbKey) PBYTE pbKey, UINT32 cbKey, _In_reads_(cbData) PBYTE pbData,
	                                  UINT32 cbData, _Out_writes_to_opt_(cbResult, *pcbResult) PBYTE pbResult, UINT32 cbResult, _Out_ PUINT32 pcbResult)
{
	HRESULT hr = S_OK;
	BCRYPT_ALG_HANDLE* phAlg = NULL;
	BCRYPT_ALG_HANDLE  hTempAlg = NULL;
	BCRYPT_HASH_HANDLE hHash = NULL;
	DWORD dwFlags = 0;
	DWORD hashSize = 0;
	DWORD cbHashSize = 0;

	if ((cbKey == 0) || (pbKey == NULL))
	{
		if (wcscmp(pszAlgId, BCRYPT_SHA1_ALGORITHM) == 0)
		{
			phAlg = &g_hSHA1HashAlg;
		}
		else if (wcscmp(pszAlgId, BCRYPT_SHA256_ALGORITHM) == 0)
		{
			phAlg = &g_hSHA256HashAlg;
		}
		else if (wcscmp(pszAlgId, BCRYPT_SHA384_ALGORITHM) == 0)
		{
			phAlg = &g_hSHA384HashAlg;
		}
		else
		{
			hr = E_INVALIDARG;
			goto Cleanup;
		}
	}
	else
	{
		if (wcscmp(pszAlgId, BCRYPT_SHA1_ALGORITHM) == 0)
		{
			phAlg = &g_hSHA1HmacAlg;
		}
		else if (wcscmp(pszAlgId, BCRYPT_SHA256_ALGORITHM) == 0)
		{
			phAlg = &g_hSHA256HmacAlg;
		}
		else if (wcscmp(pszAlgId, BCRYPT_SHA384_ALGORITHM) == 0)
		{
			phAlg = &g_hSHA384HmacAlg;
		}
		else
		{
			hr = E_INVALIDARG;
			goto Cleanup;
		}
		dwFlags = BCRYPT_ALG_HANDLE_HMAC_FLAG;
	}

	// Open the provider if not already open
	if (*phAlg == NULL)
	{
		if (FAILED(hr = HRESULT_FROM_NT(BCryptOpenAlgorithmProvider(
			&hTempAlg,
			pszAlgId,
			MS_PRIMITIVE_PROVIDER, // Use MS Primitive Provider
			dwFlags))))
		{
			goto Cleanup;
		}
		if (InterlockedCompareExchangePointer((volatile PVOID *)phAlg, (PVOID)hTempAlg, NULL) != NULL)
		{
			BCryptCloseAlgorithmProvider(hTempAlg, 0);
		}
	}

	// Check output buffer size
	if (FAILED(hr = HRESULT_FROM_NT(BCryptGetProperty(
		*phAlg,
		BCRYPT_HASH_LENGTH,
		(PUCHAR)&hashSize,
		sizeof(hashSize),
		&cbHashSize,
		0))))
	{
		goto Cleanup;
	}

	// Size check?
	if ((pbResult == NULL) || (cbResult == 0))
	{
		*pcbResult = hashSize;
		goto Cleanup;
	}
	else if (cbResult < hashSize)
	{
		hr = HRESULT_FROM_WIN32(ERROR_INSUFFICIENT_BUFFER);
		*pcbResult = hashSize;
		goto Cleanup;
	}

	// Create the hash
	if (FAILED(hr = HRESULT_FROM_NT(BCryptCreateHash(
		*phAlg,
		&hHash,
		NULL,
		0,
		pbKey,
		(ULONG)cbKey,
		0))))
	{
		goto Cleanup;
	}

	// Hash the data
	if (FAILED(hr = HRESULT_FROM_NT(BCryptHashData(
		hHash,
		pbData,
		(ULONG)cbData,
		0))))
	{
		goto Cleanup;
	}

	// Calculate the digesst
	if (FAILED(hr = HRESULT_FROM_NT(BCryptFinishHash(
		hHash,
		pbResult,
		(ULONG)cbResult,
		0))))
	{
		goto Cleanup;
	}
	*pcbResult = hashSize;

Cleanup:
	if (hHash != NULL)
	{
		BCryptDestroyHash(hHash);
		hHash = NULL;
	}
	return hr;
}
/*++
Retrieve the version strings from the PCP provider and the TPM.
--*/
HRESULT CCryptoDevice::hHelperGetTPMReadyState()
{
	HRESULT hr = S_OK;
	BCRYPT_ALG_HANDLE hAlg = NULL;

	if (FAILED(hr = HRESULT_FROM_NT(BCryptOpenAlgorithmProvider(
		&hAlg,
		BCRYPT_RNG_ALGORITHM,
		MS_PLATFORM_CRYPTO_PROVIDER,
		0))))
	{
		goto Cleanup;
	}

	WCHAR versionData[256] = L"";
	DWORD cbData = 0;

	ZeroMemory(versionData, sizeof(versionData));

	if (FAILED(hr = HRESULT_FROM_NT(BCryptGetProperty(
		hAlg,
		BCRYPT_PCP_PROVIDER_VERSION_PROPERTY,
		(PUCHAR)versionData,
		sizeof(versionData) - sizeof(WCHAR),
		&cbData,
		0))))
	{
		goto Cleanup;
	}

	if (cbData > sizeof(versionData) - sizeof(WCHAR))
	{
		hr = HRESULT_FROM_WIN32(ERROR_INVALID_DATA);
		goto Cleanup;
	}
	versionData[cbData / sizeof(WCHAR)] = 0x0000;

	errMsg.Format(L"<Version>");
	errMsg.Format(L"  <Provider>%s</Provider>", versionData);

	if (FAILED(hr = HRESULT_FROM_NT(BCryptGetProperty(
		hAlg,
		BCRYPT_PCP_PLATFORM_TYPE_PROPERTY,
		(PUCHAR)versionData,
		sizeof(versionData) - sizeof(WCHAR),
		&cbData,
		0))))
	{
		goto Cleanup;
	}

	if (cbData > sizeof(versionData) - sizeof(WCHAR))
	{
		hr = HRESULT_FROM_WIN32(ERROR_INVALID_DATA);
		goto Cleanup;
	}

	versionData[cbData / sizeof(WCHAR)] = 0x0000;

	errMsg.Format(L"  <TPM>");
	errMsg.Format(L"    %s", versionData);
	errMsg.Format(L"  </TPM>");
	errMsg.Format(L"</Version>");

	DISPLAY_TRACE();

Cleanup:
	if (hAlg != NULL)
	{
		BCryptCloseAlgorithmProvider(hAlg, 0);
		hAlg = NULL;
	}

	vHelperResult(L"hGetTPMReadyState()", hr);
	return hr;
}

bool CCryptoDevice::EnumProviders(CStringList *lstRegisteredProviders)
{
	NTSTATUS ntStatus = STATUS_UNSUCCESSFUL;
	DWORD cbBuffer = 0;
	PCRYPT_PROVIDERS pProviders = NULL;
	ntStatus = BCryptEnumRegisteredProviders(&cbBuffer, &pProviders);
	CString sProvider;
	if (ntStatus != STATUS_SUCCESS)
	{
		errMsg.Format(_T("BCryptEnumRegisteredProviders failed with error code 0x%08x"), ntStatus);
		return false;
	}
	if (pProviders == NULL)
	{
		errMsg.Format(_T("BCryptEnumRegisteredProviders returned a NULL"));
		return false;
	}
	else
	{
		for (DWORD i = 0; i < pProviders->cProviders; i++)
		{
			sProvider.Format(_T("%s\n"), pProviders->rgpszProviders[i]);
			lstRegisteredProviders->AddHead(sProvider);
		}
	}

	if (pProviders != NULL)
	{
		BCryptFreeBuffer(pProviders);
	}
	return true;
}

HRESULT CCryptoDevice::HelperWriteFile(_In_ PCWSTR lpFileName,_In_reads_opt_(cbData) PBYTE pbData,UINT32 cbData)
{
	HRESULT hr = S_OK;
	HANDLE hFile = INVALID_HANDLE_VALUE;
	DWORD bytesWritten = 0;

	hFile = CreateFileW(
		lpFileName,
		GENERIC_WRITE,
		0,
		NULL,
		CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL,
		0);
	if (hFile == INVALID_HANDLE_VALUE)
	{
		hr = HRESULT_FROM_WIN32(GetLastError());
		goto Cleanup;
	}


	while (cbData > bytesWritten)
	{
		DWORD bytesWrittenLast = 0;
		if (!WriteFile(hFile,
			&pbData[bytesWritten],
			(DWORD)(cbData - bytesWritten),
			&bytesWrittenLast,
			NULL))
		{
			hr = HRESULT_FROM_WIN32(GetLastError());
			goto Cleanup;
		}
		bytesWritten += bytesWrittenLast;
	}

Cleanup:
	if (hFile != INVALID_HANDLE_VALUE)
	{
		CloseHandle(hFile);
		hFile = INVALID_HANDLE_VALUE;
	}
	return hr;
}

HRESULT CCryptoDevice::HelperReadFile(_In_ PCWSTR lpFileName, _In_reads_opt_(cbData) PBYTE pbData, UINT32 cbData, __out PUINT32 pcbData)
{
	HRESULT hr = S_OK;
	HANDLE hFile = INVALID_HANDLE_VALUE;
	LARGE_INTEGER dataSize = { 0 };
	DWORD bytesRead = 0;

	if (pcbData == NULL)
	{
		hr = E_INVALIDARG;
		goto Cleanup;
	}

	hFile = CreateFileW(
		lpFileName,
		GENERIC_READ,
		FILE_SHARE_READ,
		NULL,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		0);
	if (hFile == INVALID_HANDLE_VALUE)
	{
		hr = HRESULT_FROM_WIN32(GetLastError());
		goto Cleanup;
	}

	if (!GetFileSizeEx(hFile, &dataSize))
	{
		hr = HRESULT_FROM_WIN32(GetLastError());
		goto Cleanup;
	}

	if (dataSize.HighPart != 0)
	{
		hr = NTE_BAD_DATA;
		goto Cleanup;
	}

	*pcbData = dataSize.LowPart;
	if ((pbData == NULL) || (cbData == 0))
	{
		goto Cleanup;
	}
	else if (cbData < *pcbData)
	{
		hr = NTE_BUFFER_TOO_SMALL;
		goto Cleanup;
	}
	else
	{
		while ((cbData > bytesRead) && (*pcbData > bytesRead))
		{
			DWORD bytesReadLast = 0;
			if (!ReadFile(hFile,
				&pbData[bytesRead],
				(DWORD)(cbData - bytesRead),
				&bytesReadLast,
				NULL))
			{
				hr = HRESULT_FROM_WIN32(GetLastError());
				goto Cleanup;
			}
			bytesRead += bytesReadLast;
		}
	}

Cleanup:
	if (hFile != INVALID_HANDLE_VALUE)
	{
		CloseHandle(hFile);
		hFile = INVALID_HANDLE_VALUE;
	}
	return hr;
}

CString CCryptoDevice::sHelperGetPublicKey(PCWSTR keyName, PCWSTR usageAuth)
{
	HRESULT hr = S_OK;
	NCRYPT_PROV_HANDLE hProv = NULL;
	NCRYPT_KEY_HANDLE hKey = NULL;

	BYTE pbPubKey[1024] = { 0 };
	DWORD cbPubKey = 0;

	eMsg = L"";
	// Open key
	if (FAILED(hr = HRESULT_FROM_WIN32(NCryptOpenStorageProvider(
		&hProv, strKeyProvider,
		0))))
	{
		goto Cleanup;
	}

	if (FAILED(hr = HRESULT_FROM_WIN32(NCryptOpenKey(
		hProv,
		&hKey,
		keyName,
		0,
		(usageAuth != 0) ? NCRYPT_SILENT_FLAG : 0))))
	{
		goto Cleanup;
	}

	if ((usageAuth != NULL) && (wcslen(usageAuth) != 0))
	{
		if (FAILED(hr = HRESULT_FROM_WIN32(NCryptSetProperty(
			hKey,
			NCRYPT_PIN_PROPERTY,
			(PBYTE)usageAuth,
			(DWORD)((wcslen(usageAuth) + 1) * sizeof(WCHAR)),
			0))))
		{
			eMsg.Format(L"");
			// goto Cleanup;  // MS_KEY_STORAGE_PROVIDER not supported
		}
	}

	// Export public key
	if (FAILED(hr = HRESULT_FROM_WIN32(NCryptExportKey(
		hKey,
		NULL,
		BCRYPT_RSAPUBLIC_BLOB,
		NULL,
		pbPubKey,
		sizeof(pbPubKey),
		&cbPubKey,
		0))))
	{
		goto Cleanup;
	}

	eMsg.AppendFormat(L"    <RSAKey size=\"%u\"", cbPubKey);

	eMsg.AppendFormat(L" keyName=\"%s\"\n", keyName);

	BCRYPT_RSAKEY_BLOB* pKey = (BCRYPT_RSAKEY_BLOB*)pbPubKey;

	eMsg.AppendFormat(L"      <BitLength>%u</BitLength>\n", pKey->BitLength);

	eMsg.AppendFormat(L"      <Modulus size=\"%u\"\n", pKey->cbModulus);

	for (UINT32 n = 0; n < pKey->cbModulus; n++)
	{
		eMsg.AppendFormat(L"%02x", pbPubKey[sizeof(BCRYPT_RSAKEY_BLOB) +
			pKey->cbPublicExp + n]);
	}
	eMsg.AppendFormat(L"\n      </Modulus>\n");

Cleanup:
	if (hKey != NULL)
	{
		NCryptFreeObject(hKey);
		hKey = NULL;
	}
	if (hProv != NULL)
	{
		NCryptFreeObject(hProv);
		hProv = NULL;
	}

	vHelperResult(L"vHelperGetPublicKey()", hr);

	return eMsg;
}

bool CCryptoDevice::bCreateSignature(PCWSTR keyName, PCWSTR usageAuth, PCWSTR nounce, PBYTE nounceHashed, PBYTE signature)
{
	HRESULT hr = S_OK;
	NCRYPT_PROV_HANDLE hProv = NULL;
	NCRYPT_KEY_HANDLE hKey = NULL;
	BCRYPT_PKCS1_PADDING_INFO pPkcs = { BCRYPT_SHA1_ALGORITHM };
//	BYTE pubKeyDigest[SHA1_DIGEST_SIZE] = { 0 };
	UINT32 cbRequired = 0;
	char *pNounce;

	USES_CONVERSION;
	pNounce = T2A(nounce);

	if (FAILED(hr = hHelperShaHash(BCRYPT_SHA1_ALGORITHM,
		NULL,
		0,
		(PBYTE)pNounce,
		strlen(pNounce),
		nounceHashed,
//		pubKeyDigest,
		SHA1_DIGEST_SIZE,
		&cbRequired)))
	{
		hr = E_INVALIDARG;
		return FALSE;
	}

	// Open key
	if (FAILED(hr = HRESULT_FROM_WIN32(NCryptOpenStorageProvider(
		&hProv, strKeyProvider,
		0))))
	{
		return FALSE;
	}

	if (FAILED(hr = HRESULT_FROM_WIN32(NCryptOpenKey(
		hProv,
		&hKey,
		keyName,
		0,
		(usageAuth != 0) ? NCRYPT_SILENT_FLAG : 0))))
	{
		goto Cleanup;
	}

	if ((usageAuth != NULL) && (wcslen(usageAuth) != 0))
	{
		if (FAILED(hr = HRESULT_FROM_WIN32(NCryptSetProperty(
			hKey,
			NCRYPT_PIN_PROPERTY,
			(PBYTE)usageAuth,
			(DWORD)((wcslen(usageAuth) + 1) * sizeof(WCHAR)),
			0))))
		{
			eMsg.Format(L"");
			// goto Cleanup;  // MS_KEY_STORAGE_PROVIDER not supported
		}
	}

	if (FAILED(hr = HRESULT_FROM_WIN32(NCryptSignHash(
		hKey,
		&pPkcs,
		nounceHashed,
		SHA1_DIGEST_SIZE,
		signature,
		CFGDATASIZE,
		(DWORD *)&cbRequired,
		BCRYPT_PAD_PKCS1))))
	{
		eMsg.Format(L"");
		goto Cleanup;  // MS_KEY_STORAGE_PROVIDER not supported
	}
	errMsg.Format(L"Signature len=%d", cbRequired);
	eMsg = L"";
	for (UINT32 n = 0; n < cbRequired; n++)
	{
		eMsg.AppendFormat(L"%02x", signature[n]);
	}
	errMsg.Format(L"%s", eMsg);
	DISPLAY_TRACE();

Cleanup:
	if (hKey != NULL)
	{
		NCryptFreeObject(hKey);
		hKey = NULL;
	}
	if (hProv != NULL)
	{
		NCryptFreeObject(hProv);
		hProv = NULL;
	}

	vHelperResult(L"bCreateSignature()", hr);
	return SUCCEEDED(hr) ? TRUE : FALSE;
}

bool CCryptoDevice::bVerifySignature(PCWSTR keyName, PCWSTR usageAuth, PCWSTR nounce, PBYTE signature)
{
	HRESULT hr = S_OK;
	NCRYPT_PROV_HANDLE hProv = NULL;
	NCRYPT_KEY_HANDLE hKey = NULL;
	BCRYPT_PKCS1_PADDING_INFO pPkcs = { BCRYPT_SHA1_ALGORITHM };
	BYTE pNounceHashed[SHA1_DIGEST_SIZE+1];
	char *pNounce;
	UINT32 cbRequired;

	USES_CONVERSION;
	pNounce = T2A(nounce);

	if (FAILED(hr = hHelperShaHash(BCRYPT_SHA1_ALGORITHM,
		NULL,
		0,
		(PBYTE)pNounce,
		strlen(pNounce),
		pNounceHashed,
		SHA1_DIGEST_SIZE,
		&cbRequired)))
	{
		hr = E_INVALIDARG;
		return FALSE;
	}

	eMsg = L"";
	for (UINT32 n = 0; n < SHA1_DIGEST_SIZE; n++)
	{
		eMsg.AppendFormat(L"%02x", pNounceHashed[n]);
	}
	errMsg.Format(L"%s", eMsg);
	DISPLAY_TRACE();

	// Open key
	if (FAILED(hr = HRESULT_FROM_WIN32(NCryptOpenStorageProvider(
		&hProv, strKeyProvider,
		0))))
	{
		return FALSE;
	}

	if (FAILED(hr = HRESULT_FROM_WIN32(NCryptOpenKey(
		hProv,
		&hKey,
		keyName,
		0,
		(usageAuth != 0) ? NCRYPT_SILENT_FLAG : 0))))
	{
		goto Cleanup;
	}

	if ((usageAuth != NULL) && (wcslen(usageAuth) != 0))
	{
		if (FAILED(hr = HRESULT_FROM_WIN32(NCryptSetProperty(
			hKey,
			NCRYPT_PIN_PROPERTY,
			(PBYTE)usageAuth,
			(DWORD)((wcslen(usageAuth) + 1) * sizeof(WCHAR)),
			0))))
		{
			eMsg.Format(L"");
			// goto Cleanup;  // MS_KEY_STORAGE_PROVIDER not supported
		}
	}

	int signatureBlockSize=0;
	if (FAILED(hr = HRESULT_FROM_WIN32(NCryptGetProperty(
		hKey,
		BCRYPT_SIGNATURE_LENGTH,           // TPM Support this property
		(PBYTE)&signatureBlockSize,
		sizeof(signatureBlockSize),
		(DWORD *)&cbRequired,
		0))))
	{
		signatureBlockSize = RSABlockSize; // For Non-TPM
	}

	eMsg = L"";
	for (int n = 0; n < signatureBlockSize; n++)
	{
		eMsg.AppendFormat(L"%02x", signature[n]);
	}
	errMsg.Format(L"%s", eMsg);
	DISPLAY_TRACE();

	// Verify the signature with the hKey
	if (FAILED(hr = HRESULT_FROM_NT(NCryptVerifySignature(
		hKey,
		&pPkcs,
		(PBYTE)pNounceHashed,
		SHA1_DIGEST_SIZE,
		(PBYTE)signature,
		signatureBlockSize,
		BCRYPT_PAD_PKCS1))))
	{
		errMsg.Format(L"Signature Verification - FAILED");
		goto Cleanup;
	}

	errMsg.Format(L"Signature Verification - PASSED");

Cleanup:
	DISPLAY_TRACE();

	if (hKey != NULL)
	{
		NCryptFreeObject(hKey);
		hKey = NULL;
	}
	if (hProv != NULL)
	{
		NCryptFreeObject(hProv);
		hProv = NULL;
	}

	vHelperResult(L"VerifySignature()", hr);

	return SUCCEEDED(hr) ? TRUE : FALSE;
}

void CCryptoDevice::vShowKeys(bool bUseTPM)
{
	HRESULT hr = S_OK;
	NCRYPT_PROV_HANDLE hProv = NULL;
	NCRYPT_KEY_HANDLE hKey = NULL;

	NCryptKeyName* pKeyName = NULL;
	PVOID pEnumState = NULL;
//	DWORD dwFlags[2] = { NCRYPT_SILENT_FLAG,
//		NCRYPT_SILENT_FLAG | NCRYPT_MACHINE_KEY_FLAG };

	DWORD dwFlags[2] = { NCRYPT_SILENT_FLAG, NCRYPT_MACHINE_KEY_FLAG };
	DWORD dwKeyUsage = NCRYPT_PCP_IDENTITY_KEY;
	DWORD cbRequired = 0;
	DWORD keyLength = 0;
	DWORD exportPolicy = 0;
	LPCWSTR pProperty;

	if (FAILED(hr = HRESULT_FROM_WIN32(NCryptOpenStorageProvider(
		&hProv, strKeyProvider,
		0))))
	{
		goto Cleanup;
	}

	errMsg.Format(L"<Key Provider> %s", strKeyProvider);
	for (UINT32 n = 0; n < (sizeof(dwFlags) / sizeof(DWORD)); n++)
	{
		errMsg.Format(L"<Keys> flag=%08x", dwFlags[n]);

		hr = S_OK;
		BYTE pubKey[4096] = { 0 };
		BCRYPT_RSAKEY_BLOB* pPubKey = (BCRYPT_RSAKEY_BLOB*)pubKey;
		BYTE pubKeyDigest[20] = { 0 };

		while (SUCCEEDED(hr))
		{
			hr = HRESULT_FROM_WIN32(NCryptEnumKeys(
				hProv,
				NULL,
				&pKeyName,
				&pEnumState,
				dwFlags[n]));
			if (FAILED(hr))
			{
				if (hr == HRESULT_FROM_WIN32((ULONG)NTE_NO_MORE_ITEMS))
				{
					if (pEnumState != NULL)
					{
						NCryptFreeBuffer(pEnumState);
						pEnumState = NULL;
					}
					hr = S_OK;
					break;
				}
				else
				{
					goto Cleanup;
				}
			}
			else
			{
				if (FAILED(hr = HRESULT_FROM_WIN32(NCryptOpenKey(
					hProv,
					&hKey,
					pKeyName->pszName,
					0,
					0))))
				{
					goto Cleanup;
				}

				if (FAILED(hr = HRESULT_FROM_WIN32(NCryptGetProperty(
					hKey,
					NCRYPT_LENGTH_PROPERTY,
					(PBYTE)&keyLength,
					sizeof(keyLength),
					&cbRequired,
					0))))
				{
					goto Cleanup;
				}


				pProperty = (bUseTPM) ? NCRYPT_PCP_KEY_USAGE_POLICY_PROPERTY : NCRYPT_KEY_USAGE_PROPERTY;
				if (FAILED(hr = HRESULT_FROM_WIN32(NCryptGetProperty(
					hKey,
					pProperty,
					(PBYTE)&dwKeyUsage,
					sizeof(dwKeyUsage),
					&cbRequired,
					0))))
				{
					goto Cleanup;
				}

				if (FAILED(hr = HRESULT_FROM_WIN32(NCryptExportKey(
					hKey,
					NULL,
					BCRYPT_RSAPUBLIC_BLOB,
					NULL,
					pubKey,
					sizeof(pubKey),
					&cbRequired,
					0))))
				{
					goto Cleanup;
				}

				errMsg.Format(L"  <Key>");
				errMsg.Format(L"    <Name>%s</Name>", pKeyName->pszName);
				errMsg.Format(L"    <Algorithm>%s</Algorithm>", pKeyName->pszAlgid);
				errMsg.Format(L"    <KeyLength>%u</KeyLength>", keyLength);

				switch (dwKeyUsage & 0x0000ffff)
				{
				case NCRYPT_ALLOW_SIGNING_FLAG: // NCRYPT_PCP_ENCRYPTION_KEY
					(!bUseTPM) ? errMsg.Format(L"    <KeyUsage>SIGNATURE</KeyUsage>")
					: errMsg.Format(L"    <KeyUsage>ENCRYPTION/DECRYPTION</KeyUsage>");
					break;
				case NCRYPT_ALLOW_DECRYPT_FLAG: // NCRYPT_PCP_SIGNATURE_KEY
					(!bUseTPM) ? errMsg.Format(L"    <KeyUsage>ENCRYPTION/DECRYPTION</KeyUsage>")
						: errMsg.Format(L"    <KeyUsage>SIGNATURE</KeyUsage>");
					break;
				case NCRYPT_ALLOW_DECRYPT_FLAG | NCRYPT_ALLOW_SIGNING_FLAG: // NCRYPT_PCP_GENERIC_KEY
					(!bUseTPM) ? errMsg.Format(L"    <KeyUsage>SIGNATURE/ENCRYPTION/DECRYPTION</KeyUsage>")
						: errMsg.Format(L"    <KeyUsage>GENERIC</KeyUsage>");
					break;
				case NCRYPT_ALLOW_KEY_AGREEMENT_FLAG: // NCRYPT_PCP_STORAGE_KEY
					(!bUseTPM) ? errMsg.Format(L"    <KeyUsage>AGREMENT</KeyUsage>")
						: errMsg.Format(L"    <KeyUsage>STORAGE</KeyUsage>");
					break;
				case NCRYPT_PCP_IDENTITY_KEY:
					errMsg.Format(L"    <KeyUsage>IDENTITY</KeyUsage>");
					break;
				default:
					errMsg.Format(L"    <KeyUsage>UNKNOWN</KeyUsage>");
					break;
				}

				errMsg.Format(L"  </Key>");

				NCryptFreeObject(hKey);
				hKey = NULL;
				NCryptFreeBuffer(pKeyName);
				pKeyName = NULL;
			}
		}
		errMsg.Format(L"</Keys>");
	}

	DISPLAY_TRACE();

Cleanup:
	if (pKeyName != NULL)
	{
		NCryptFreeBuffer(pKeyName);
		pKeyName = NULL;
	}
	if (pEnumState != NULL)
	{
		NCryptFreeBuffer(pEnumState);
		pEnumState = NULL;
	}
	if (hKey != NULL)
	{
		NCryptFreeObject(hKey);
		hKey = NULL;
	}
	if (hProv != NULL)
	{
		NCryptFreeObject(hProv);
		hProv = NULL;
	}
	vHelperResult(L"vShowKeys()", hr);
}
