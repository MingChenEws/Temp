#pragma once

#include "CryptoDevice.h"
#include "xFAWinMsg.h"

class CCryptoClient
{
public:
	CCryptoClient();
	~CCryptoClient();
	void vInitClient();
	HRESULT hCreateAttestationIdentityKey();
	HRESULT hCreateStorageKey();
	HRESULT hCreateRelationKey(CString mRName, int mRIdx);
	bool bDeleteKey(PCWSTR keyName);
	bool bSaveCfgData(CString cfgFile);
	bool bEncryptCfgData(CString cfgFile);
	bool bDecryptCfgData(CString cfgFile);
	bool bCreateSignature(CString mNounce);
	bool bVerifySignature(CString mNounceHashed);
	void vShowKeys();

	HWND hwnd;
	bool bUseTPM;
	BYTE cfgData[CFGDATASIZE];
	BYTE nounceHashed[SHA1_DIGEST_SIZE];
	BYTE signature[CFGDATASIZE];

private:
	CCryptoDevice *pCryptoDev;

	HRESULT hGetTPMReadyState();
};
