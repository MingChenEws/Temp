#pragma once

extern CStringList glErrMsg;

class CErrMsg: public CString
{
public:
	void Format(_In_z_ _Printf_format_string_ PCXSTR pszFormat, ...)
	{
		ATLASSERT(AtlIsValidString(pszFormat));

		va_list argList;
		va_start(argList, pszFormat);
		FormatV(pszFormat, argList);
		va_end(argList);

		glErrMsg.AddHead(GetString());
	};
};

class CCryptoDevice // Interface
{
public:
	CString strCryptoProvider;
	CString strKeyProvider;

	HWND hwnd;
	CErrMsg errMsg;
	CString eMsg;
	CString UDID;
	TCHAR *strBlockLengthProperty;
	int RSABlockSize;
	int NoOfWordsForPadding;

	virtual HRESULT hCreateAttestationIdentityKey(PCWSTR keyName, PCWSTR usageAuth);
	virtual HRESULT hCreateStorageKey(PCWSTR keyName, PCWSTR usageAuth);
	virtual HRESULT hCreateRelationKey(PCWSTR keyName, PCWSTR usageAuth);
	virtual bool bDeleteKey(PCWSTR keyName);
	virtual bool bGetUniqDeviceIdentity();

	virtual bool bEncryptBlob(PCWSTR keyName, PCWSTR usageAuth, PCWSTR cfgFile);
	virtual bool bEncryptBlob(PCWSTR keyName, PCWSTR usageAuth, PCWSTR cfgFile, PBYTE cfgData, UINT32 cfgDataLen);
	virtual bool bDecryptBlob(PCWSTR keyName, PCWSTR usageAuth, PCWSTR cfgFile, PBYTE cfgData, UINT32 cfgDataLen);
	virtual bool bCreateSignature(PCWSTR keyName, PCWSTR usageAuth, PCWSTR nounce, PBYTE nounceHashed, PBYTE signature);
	virtual bool bVerifySignature(PCWSTR keyName, PCWSTR usageAuth, PCWSTR nounce, PBYTE signature);
	virtual void vShowKeys(bool bUseTPM);

	bool EnumProviders(CStringList *lstRegisteredProviders);

	HRESULT hHelperGetTPMReadyState();
	void vHelperResult(_In_ WCHAR* func, HRESULT hr);
	HRESULT hHelperDisplayKey(_In_ PCWSTR lpKeyName, _In_reads_(cbKey) PBYTE pbKey, DWORD cbKey);
	HRESULT HelperReadFile(_In_ PCWSTR lpFileName, _In_reads_opt_(cbData) PBYTE pbData, UINT32 cbData, __out PUINT32 pcbData);
	HRESULT HelperWriteFile(_In_ PCWSTR lpFileName, _In_reads_opt_(cbData) PBYTE pbData, UINT32 cbData);
	CString sHelperGetPublicKey(PCWSTR keyName, PCWSTR usageAuth);
	HRESULT hHelperShaHash(LPCWSTR pszAlgId, _In_reads_opt_(cbKey) PBYTE pbKey, UINT32 cbKey, _In_reads_(cbData) PBYTE pbData,
		                   UINT32 cbData, _Out_writes_to_opt_(cbResult, *pcbResult) PBYTE pbResult, UINT32 cbResult, _Out_ PUINT32 pcbResult);
};