// DialogRelation.cpp : implementation file
//

#include "stdafx.h"
#include "xFACryptoClient.h"
#include "DialogRelation.h"
#include "afxdialogex.h"


// CDialogRelation dialog

IMPLEMENT_DYNAMIC(CDialogRelation, CDialogEx)

CDialogRelation::CDialogRelation(CWnd* pParent, LPCTSTR pAct, CString *pRName, int *pRIndex /*=NULL*/)
	: CDialogEx(CDialogRelation::IDD, pParent)
	, mRelationName(_T("BOA"))
	, mRelationIndex(1)
{
	pAction = pAct;
	pRelationName = pRName;
	pRelationIndex = pRIndex;
}

CDialogRelation::~CDialogRelation()
{
}

BOOL CDialogRelation::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	cRelationAction.SetWindowTextW(pAction);

	// TODO: Add extra initialization here

	return TRUE;  // return TRUE  unless you set the focus to a control
}
void CDialogRelation::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDOK, cRelationAction);
	DDX_Text(pDX, IDC_RELATION_NAME, mRelationName);
	DDV_MaxChars(pDX, mRelationName, 20);
	DDX_Text(pDX, IDC_RELATION_INDEX, mRelationIndex);
	DDV_MinMaxInt(pDX, mRelationIndex, 0, 20);
}

BEGIN_MESSAGE_MAP(CDialogRelation, CDialogEx)
	ON_BN_CLICKED(IDOK, &CDialogRelation::OnBnClickedOk)
END_MESSAGE_MAP()


// CDialogRelation message handlers


void CDialogRelation::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	(*pRelationName) = mRelationName;
	(*pRelationIndex) = mRelationIndex;

	CDialogEx::OnOK();
}
