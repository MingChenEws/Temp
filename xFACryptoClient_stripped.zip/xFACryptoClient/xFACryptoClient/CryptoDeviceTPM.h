#pragma once
#include "CryptoClient.h"

class CCryptoDeviceTPM :
	public CCryptoDevice
{
public:
	CCryptoDeviceTPM(HWND hw);
	~CCryptoDeviceTPM();
	HRESULT hCreateRSAAsymmetricKey(PCWSTR keyType, PCWSTR keyName, PCWSTR usageAuth, DWORD dwKeyUsage);
	HRESULT hCreateAttestationIdentityKey(PCWSTR keyName, PCWSTR usageAuth);
	HRESULT hCreateStorageKey(PCWSTR keyName, PCWSTR usageAuth);
	HRESULT hCreateRelationKey(PCWSTR keyName, PCWSTR usageAuth);
};

