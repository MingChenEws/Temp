#pragma once
#include "afxwin.h"


// CDialogRelation dialog

class CDialogRelation : public CDialogEx
{
	DECLARE_DYNAMIC(CDialogRelation)

public:
	CDialogRelation(CWnd* pParent, LPCTSTR pAct, CString *pRName, int *pRIndex);   // standard constructor
	virtual ~CDialogRelation();

// Dialog Data
	enum { IDD = IDD_DIALOG_RELATION };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	CButton cRelationAction;
	CString mRelationName;
	int mRelationIndex;
	CString *pRelationName;
	int *pRelationIndex;
	LPCTSTR pAction;
};
