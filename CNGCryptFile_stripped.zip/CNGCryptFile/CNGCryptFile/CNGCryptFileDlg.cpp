// CNGCryptFileDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CNGCryptFile.h"
#include "CNGCryptFileDlg.h"
#include "MyCNGCryptFile.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CCNGCryptFileDlg dialog




CCNGCryptFileDlg::CCNGCryptFileDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCNGCryptFileDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_bEncrypt =true;
}

void CCNGCryptFileDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCNGCryptFileDlg)
	DDX_Control(pDX, IDC_LIST_LOG, m_lstLog);
	//}}AFX_DATA_MAP

}

BEGIN_MESSAGE_MAP(CCNGCryptFileDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_FILE1, &CCNGCryptFileDlg::OnBnClickedButtonFile1)
	ON_BN_CLICKED(IDC_BUTTON_ENCRYPT, &CCNGCryptFileDlg::OnBnClickedButtonCrypt)
	ON_BN_CLICKED(IDC_RADIO_CRYPT, &CCNGCryptFileDlg::OnBnClickedRadioCrypt)
	ON_BN_CLICKED(IDC_RADIO_DECRYPT, &CCNGCryptFileDlg::OnBnClickedRadioDecrypt)
END_MESSAGE_MAP()


// CCNGCryptFileDlg message handlers

BOOL CCNGCryptFileDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	{
		CRect rect;
		m_lstLog.GetClientRect(&rect);
		int iWidth = rect.Width();

		m_lstLog.InsertColumn(0,_T(""),0,iWidth);
	}
	//TODO selesionzte il primo check

	//Show the list of available providers.
	CMyCNGCryptFile oCngAes;
	CStringList oRegisteredProviders;
	oCngAes.EnumProviders(&oRegisteredProviders);
	
	//Print ProviderList
	CString sProv;
	sProv.Format(_T("Provider found:"));
	m_lstLog.InsertItem(m_lstLog.GetItemCount(),sProv);
	int idx=1;
	while (!oRegisteredProviders.IsEmpty())
	{
		sProv.Format(_T("%d. %s"),idx,oRegisteredProviders.GetTail());
		m_lstLog.InsertItem(m_lstLog.GetItemCount(),sProv);
		oRegisteredProviders.RemoveTail();
		idx++;
	}
	
	sProv.Format(_T("Init Ok."));
	m_lstLog.InsertItem(m_lstLog.GetItemCount(),sProv);

	GetDlgItem(	IDC_BUTTON_ENCRYPT)->EnableWindow(FALSE);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCNGCryptFileDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCNGCryptFileDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CCNGCryptFileDlg::OnBnClickedButtonFile1()
{
	CString sFile1;
	CFileDialog oFileDialog(TRUE,
		NULL,
		NULL,OFN_HIDEREADONLY 		);
	if (oFileDialog.DoModal() == IDOK)
	{
		sFile1  = oFileDialog.GetPathName();
		

		if (!sFile1.IsEmpty())
		{
			GetDlgItem(IDC_EDIT_FILE1)->SetWindowTextW(sFile1);
		}
	}
}

void CCNGCryptFileDlg::OnBnClickedButtonCrypt()
{
	CString sFileToOpen, sFileToCrypt, sKey,sError;
	GetDlgItem(IDC_EDIT_FILE1)->GetWindowTextW(sFileToOpen);
	
	if (sFileToOpen.IsEmpty())
	{
		sError.Format(_T("Error the file choosed is empty"));
		m_lstLog.InsertItem(m_lstLog.GetItemCount(),sError);
		return ;
	}
	else
	{
		sError.Format(_T("File choosed is %s"),sFileToOpen);
		m_lstLog.InsertItem(m_lstLog.GetItemCount(),sError);
	}

	GetDlgItem(IDC_EDIT_KEY)->GetWindowTextW(sKey);
	
	if (sKey.IsEmpty())
	{
		sError.Format(_T("Error the Key is empty"));
		m_lstLog.InsertItem(m_lstLog.GetItemCount(),sError);
		return ;
	}

	if (m_bEncrypt)
		sFileToCrypt.Format(_T("%s.Encrypt"),sFileToOpen);
	else
		sFileToCrypt.Format(_T("%s.Decrypt"),sFileToOpen);



	CMyCNGCryptFile oCngAes;

	if(oCngAes.CryptFile(m_bEncrypt,sFileToOpen,sFileToCrypt,sKey))
	{
		sError.Format(_T("Success, the file %s is %s"),m_bEncrypt?_T("Encrypted"):_T("Decrypted"), sFileToCrypt);
		m_lstLog.InsertItem(m_lstLog.GetItemCount(),sError);
	}
	else
	{	
		m_lstLog.InsertItem(m_lstLog.GetItemCount(),oCngAes.GetLastError());
	}


}

void CCNGCryptFileDlg::OnBnClickedRadioCrypt()
{
	m_bEncrypt =true;
	GetDlgItem(	IDC_BUTTON_ENCRYPT)->EnableWindow(TRUE);
	GetDlgItem(	IDC_BUTTON_ENCRYPT)->SetWindowTextW(_T("Encrypt"));
}

void CCNGCryptFileDlg::OnBnClickedRadioDecrypt()
{
	m_bEncrypt = false;
	GetDlgItem(	IDC_BUTTON_ENCRYPT)->EnableWindow(TRUE);
	GetDlgItem(	IDC_BUTTON_ENCRYPT)->SetWindowTextW(_T("Decrypt"));
}
