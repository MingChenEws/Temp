﻿using System;
using System.Diagnostics;
using System.Threading.Tasks;
using Windows.ApplicationModel.AppService;
using Windows.ApplicationModel.Background;
using Windows.Foundation.Collections;

namespace AppService
{
    public sealed class BridgeAppService : IBackgroundTask
    {
        private const byte GTID_COMPONENT_GTID = 0x00;
        private const byte GTID_COMPONENT_FIDO = 0x01;
        private const byte GTID_COMPONENT_SMARTCARD = 0x02;

        private const byte CTAPHID_INIT_FRAME = 0x80;
        // Manadatory CTAP HID native commands
        private const byte CTAPHID_PING = (CTAPHID_INIT_FRAME | 0x01);   // Echo data through local processor only
        private const byte CTAPHID_INIT = (CTAPHID_INIT_FRAME | 0x06);   // HID Init
        private const byte CTAPHID_MSG = (CTAPHID_INIT_FRAME | 0x03);    // Send U2F message frame
        private const byte CTAPHID_ERROR = (CTAPHID_INIT_FRAME | 0x3f);  // Error response

        // Manadatory FIDO2 New
        private const byte CTAPHID_CBOR = (CTAPHID_INIT_FRAME | 0x10);	// FIDO2 CBOR Message
        private const byte CTAPHID_CANCEL = (CTAPHID_INIT_FRAME | 0x11); // FIDO2 Cancel 
        private const byte CTAPHID_KEEPALIVE = (CTAPHID_INIT_FRAME | 0x3b);  // FIDO2 Keep Alive

        // Optional
        private const byte CTAPHID_WINK = (CTAPHID_INIT_FRAME | 0x08);   // Send device identification wink
        private const byte CTAPHID_LOCK = (CTAPHID_INIT_FRAME | 0x04);	// Send lock channel command

        // Vendor Specific
        private const byte CTAPHID_VENDOR_FIRST = (CTAPHID_INIT_FRAME | 0x40);	// First vendor defined command
        private const byte CTAPHID_VENDOR_EXIT = (CTAPHID_INIT_FRAME | 0x41);    // vendor EXIT
        private const byte CTAPHID_VENDOR_ABORT = (CTAPHID_INIT_FRAME | 0x42);   // vendor ABORT
        private const byte CTAPHID_VENDOR_PING = (CTAPHID_INIT_FRAME | 0x43);	// vendor PING
        private const byte CTAPHID_VENDOR_LAST = (CTAPHID_INIT_FRAME | 0x7f); // Last vendor defined command

        // U2F native commands
        private const byte U2F_REGISTER = 0x01;	// Registration command
        private const byte U2F_AUTHENTICATE = 0x02;	// Authenticate/sign command
        private const byte U2F_VERSION = 0x03;	// Read version string command
        private const byte U2F_VENDOR_FIRST = 0x40;	// First vendor defined command
        private const byte U2F_VENDOR_LAST = 0x7f;  // Last vendor defined command

        // FIDO2 CBOR native commands
        private const byte FIDO2_MAKE_CREDENTIAL = 0X01;
        private const byte FIDO2_GET_ASSERTION = 0X02;
        private const byte FIDO2_CANCEL = 0X03;
        private const byte FIDO2_GET_INFO = 0X04;
        private const byte FIDO2_CLIENT_PIN = 0X06;
        private const byte FIDO2_RESET = 0X07;
        private const byte FIDO2_GET_NEXT_ASSERTION = 0X08;

        uint mChanId = 0;

        private BackgroundTaskDeferral backgroundTaskDeferral;
        private AppServiceConnection appServiceconnection = null;
        private AppServiceConnection appServiceClient = null;

        public void Run(IBackgroundTaskInstance taskInstance)
        {
            // Get a deferral so that the service isn't terminated.
            this.backgroundTaskDeferral = taskInstance.GetDeferral();

            // Associate a cancellation handler with the background task.
            taskInstance.Canceled += OnTaskCanceled;

            // Retrieve the app service connection and set up a listener for incoming app service requests.
            var details = taskInstance.TriggerDetails as AppServiceTriggerDetails;
            appServiceconnection = details.AppServiceConnection;
            appServiceconnection.RequestReceived += OnRequestReceived;


        }

        private async void OnRequestReceived(AppServiceConnection sender, AppServiceRequestReceivedEventArgs args)
        {
            // Get a deferral because we use an awaitable API below to respond to the message
            // and we don't want this call to get cancelled while we are waiting.
            appServiceClient = sender;
            var messageDeferral = args.GetDeferral();
            try
            {
                ValueSet statusOK = new ValueSet() { { "Status", "OK" } };
                await args.Request.SendResponseAsync(statusOK); // Return the data to the caller.

            }
            catch (Exception e)
            {
                Debug.WriteLine(getTimeStamp() + "AppServiceModule: SendResponseAsync Exception: " + e.Message);
            }
            finally
            {
                // Complete the deferral so that the platform knows that we're done responding to the app service call.
                // Note for error handling: this must be called even if SendResponseAsync() throws an exception.
                messageDeferral.Complete();
            }

            byte function = (args.Request.Message.TryGetValue("Function", out object obj)) ? (byte)obj : (byte)0x02;
            //Debug.WriteLine("Function=0x{0:X2}", module);
            byte cmd = (args.Request.Message.TryGetValue("Command", out obj)) ? (byte)obj : (byte)0x83;
            //Debug.WriteLine("Command=0x{0:X2}", cmd);
            mChanId = (args.Request.Message.TryGetValue("ChannelId", out obj)) ? (uint)obj : (uint)0xffffffff;
            //Debug.WriteLine("ChannelId=0x{0:X8}", mChanId);
            byte[] req = (args.Request.Message.TryGetValue("Request", out obj)) ? (byte[])obj : (byte[])null;
            int len = (req == null) ? 0 : req.Length;

            Debug.WriteLine(getTimeStamp() + "BRIDGE_APPSVC:: Command=0x{0:X2}, ChannelId=0x{1:X8}, len={2:D}", cmd, mChanId, len);
            //displayHexDump(msgRcvd.data);

            switch(function)
            {
                case GTID_COMPONENT_FIDO:
                    switch (cmd) // Check FIDO Command
                    {
                        case CTAPHID_INIT:
                            // Do your BT Discovery here
                            Debug.WriteLine(getTimeStamp() + "[CTAPHID_INIT]");
                            break;

                        case CTAPHID_MSG:  // U2F
                            if (len > 0)
                            {
                                Debug.WriteLine(getTimeStamp() + "[CTAPHID_MSG]");
                                if (false)
                                {
                                    // whatever you need to send through BT
                                    // change false to true
                                }
                                else
                                {
                                    // Right now, I just hardcode and send back response
                                    switch (req[1])  // INS
                                    {
                                        case U2F_REGISTER:
                                        case U2F_AUTHENTICATE:
                                            string rspStr = "0504711F1870863EDF82F7AF8FEBD8C40F4CFD8D4AE479EF6DBC554B2E0714DE3B756B6C74327982484B140BE2085C95D4C990915058D1582F10F5803B5B2271CA0B408A6D37B187A7B49DBEDE689E4925F669E329EBDBF7A88CDE9A05D8FA128C17AABCA3983F0134CF6E0D21400D70663B09202FDF4F42AF192A0AA7515418A7B4A23082022E30820118A00302010202040A630BFF300B06092A864886F70D01010B302E312C302A0603550403132359756269636F2055324620526F6F742043412053657269616C203435373230303633313020170D3134303830313030303030305A180F32303530303930343030303030305A30293127302506035504030C1E59756269636F205532462045452053657269616C203137343236333239353059301306072A8648CE3D020106082A8648CE3D03010703420004A423645DBA8B23ED6CD9E5E48B932ACFDF4564C75731F1CF520745106B49BA960FAD0F0AA5093DEE33908445A816B8367CDD855712F349E566E63700D426D09FA3263024302206092B0601040182C40A020415312E332E362E312E342E312E34313438322E312E32300B06092A864886F70D01010B03820101006539B032A1CFC448D207AE149B0AB6B460CAA6501C133AF09A0EA4812F0A3E424A5CA4AEF53D47E9704CF7E2C013D70DE3CA148AB1459832254DB6515D4D959B6A8EF4E76B495158FAA75B17DA2D8BC08A0263C7B896525BA8A2EEA344E7D74729468FE250D8A678510EAB6D59251A961D8B3C32505293BD6EC24F92035902105440C6195CBFCC4192D16245FE95DEE595334E5F9BBB9FFE18E4432BFA5A8EC95542F6543A24FEB1A1AF6AE99A7DF98F5998B09E72BADCB87EBEA4B0E00333DC73CAB1842D8E475074652A48F51060713D0AAA7544D2DAB52840DEA243EA17732098346427EFBF6B6A55D300187CF0B7B42E7B06D05D1FF517101F31655161B4304502207898C31D93AEF0AC566B1919BBA0C59C897E55CBBB4B72DC50E5C4F06B99C89D022100F86ECACF3BF8FCB412F21EFE91748666AC91D8ED04C81F6A2CA0B491B0F35B0A9000";
                                            char[] bufData = rspStr.ToCharArray();
                                            int txLen = rspStr.Length / 2;
                                            byte[] respData = new byte[txLen];
                                            for (int i = 0, j = 0; j < rspStr.Length; i++, j = j + 2)
                                            {
                                                respData[i] = (byte)(getDigit(bufData[j]) * 16 + getDigit(bufData[j + 1]));
                                            }
                                            //await Task.Delay(4000);
                                            sendFidoResponse(appServiceClient, CTAPHID_MSG, respData, txLen);
                                            break;

                                        default:
                                            Debug.WriteLine(getTimeStamp() + "Invalid U2F Request!!!");
                                            break;
                                    }
                                }
                            }
                            break;

                        case CTAPHID_CBOR:  // FIDO2
                            if (len > 0)
                            {
                                Debug.WriteLine(getTimeStamp() + "[CTAPHID_CBOR]");
                                if (true)
                                {
                                    // whatever you need to send through BT
                                    // change false to true
                                }
                                else
                                {
                                    // Right now, I just hardcode and send back response
                                    switch (req[1])  // INS
                                    {
                                        case U2F_REGISTER:
                                        case U2F_AUTHENTICATE:
                                            string rspStr = "0504711F1870863EDF82F7AF8FEBD8C40F4CFD8D4AE479EF6DBC554B2E0714DE3B756B6C74327982484B140BE2085C95D4C990915058D1582F10F5803B5B2271CA0B408A6D37B187A7B49DBEDE689E4925F669E329EBDBF7A88CDE9A05D8FA128C17AABCA3983F0134CF6E0D21400D70663B09202FDF4F42AF192A0AA7515418A7B4A23082022E30820118A00302010202040A630BFF300B06092A864886F70D01010B302E312C302A0603550403132359756269636F2055324620526F6F742043412053657269616C203435373230303633313020170D3134303830313030303030305A180F32303530303930343030303030305A30293127302506035504030C1E59756269636F205532462045452053657269616C203137343236333239353059301306072A8648CE3D020106082A8648CE3D03010703420004A423645DBA8B23ED6CD9E5E48B932ACFDF4564C75731F1CF520745106B49BA960FAD0F0AA5093DEE33908445A816B8367CDD855712F349E566E63700D426D09FA3263024302206092B0601040182C40A020415312E332E362E312E342E312E34313438322E312E32300B06092A864886F70D01010B03820101006539B032A1CFC448D207AE149B0AB6B460CAA6501C133AF09A0EA4812F0A3E424A5CA4AEF53D47E9704CF7E2C013D70DE3CA148AB1459832254DB6515D4D959B6A8EF4E76B495158FAA75B17DA2D8BC08A0263C7B896525BA8A2EEA344E7D74729468FE250D8A678510EAB6D59251A961D8B3C32505293BD6EC24F92035902105440C6195CBFCC4192D16245FE95DEE595334E5F9BBB9FFE18E4432BFA5A8EC95542F6543A24FEB1A1AF6AE99A7DF98F5998B09E72BADCB87EBEA4B0E00333DC73CAB1842D8E475074652A48F51060713D0AAA7544D2DAB52840DEA243EA17732098346427EFBF6B6A55D300187CF0B7B42E7B06D05D1FF517101F31655161B4304502207898C31D93AEF0AC566B1919BBA0C59C897E55CBBB4B72DC50E5C4F06B99C89D022100F86ECACF3BF8FCB412F21EFE91748666AC91D8ED04C81F6A2CA0B491B0F35B0A9000";
                                            char[] bufData = rspStr.ToCharArray();
                                            int txLen = rspStr.Length / 2;
                                            byte[] respData = new byte[txLen];
                                            for (int i = 0, j = 0; j < rspStr.Length; i++, j = j + 2)
                                            {
                                                respData[i] = (byte)(getDigit(bufData[j]) * 16 + getDigit(bufData[j + 1]));
                                            }
                                            //await Task.Delay(40000);
                                            sendFidoResponse(appServiceClient, CTAPHID_CBOR, respData, txLen);
                                            break;

                                        default:
                                            Debug.WriteLine(getTimeStamp() + "Invalid U2F Request!!!");
                                            break;
                                    }
                                }
                            }
                            break;
                        case CTAPHID_VENDOR_ABORT:
                            Debug.WriteLine(getTimeStamp() + "[CTAPHID_VENDOR_ABORT]");
                            break;

                        default:
                            break;
                    }
                    break;
                case GTID_COMPONENT_SMARTCARD:
                    break;
            }
        }

        private async void sendFidoResponse(AppServiceConnection requester, byte FidoCommand, byte[] packet, int len)
        {
            ValueSet response = new ValueSet()
            {
                { "Function", (byte)GTID_COMPONENT_FIDO },
                { "Command", (byte)FidoCommand },
                { "ChannelId", mChanId },
                { "Response", packet }
            };

            Debug.WriteLine(getTimeStamp() + "BridgeAppService: SendMessageAsync({0:D})", len);

            try
            {
                await requester.SendMessageAsync(response);
            }
            catch (InvalidOperationException e)
            {
                Debug.WriteLine(getTimeStamp() + "BridgeAppService: SendMessageAsync[InvalidOperationException] " + e.Message);

            }
            Debug.WriteLine(getTimeStamp() + "BridgeAppService: SendMessageAsync({0:D}) ... SUCCESS", len);
        }

        private void OnTaskCanceled(IBackgroundTaskInstance sender, BackgroundTaskCancellationReason reason)
        {
            if (this.backgroundTaskDeferral != null)
            {
                // Complete the service deferral.
                this.backgroundTaskDeferral.Complete();
            }
        }

        private int getDigit(char c)
        {
            int v = 0;

            switch (c)
            {
                case '0': v = 0; break;
                case '1': v = 1; break;
                case '2': v = 2; break;
                case '3': v = 3; break;
                case '4': v = 4; break;
                case '5': v = 5; break;
                case '6': v = 6; break;
                case '7': v = 7; break;
                case '8': v = 8; break;
                case '9': v = 9; break;
                case 'A': v = 10; break;
                case 'B': v = 11; break;
                case 'C': v = 12; break;
                case 'D': v = 13; break;
                case 'E': v = 14; break;
                case 'F': v = 15; break;
            }
            return v;
        }

        private string getTimeStamp()
        {
            return DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff ");
        }
    }
}
