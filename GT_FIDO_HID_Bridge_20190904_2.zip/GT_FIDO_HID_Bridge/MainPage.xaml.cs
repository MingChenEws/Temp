﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

using System.Threading.Tasks;
using Windows.Networking;
using Windows.Networking.Sockets;
using System.Threading;
using System.Net.Sockets;
using System.Net;
using System.Diagnostics;
using Windows.UI.Popups;
using Windows.ApplicationModel.Core;
using Windows.UI.Core;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace GT_FIDO_HID_Bridge
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private const ushort FIDO_PID = 0xDEED;
        private const ushort FIDO_VID = 0xFEED;
        private const ushort FIDO_UID = 0x0001;
        private const ushort FIDO_UPAGE = 0xF1D0;
        // CTAPHID native commands
        private const byte CTAPHID_INIT_FRAME = 0x80;
        // Manadatory CTAP HID native commands
        private const byte CTAPHID_PING = (CTAPHID_INIT_FRAME | 0x01);   // Echo data through local processor only
        private const byte CTAPHID_INIT = (CTAPHID_INIT_FRAME | 0x06);   // HID Init
        private const byte CTAPHID_MSG = (CTAPHID_INIT_FRAME | 0x03);    // Send U2F message frame
        private const byte CTAPHID_ERROR = (CTAPHID_INIT_FRAME | 0x3f);  // Error response

        // Manadatory FIDO2 New
        private const byte CTAPHID_CBOR = (CTAPHID_INIT_FRAME | 0x10);	// FIDO2 CBOR Message
        private const byte CTAPHID_CANCEL = (CTAPHID_INIT_FRAME | 0x11); // FIDO2 Cancel 
        private const byte CTAPHID_KEEPALIVE = (CTAPHID_INIT_FRAME | 0x3b);  // FIDO2 Keep Alive

        // Optional
        private const byte CTAPHID_WINK = (CTAPHID_INIT_FRAME | 0x08);   // Send device identification wink
        private const byte CTAPHID_LOCK = (CTAPHID_INIT_FRAME | 0x04);	// Send lock channel command

        // Vendor Specific
        private const byte CTAPHID_VENDOR_FIRST = (CTAPHID_INIT_FRAME | 0x40);	// First vendor defined command
        private const byte CTAPHID_VENDOR_EXIT = (CTAPHID_INIT_FRAME | 0x41);    // vendor EXIT
        private const byte CTAPHID_VENDOR_PING = (CTAPHID_INIT_FRAME | 0x43);	// vendor PING
        private const byte CTAPHID_VENDOR_LAST = (CTAPHID_INIT_FRAME | 0x7f); // Last vendor defined command
        byte[] AuthBridgeMsg = new byte[1028];

        public static List<Task> TaskList = new List<Task>();
        private Boolean[] bContinue = { true, true };
        private Boolean[] bExit = { false, false };
        private int TASK_HID_BRIDGE = 0;
        private int TASK_BT_BRIDGE = 1;
        private bool bAbort = false;
        private int testNo = 0;
        Socket socketHIDBridge = null;
        int mChanId = 0;
        int MSGHDRLEN = 4;

        public MainPage()
        {
            this.InitializeComponent();
            this.startTasks();
        }

        /// <summary>
        /// ///////////////////////////////////////////////////////////////////
        /// </summary>
        private void startBTBridgeTask()
        {
            // Just loop.
            while (bContinue[TASK_BT_BRIDGE])
            {

            }

            // Out of BT Task
            bContinue[TASK_BT_BRIDGE] = false;
            bExit[TASK_BT_BRIDGE] = true;
            if (bExit[TASK_HID_BRIDGE] == true)
            {
                Application.Current.Exit();
            }
        }

        // Abnerl, modify sendtoBTBridge() and add any other functions for BT work
        public async void sendtoBTBridge(byte[] data, int len)
        {
            int msgLen = 0;
            if (len >= MSGHDRLEN) // MUST be greater or equal to MSGHDRLEN
            {
                switch (data[1]) // Check cmd
                {
                    case CTAPHID_INIT:
                        // Do your BT Discovery here
                        //msgLen = len - MSGHDRLEN;
                        MSGHDRLEN = len;
                        break;

                    case CTAPHID_MSG:
                        msgLen = len - MSGHDRLEN;
                        int lenInsideMsg = (data[3] << 8) + data[2];
                        if (MSGHDRLEN > 4)
                            mChanId = (data[7] << 24) + (data[6] << 16) + (data[5] << 8) + data[4];
                        Debug.WriteLine("MSGHDRLEN={0:D},  mChanId=0x{1:X8}", MSGHDRLEN, mChanId);
                        if (false)
                        {
                            // whatever you need to send through BT
                            // change false to true
                        }
                        else
                        {
                            // Right now, I just hardcode and send back response
                            string rspStr = "0504711F1870863EDF82F7AF8FEBD8C40F4CFD8D4AE479EF6DBC554B2E0714DE3B756B6C74327982484B140BE2085C95D4C990915058D1582F10F5803B5B2271CA0B408A6D37B187A7B49DBEDE689E4925F669E329EBDBF7A88CDE9A05D8FA128C17AABCA3983F0134CF6E0D21400D70663B09202FDF4F42AF192A0AA7515418A7B4A23082022E30820118A00302010202040A630BFF300B06092A864886F70D01010B302E312C302A0603550403132359756269636F2055324620526F6F742043412053657269616C203435373230303633313020170D3134303830313030303030305A180F32303530303930343030303030305A30293127302506035504030C1E59756269636F205532462045452053657269616C203137343236333239353059301306072A8648CE3D020106082A8648CE3D03010703420004A423645DBA8B23ED6CD9E5E48B932ACFDF4564C75731F1CF520745106B49BA960FAD0F0AA5093DEE33908445A816B8367CDD855712F349E566E63700D426D09FA3263024302206092B0601040182C40A020415312E332E362E312E342E312E34313438322E312E32300B06092A864886F70D01010B03820101006539B032A1CFC448D207AE149B0AB6B460CAA6501C133AF09A0EA4812F0A3E424A5CA4AEF53D47E9704CF7E2C013D70DE3CA148AB1459832254DB6515D4D959B6A8EF4E76B495158FAA75B17DA2D8BC08A0263C7B896525BA8A2EEA344E7D74729468FE250D8A678510EAB6D59251A961D8B3C32505293BD6EC24F92035902105440C6195CBFCC4192D16245FE95DEE595334E5F9BBB9FFE18E4432BFA5A8EC95542F6543A24FEB1A1AF6AE99A7DF98F5998B09E72BADCB87EBEA4B0E00333DC73CAB1842D8E475074652A48F51060713D0AAA7544D2DAB52840DEA243EA17732098346427EFBF6B6A55D300187CF0B7B42E7B06D05D1FF517101F31655161B4304502207898C31D93AEF0AC566B1919BBA0C59C897E55CBBB4B72DC50E5C4F06B99C89D022100F86ECACF3BF8FCB412F21EFE91748666AC91D8ED04C81F6A2CA0B491B0F35B0A9000";
                            char[] bufData = rspStr.ToCharArray();
                            int txLen = rspStr.Length / 2;
                            byte[] respData = new byte[txLen];
                            for (int i = 0, j = 0; j < rspStr.Length; i++, j = j + 2)
                            {
                                respData[i] = (byte)(getDigit(bufData[j]) * 16 + getDigit(bufData[j + 1]));
                            }
                            //await Task.Delay(1111);
                            bAbort = false;
                            testNo++;
                            await CoreApplication.MainView.CoreWindow.Dispatcher.RunAsync(
                                CoreDispatcherPriority.Normal, async () =>
                            {
                                MessageDialog msgbox = new MessageDialog("Would you like to send the response", "Test-"+testNo%5);
                                msgbox.Commands.Clear();
                                msgbox.Commands.Add(new UICommand { Label = "Yes", Id = 0 });
                                msgbox.Commands.Add(new UICommand { Label = "No", Id = 1 });
                                msgbox.Commands.Add(new UICommand { Label = "Error", Id = 2 });

                                var res = await msgbox.ShowAsync();
                                if ((int)res.Id == 0)
                                {
                                    if (bAbort == false)
                                    {
                                        sendtoHIDBridge(respData, txLen);
                                        //socketHIDBridge.Send(respData);
                                    }
                                }
                                if ((int)res.Id == 2)
                                {
                                    if (bAbort == false)
                                    {
                                        byte[] err = new byte[1] { 0x19 };
                                        //CTAP2_ERR_CREDENTIAL_EXCLUDED(0x19);
                                        sendtoHIDBridge(err, err.Length);
                                        //socketHIDBridge.Send(respData);
                                    }
                                }

                            });

                        }
                        break;

                    case CTAPHID_CANCEL:
                        bAbort = true;
                        Debug.WriteLine("CTAPHID_CANCEL");
                        break;

                    default:
                        break;
                }
            }
        }

        /// Abnerl, you can optimize sendtoHIDBridge() to reduce byte copy later. 
        /// 
        private void sendtoHIDBridge(byte[] data, int len)
        {
            byte[] hdr = new byte[8] { 0x01, CTAPHID_MSG, (byte)(len % 256), (byte)(len >> 8),
                        (byte)(mChanId % 256), (byte)(mChanId >> 8), (byte)(mChanId >> 16), (byte)(mChanId >> 24) };
            byte[] message = null;
            if (len > 0)
            {
                message = new byte[len + MSGHDRLEN];
                System.Buffer.BlockCopy(hdr, 0, message, 0, MSGHDRLEN);
                System.Buffer.BlockCopy(data, 0, message, MSGHDRLEN, len);
            }
            else
            {
                message = new byte[MSGHDRLEN];
                System.Buffer.BlockCopy(hdr, 0, message, 0, MSGHDRLEN);
            }

            socketHIDBridge.Send(message);
        }


        /// Abnerl, no need to change codes below. 
        /// 
        private int getDigit(char c)
        {
            int v = 0;

            switch (c)
            {
                case '0': v = 0; break;
                case '1': v = 1; break;
                case '2': v = 2; break;
                case '3': v = 3; break;
                case '4': v = 4; break;
                case '5': v = 5; break;
                case '6': v = 6; break;
                case '7': v = 7; break;
                case '8': v = 8; break;
                case '9': v = 9; break;
                case 'A': v = 10; break;
                case 'B': v = 11; break;
                case 'C': v = 12; break;
                case 'D': v = 13; break;
                case 'E': v = 14; break;
                case 'F': v = 15; break;
            }
            return v;
        }

        CancellationTokenSource tokenSource = new CancellationTokenSource();

        private async void startHIDBridgeTask()
        {

            while (bContinue[TASK_HID_BRIDGE])
            {
                try
                {
                    // Establish the remote endpoint for the socket.  
                    // This example uses port 11000 on the local computer.
                    int bytesRec = 1;
                    IPAddress addr = IPAddress.Any;
                    socketHIDBridge = new Socket(
                            addr.AddressFamily,
                            SocketType.Stream,
                            ProtocolType.Tcp);
                    // Connect the socket to the address and port.
                    socketHIDBridge.Connect("192.168.1.101", 27015);
                    //socketHIDBridge.Connect("127.0.0.1", 27015);

                    // Send the data through the socket.  
                    //int bytesSent = sender.Send(msg);

                    // Receive the response from the remote device.
                    do
                    {
                        bytesRec = socketHIDBridge.Receive(AuthBridgeMsg);
                        if (bytesRec > 0)
                        {
                            sendtoBTBridge(AuthBridgeMsg, bytesRec);
                        }
                    } while (bytesRec > 0);
                }
                catch (ArgumentNullException) { }
                catch (SocketException) { }
                catch (Exception) { }

                // Release the socket.  
                if (socketHIDBridge != null)
                {
                    try
                    {
                        socketHIDBridge.Shutdown(SocketShutdown.Both);
                    }
                    catch (SocketException) { }
                    catch (ObjectDisposedException) { }

                    socketHIDBridge.Dispose();
                    socketHIDBridge = null;
                }
                // Loop until bContinue[TASK_HID_BRIDGE] = false
                if (bContinue[TASK_HID_BRIDGE] == true)
                {
                    try
                    {
                        await Task.Delay(5000, tokenSource.Token);
                    }
                    catch (ArgumentOutOfRangeException) { }
                    catch (TaskCanceledException) { }
                }
            }

            bContinue[TASK_HID_BRIDGE] = false;
            bExit[TASK_HID_BRIDGE] = true;
            if (bExit[TASK_BT_BRIDGE] == true)
            {
                Application.Current.Exit();
            }
        }

        private void startTasks()
        {
            Task taskHIDBRidge = Task.Factory.StartNew(() => startHIDBridgeTask());
            TaskList.Add(taskHIDBRidge);
            Debug.WriteLine("startTasks: Start taskHIDBRidge");
            //LogArea.Text = "startTasks: Start taskHIDBRidge";

            Task taskBTBRidge = Task.Factory.StartNew(() => startBTBridgeTask());
            TaskList.Add(taskBTBRidge);
            Debug.WriteLine("startTasks: Start taskBTBRidge");
            LogArea.Text = "startTasks: Start taskHIDBRidge" + System.Environment.NewLine + " + Start taskBTBRidge";
            //Task.WaitAll(TaskList.ToArray());
            //bContinue[TASK_HID_BRIDGE] = false;
            //bContinue[TASK_BT_BRIDGE] = false;

        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            bContinue[TASK_HID_BRIDGE] = false;
            bContinue[TASK_BT_BRIDGE] = false;
            if (socketHIDBridge != null)
            {
                try
                {
                    socketHIDBridge.Shutdown(SocketShutdown.Both);
                }
                catch (SocketException) { }
                catch (ObjectDisposedException) { }
                socketHIDBridge.Dispose();
            }
            tokenSource.Cancel();
        }

        private void StopButton_Click(object sender, RoutedEventArgs e)
        {
            LogArea.Text = "StopButton_Click";
        }
    }
}
