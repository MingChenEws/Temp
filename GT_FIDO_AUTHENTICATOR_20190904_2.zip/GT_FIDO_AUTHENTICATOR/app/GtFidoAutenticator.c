/*

Copyright (c) Microsoft Corporation.  All rights reserved.

    THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
    KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
    PURPOSE.

Module Name:

    GtFidoAutenticator.c

Environment:

    user mode only

Author:

*/

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <cfgmgr32.h>
#include <hidsdi.h>
#include "common.h"
#include <time.h>

#include <tchar.h>
#include <strsafe.h>

#include <winsock2.h>
#include <ws2tcpip.h>


//
// These are the default device attributes set in the driver
// which are used to identify the device.
//
#define HIDMINI_DEFAULT_PID              0xFEED
#define HIDMINI_DEFAULT_VID              0xDEED
#define TRACE printf								
//
// These are the device attributes returned by the mini driver in response
// to IOCTL_HID_GET_DEVICE_ATTRIBUTES.
//
#define HIDMINI_TEST_PID              0xDEED
#define HIDMINI_TEST_VID              0xFEED
#define HIDMINI_TEST_VERSION          0x0505

USAGE g_MyUsagePage = 0xF1D0;
USAGE g_MyUsage = 0x01;

#define USE_ALT_USAGE_PAGE "UseAltUsagePage"
#define INIT_NONCE_SIZE         8	// Size of channel initialization challenge


typedef enum
{
	U2FH_OK = 0,
	U2FH_MEMORY_ERROR = -1,
	U2FH_TRANSPORT_ERROR = -2,
	U2FH_JSON_ERROR = -3,
	U2FH_BASE64_ERROR = -4,
	U2FH_NO_U2F_DEVICE = -5,
	U2FH_AUTHENTICATOR_ERROR = -6,
	U2FH_TIMEOUT = -7,
	U2FH_NOTSATISFIED = -8,
	U2FH_NOTSUPPORTED = -9,
	U2FH_WRONG_DATA = -10,
	U2FH_UNKNOWN_ERROR = -99,
} u2fh_rc;
typedef struct
{
	UINT8 nonce[INIT_NONCE_SIZE];	// Client application nonce
	UINT32 cid;		// Channel identifier  
	UINT8 versionInterface;	// Interface version
	UINT8 versionMajor;	// Major version number
	UINT8 versionMinor;	// Minor version number
	UINT8 versionBuild;	// Build version number
	UINT8 capFlags;		// Capabilities flags  
} U2FHID_INIT_RESP;
//
// Function prototypes
//

BOOLEAN encodeLayerSession();
BOOLEAN encodeLayerTransFrame();
BOOLEAN encodeLayerTransEncap();

BOOLEAN decodeLayerSession();
BOOLEAN decodeLayerTransFrame();
unsigned char decodeLayerTransEncap();

VOID sendErrorResponse(unsigned char errCode);
VOID displayHexDump(UCHAR *buf);
VOID formatHexDump(UCHAR *buf);
int getDigit(char c);

//char bufData[] = "0504711F1870863EDF82F7AF8FEBD8C40F4CFD8D4AE479EF6DBC554B2E0714DE3B756B6C74327982484B140BE2085C95D4C990915058D1582F10F5803B5B2271CA0B408A6D37B187A7B49DBEDE689E4925F669E329EBDBF7A88CDE9A05D8FA128C17AABCA3983F0134CF6E0D21400D70663B09202FDF4F42AF192A0AA7515418A7B4A23082022E30820118A00302010202040A630BFF300B06092A864886F70D01010B302E312C302A0603550403132359756269636F2055324620526F6F742043412053657269616C203435373230303633313020170D3134303830313030303030305A180F32303530303930343030303030305A30293127302506035504030C1E59756269636F205532462045452053657269616C203137343236333239353059301306072A8648CE3D020106082A8648CE3D03010703420004A423645DBA8B23ED6CD9E5E48B932ACFDF4564C75731F1CF520745106B49BA960FAD0F0AA5093DEE33908445A816B8367CDD855712F349E566E63700D426D09FA3263024302206092B0601040182C40A020415312E332E362E312E342E312E34313438322E312E32300B06092A864886F70D01010B03820101006539B032A1CFC448D207AE149B0AB6B460CAA6501C133AF09A0EA4812F0A3E424A5CA4AEF53D47E9704CF7E2C013D70DE3CA148AB1459832254DB6515D4D959B6A8EF4E76B495158FAA75B17DA2D8BC08A0263C7B896525BA8A2EEA344E7D74729468FE250D8A678510EAB6D59251A961D8B3C32505293BD6EC24F92035902105440C6195CBFCC4192D16245FE95DEE595334E5F9BBB9FFE18E4432BFA5A8EC95542F6543A24FEB1A1AF6AE99A7DF98F5998B09E72BADCB87EBEA4B0E00333DC73CAB1842D8E475074652A48F51060713D0AAA7544D2DAB52840DEA243EA17732098346427EFBF6B6A55D300187CF0B7B42E7B06D05D1FF517101F31655161B4304502207898C31D93AEF0AC566B1919BBA0C59C897E55CBBB4B72DC50E5C4F06B99C89D022100F86ECACF3BF8FCB412F21EFE91748666AC91D8ED04C81F6A2CA0B491B0F35B0A9000";
BYTE respData[1024];

BOOLEAN
GetInputReport(
    HANDLE file
    );

BOOLEAN
SetOutputReport(
    HANDLE file
    );

BOOLEAN
CheckIfOurDevice(
    HANDLE file
    );

BOOLEAN
ReadInputData(
    _In_ HANDLE file
    );

BOOLEAN
WriteOutputData(
    _In_ HANDLE file
    );

VOID sendToPhoneAuthenticator(HANDLE file, PBYTE data, size_t len);
BOOLEAN sendResponse(HANDLE file, UINT32 cid, BYTE cmd, PBYTE reqData, size_t reqLen);

BOOLEAN
FindMatchingDevice(
    _In_ LPGUID   Guid,
    _Out_ HANDLE* Handle
    );

// General constants    

#define U2FHID_IF_VERSION       2	// Current interface implementation version
#define U2FHID_FRAME_TIMEOUT    500	// Default frame timeout in ms
#define U2FHID_TRANS_TIMEOUT    3000	// Default message timeout in ms

#define CID_BROADCAST           0xffffffff	// Broadcast channel id

#define TYPE_MASK               0x80	// Frame type mask
#define TYPE_INIT               0x80	// Initial frame identifier
#define TYPE_CONT               0x00	// Continuation frame identifier

// U2FHID native commands

#define U2FHID_PING         (TYPE_INIT | 0x01)	// Echo data through local processor only
#define U2FHID_MSG          (TYPE_INIT | 0x03)	// Send U2F message frame
#define U2FHID_LOCK         (TYPE_INIT | 0x04)	// Send lock channel command
#define U2FHID_INIT         (TYPE_INIT | 0x06)	// Channel initialization
#define U2FHID_WINK         (TYPE_INIT | 0x08)	// Send device identification wink
#define U2FHID_ERROR        (TYPE_INIT | 0x3f)	// Error response

#define U2FHID_VENDOR_FIRST (TYPE_INIT | 0x40)	// First vendor defined command
#define U2FHID_VENDOR_EXIT  (TYPE_INIT | 0x41)	// vendor EXIT
#define U2FHID_VENDOR_LAST  (TYPE_INIT | 0x7f)	// Last vendor defined command

#define TXRX_PACKET_SIZE		1024
#define HID_RPT_SIZE            64

#define APDU_CID_OFFSET         0
#define APDU_INIT_CMD_OFFSET    4
#define APDU_INIT_BCNTH_OFFSET  5
#define APDU_INIT_BCNTL_OFFSET  6
#define APDU_INIT_DATA_OFFSET   7
#define APDU_CONT_SEQNO_OFFSET  4
#define APDU_CONT_DATA_OFFSET   5
#define HID_REPORT_FRAME_SIZE	1

#define ERR_NONE                0x00	// No error
#define ERR_INVALID_CMD         0x01	// Invalid command
#define ERR_INVALID_PAR         0x02	// Invalid parameter
#define ERR_INVALID_LEN         0x03	// Invalid message length
#define ERR_INVALID_SEQ         0x04	// Invalid message sequencing
#define ERR_MSG_TIMEOUT         0x05	// Message has timed out
#define ERR_CHANNEL_BUSY        0x06	// Channel busy
#define ERR_LOCK_REQUIRED       0x0a	// Command requires channel lock
#define ERR_INVALID_CID         0x0b	// Command not allowed on this cid
#define ERR_OTHER               0x7f	// Other unspecified error

DWORD  mChanId;
DWORD  mChanIdPool = 0;
BYTE   mCmd;
char   mSeqNo;
PBYTE  pTxHIDFrame;
PBYTE  pTxReportFrame;
PBYTE  pRxHIDFrame;
PBYTE  pRxReportFrame;

size_t dataOffset;
size_t dataLen;

typedef struct {
	BYTE filler;
	BYTE cmd;
	short len;
	//int cid;
} AUTH_BRIDGE_MSG_HDR;
int MSGHDRLEN = sizeof(AUTH_BRIDGE_MSG_HDR);

typedef struct {
	AUTH_BRIDGE_MSG_HDR hdr;
	BYTE data[TXRX_PACKET_SIZE];
} AUTH_BRIDGE_MSG;
//AUTH_BRIDGE_MSG AuthBridgeMsgSend = { {0x00, U2FHID_MSG, 0, 0} };
AUTH_BRIDGE_MSG AuthBridgeMsgSend = { {0x00, U2FHID_MSG, 0} };
AUTH_BRIDGE_MSG AuthBridgeMsgRcvd;
//AUTH_BRIDGE_MSG_HDR AuthBridgeInit = { 0x00, U2FHID_INIT, 0, 0};
AUTH_BRIDGE_MSG_HDR AuthBridgeInit = { 0x00, U2FHID_INIT, 0 };

BYTE txData[TXRX_PACKET_SIZE];
BYTE rxData[TXRX_PACKET_SIZE];
BYTE tData[TXRX_PACKET_SIZE];
//BYTE rData[TXRX_PACKET_SIZE];
PBYTE rData = AuthBridgeMsgSend.data;

ULONG txLen;
size_t txAppLen;
size_t txAppDataSent;

ULONG rxLen;
size_t rxAppLen;
size_t rxAppDataRecv;

HANDLE fileHIDDriverSender = INVALID_HANDLE_VALUE;
HANDLE fileHIDDriverReceiver = INVALID_HANDLE_VALUE;

void ErrorHandler(LPTSTR lpszFunction);
DWORD WINAPI HIDDriverThread(LPVOID lpParam);
DWORD WINAPI HIDBridgeThread(LPVOID lpParam);

#define MAX_THREADS 2
#define THREAD_HID_DRIVER 0
#define THREAD_HID_BRIDGE 1

typedef struct ThreadData {
	int val1;
	int val2;
} THREAD_DATA, *PTHREAD_DATA;


BOOLEAN bLocked = TRUE;
BOOLEAN bContinue[MAX_THREADS] = { TRUE, TRUE };
PTHREAD_DATA pThreadDataArray[MAX_THREADS];
DWORD   dwThreadIdArray[MAX_THREADS];
HANDLE  hThreadArray[MAX_THREADS];

// Win Socket stuff

#undef UNICODE
//#define WIN32_LEAN_AND_MEAN

// Need to link with Ws2_32.lib
#pragma comment (lib, "Ws2_32.lib")
// #pragma comment (lib, "Mswsock.lib")

#define DEFAULT_BUFLEN TXRX_PACKET_SIZE
#define DEFAULT_PORT "27015"


SOCKET ListenSocket = INVALID_SOCKET;
SOCKET ClientSocket = INVALID_SOCKET;

//
// Implementation
//
INT __cdecl

main(
	_In_ ULONG argc,
	_In_reads_(argc) PCHAR argv[]
)
{
	UNREFERENCED_PARAMETER(argc);
	UNREFERENCED_PARAMETER(argv);

	// Create HID_BRIDGE Thread
	pThreadDataArray[THREAD_HID_BRIDGE] = (PTHREAD_DATA) HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY,
                sizeof(THREAD_DATA));
    if(pThreadDataArray[THREAD_HID_BRIDGE] == NULL )
    {
        ExitProcess(2);
    }

	hThreadArray[THREAD_HID_BRIDGE] = CreateThread(
		NULL,                   // default security attributes
		0,                      // use default stack size  
		HIDBridgeThread,       // thread function name
		pThreadDataArray[THREAD_HID_BRIDGE],          // argument to thread function 
		0,                      // use default creation flags 
		&dwThreadIdArray[THREAD_HID_BRIDGE]);   // returns the thread identifier 

	// Check the return value for success.
	// If CreateThread fails, terminate execution. 
	// This will automatically clean up threads and memory. 

	if (hThreadArray[THREAD_HID_BRIDGE] == NULL)
	{
		ErrorHandler(TEXT("Create THREAD_HID_BRIDGE"));
		ExitProcess(3);
	}

	// Create HID_DRIVER Thread
	pThreadDataArray[THREAD_HID_DRIVER] = (PTHREAD_DATA)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY,
		sizeof(THREAD_DATA));
	if (pThreadDataArray[THREAD_HID_DRIVER] == NULL)
	{
		ExitProcess(2);
	}

	hThreadArray[THREAD_HID_DRIVER] = CreateThread(
		NULL,                   // default security attributes
		0,                      // use default stack size  
		HIDDriverThread,       // thread function name
		pThreadDataArray[THREAD_HID_DRIVER],          // argument to thread function 
		0,                      // use default creation flags 
		&dwThreadIdArray[THREAD_HID_DRIVER]);   // returns the thread identifier 

	// Check the return value for success.
	// If CreateThread fails, terminate execution. 
	// This will automatically clean up threads and memory. 

	if (hThreadArray[THREAD_HID_DRIVER] == NULL)
	{
		ErrorHandler(TEXT("Create THREAD_HID_DRIVER"));
		ExitProcess(3);
	}

	// Wait until all threads have terminated.
	WaitForMultipleObjects(MAX_THREADS, hThreadArray, TRUE, INFINITE);

	// Close all thread handles and free memory allocations.
	for (int i = 0; i < MAX_THREADS; i++)
	{
		CloseHandle(hThreadArray[i]);
		if (pThreadDataArray[i] != NULL)
		{
			HeapFree(GetProcessHeap(), 0, pThreadDataArray[i]);
			pThreadDataArray[i] = NULL;    // Ensure address is not reused.
		}
	}

	printf("\nPress any key to exit MAIN..... ");
	getchar();
	return 0;
}

void ErrorHandler(LPTSTR lpszFunction)
{
	// Retrieve the system error message for the last-error code.

	LPVOID lpMsgBuf;
	LPVOID lpDisplayBuf;
	DWORD dw = GetLastError();

	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER |
		FORMAT_MESSAGE_FROM_SYSTEM |
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		dw,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf,
		0, NULL);

	// Display the error message.

	lpDisplayBuf = (LPVOID)LocalAlloc(LMEM_ZEROINIT,
		(lstrlen((LPCTSTR)lpMsgBuf) + lstrlen((LPCTSTR)lpszFunction) + 40) * sizeof(TCHAR));
	StringCchPrintf((LPTSTR)lpDisplayBuf,
		LocalSize(lpDisplayBuf) / sizeof(TCHAR),
		TEXT("%s failed with error %d: %s"),
		lpszFunction, dw, lpMsgBuf);
	MessageBox(NULL, (LPCTSTR)lpDisplayBuf, TEXT("Error"), MB_OK);

	// Free error-handling buffer allocations.

	LocalFree(lpMsgBuf);
	LocalFree(lpDisplayBuf);
}

/// HIDBridgeThread STARTS ////
DWORD WINAPI HIDBridgeThread(LPVOID lpParam)
{
	BOOLEAN bSuccess = FALSE;

	UNREFERENCED_PARAMETER(lpParam);

	WSADATA wsaData;
	int iResult;

	struct addrinfo *result = NULL;
	struct addrinfo hints;

	//char recvbuf[DEFAULT_BUFLEN];
	int recvbuflen = DEFAULT_BUFLEN+ MSGHDRLEN;

	// Initialize Winsock
	iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (iResult != 0) {
		printf("WSAStartup failed with error: %d\n", iResult);
		return 1;
	}

	while (bContinue[THREAD_HID_BRIDGE]) {
		// Start Listening socket
		ZeroMemory(&hints, sizeof(hints));
		hints.ai_family = AF_INET;
		hints.ai_socktype = SOCK_STREAM;
		hints.ai_protocol = IPPROTO_TCP;
		hints.ai_flags = AI_PASSIVE;

		// Resolve the server address and port
		iResult = getaddrinfo(NULL, DEFAULT_PORT, &hints, &result);
		if (iResult != 0) {
			printf("getaddrinfo failed with error: %d\n", iResult);
			WSACleanup();
			return 1;
		}

		// Create a SOCKET for connecting to server
		ListenSocket = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
		if (ListenSocket == INVALID_SOCKET) {
			printf("socket failed with error: %ld\n", WSAGetLastError());
			freeaddrinfo(result);
			WSACleanup();
			return 1;
		}

		// Setup the TCP listening socket
		iResult = bind(ListenSocket, result->ai_addr, (int)result->ai_addrlen);
		if (iResult == SOCKET_ERROR) {
			printf("bind failed with error: %d\n", WSAGetLastError());
			freeaddrinfo(result);
			closesocket(ListenSocket);
			WSACleanup();
			return 1;
		}

		freeaddrinfo(result);

		iResult = listen(ListenSocket, SOMAXCONN);
		if (iResult == SOCKET_ERROR) {
			printf("listen failed with error: %d\n", WSAGetLastError());
			closesocket(ListenSocket);
			WSACleanup();
			return 1;
		}

		printf("Start Listening socket...\n");
		// Accept a client socket
		ClientSocket = accept(ListenSocket, NULL, NULL);
		if (ClientSocket == INVALID_SOCKET) {
			printf("accept failed with error: %d\n", WSAGetLastError());
			closesocket(ListenSocket);
			WSACleanup();
			printf("...Exit THREAD_HID_BRIDGE [%d]\n", bSuccess);
			return 1;
		}

		// No longer need server socket
		closesocket(ListenSocket);
		ListenSocket = INVALID_SOCKET;
		printf("HID Bridge socket connected!!\n");

		// Receive until the peer shuts down the connection
		do {

			iResult = recv(ClientSocket, (char*)&AuthBridgeMsgRcvd, recvbuflen, 0);
			if (iResult > 0) {
				printf("Received from BRIDGE: Bytes received: %d\n", iResult);
				//printf("%02x%02x%04x%08x (%d:%d)\n", AuthBridgeMsgRcvd.hdr.filler, AuthBridgeMsgRcvd.hdr.cmd,
				//	AuthBridgeMsgRcvd.hdr.len, AuthBridgeMsgRcvd.hdr.cid, AuthBridgeMsgRcvd.hdr.len, AuthBridgeMsgRcvd.hdr.cid);
				printf("%02x%02x%04x (%d)\n", AuthBridgeMsgRcvd.hdr.filler, AuthBridgeMsgRcvd.hdr.cmd,
					AuthBridgeMsgRcvd.hdr.len, AuthBridgeMsgRcvd.hdr.len);
				displayHexDump(AuthBridgeMsgRcvd.data);
				//sendResponse(fileHIDDriverSender, AuthBridgeMsgRcvd.hdr.cid, U2FHID_MSG, (PBYTE)AuthBridgeMsgRcvd.data, (size_t)(iResult- MSGHDRLEN));
				sendResponse(fileHIDDriverSender, mChanId, U2FHID_MSG, (PBYTE)AuthBridgeMsgRcvd.data, (size_t)(iResult - MSGHDRLEN));
			}
			else 
			{
				printf("Connection closing or recv failed with error: %d\n", WSAGetLastError());
				closesocket(ClientSocket);
				ClientSocket = INVALID_SOCKET;
			}

		} while (iResult > 0);

		// shutdown the connection since we're done
		if (bContinue[THREAD_HID_BRIDGE] == FALSE) { // Close by HID Driver thread
			if (ClientSocket != INVALID_SOCKET) {
				iResult = shutdown(ClientSocket, SD_SEND);
				if (iResult == SOCKET_ERROR) {
					printf("shutdown failed with error: %d\n", WSAGetLastError());
				}
				// cleanup
				closesocket(ClientSocket);
				ClientSocket = INVALID_SOCKET;
			}
		}
	} // End of While loop
	
	WSACleanup();
	printf("...Exit THREAD_HID_BRIDGE [%d]\n", bSuccess);
	return (bSuccess ? 0 : 1);
}
/// HIDBridgeThread ENDS ////

/// HIDDriverThread STARTS ////
DWORD WINAPI HIDDriverThread(LPVOID lpParam)
{
    GUID hidguid;
    BOOLEAN found = FALSE;
    BOOLEAN bSuccess = FALSE;
	BOOLEAN bOkToProcess = FALSE;
	int iSendResult = 0;
	UNREFERENCED_PARAMETER(lpParam);

	memset(txData, 0, TXRX_PACKET_SIZE);
	memset(rxData, 0, TXRX_PACKET_SIZE);
	pTxReportFrame = &txData[0];
	pTxHIDFrame = &txData[HID_REPORT_FRAME_SIZE];
	pRxReportFrame = &rxData[0];
	pRxHIDFrame = &rxData[HID_REPORT_FRAME_SIZE];

    srand( (unsigned)time( NULL ) );

    HidD_GetHidGuid(&hidguid);

    found = FindMatchingDevice(&hidguid, &fileHIDDriverReceiver);
    if (found) {
        printf("...sending control request to our device\n");

		while (bContinue[THREAD_HID_DRIVER]) {

			mSeqNo = -1;  // starting from 0 or -1???
			rxAppLen = 0;
			rxAppDataRecv = 0;
			rxLen = HID_RPT_SIZE + 1;
			//rxLen = HID_RPT_SIZE;
			pRxReportFrame[0] = 0;
			pRxReportFrame[1] = 0;
			bOkToProcess = TRUE;

			do {
				//
				// Send Hid control code
				//
				printf("in HidD_GetInputReport loop\n");
				bSuccess = HidD_GetInputReport(fileHIDDriverReceiver,  // HidDeviceObject,
					pRxReportFrame,    // ReportBuffer,
					rxLen // ReportBufferLength
				);
				if (!bSuccess)
				{
					printf("failed HidD_GetInputReport\n");
					bOkToProcess = FALSE;
					bContinue[THREAD_HID_DRIVER] = FALSE;
					break;
				}
				else
				{
					printf("Received following data in input report:\n");
					displayHexDump(pRxHIDFrame);
				}

				if (!decodeLayerSession()) {
					bOkToProcess = FALSE;
					sendErrorResponse(ERR_INVALID_PAR);
					break;
				}
				if (!decodeLayerTransFrame()) {
					bOkToProcess = FALSE;
					sendErrorResponse(ERR_INVALID_PAR);
					break;
				}
				unsigned char errCode = decodeLayerTransEncap();
				if (errCode != ERR_NONE) {
					bOkToProcess = FALSE;
					sendErrorResponse(errCode);
					break;
				}

				if ((rxAppLen - rxAppDataRecv) < dataLen)
					dataLen = rxAppLen - rxAppDataRecv;
				memcpy(&rData[rxAppDataRecv], &pRxHIDFrame[dataOffset], dataLen);
				rxAppDataRecv += dataLen;

				mSeqNo++;

			} while (rxAppLen > rxAppDataRecv);

			TRACE("Finished READ, rxAppLen=%d, mChanId=0x%08x, mCmd=0x%02x, bOkToProcess=%d\n",
				(int)rxAppLen, mChanId, mCmd, bOkToProcess);

			if (bOkToProcess) {
				rData[rxAppLen] = 0;
				if (mCmd == U2FHID_VENDOR_EXIT)
				{
					bContinue[THREAD_HID_DRIVER] = FALSE;
				}
				else
				{
					if (ClientSocket != INVALID_SOCKET)
					{
						if (mChanId == CID_BROADCAST) {
							switch (mCmd) {
							case U2FHID_INIT:
								// Assign Channel ID
								iSendResult = send(ClientSocket, (char*)&AuthBridgeInit, MSGHDRLEN, 0);
								if (iSendResult == SOCKET_ERROR) {
									printf("send failed with error: %d\n", WSAGetLastError());
									closesocket(ClientSocket);
								}
								else
								{
									mChanId = ++mChanIdPool;
									U2FHID_INIT_RESP initresp;
									memset(&initresp, 0, sizeof(initresp));
									memcpy(initresp.nonce, rData, sizeof(initresp.nonce));
									initresp.cid = mChanId;
									initresp.versionInterface = 0x02;
									initresp.versionMajor = 0x01;
									initresp.versionMinor = 0x01;
									initresp.versionBuild = 0x00;
									initresp.capFlags = 0x01;
									txLen = 17;
									memcpy(tData, &initresp, txLen);
									//sendResponse(fileHIDDriverReceiver, CID_BROADCAST, U2FHID_INIT, tData, txLen);
									sendResponse(fileHIDDriverSender, CID_BROADCAST, U2FHID_INIT, tData, txLen);
								}
								break;
							case U2FHID_PING:
								printf("Received PING from driver!\n");
								//sendResponse(fileHIDDriverSender, CID_BROADCAST, U2FHID_PING, rData, rxAppLen);
								break;
							default:
								sendErrorResponse(ERR_INVALID_CID);
								break;
							}
						}
						else { // Other Message
							switch (mCmd) {
							case U2FHID_MSG:
								sendToPhoneAuthenticator(fileHIDDriverSender, rData, rxAppLen);
								break;
							default:
								sendErrorResponse(ERR_INVALID_CMD);
								break;
							}
						}
					}
					else
					{
						if (mCmd == U2FHID_PING) {
							printf("Received PING from driver!\n");
						} else {
							sendErrorResponse(ERR_CHANNEL_BUSY);
						}
					}
				}
			}
		} // While loop
		mSeqNo = -1;  // starting from 0 or -1???
    }
    else {
        printf("Failure: Could not find our HID device \n");
    }

//cleanup:

    if (found && bSuccess == FALSE) {
        printf("****** Failure: one or more commands to device failed *******\n");
    }

    if (fileHIDDriverReceiver != INVALID_HANDLE_VALUE) {
        CloseHandle(fileHIDDriverReceiver);
    }
	if (fileHIDDriverSender != INVALID_HANDLE_VALUE) {
		CloseHandle(fileHIDDriverSender);
	}
	printf("...Exit THREAD_HID_DRIVER [%d]\n", bSuccess);
	//getchar();
	// Shutdown BRIDGE thread
	if (ListenSocket != INVALID_SOCKET) {
		int iResult = shutdown(ListenSocket, SD_RECEIVE);
		if (iResult == SOCKET_ERROR) {
			printf("shutdown failed with error: %d\n", WSAGetLastError());
		}
		// cleanup
		closesocket(ListenSocket);
	}
	else {
		if (ClientSocket != INVALID_SOCKET) {
			int iResult = shutdown(ClientSocket, SD_SEND);
			if (iResult == SOCKET_ERROR) {
				printf("shutdown failed with error: %d\n", WSAGetLastError());
			}
			// cleanup
			closesocket(ClientSocket);
		}
	}

	bContinue[THREAD_HID_BRIDGE] = FALSE;

    return (bSuccess ? 0 : 1);
}

VOID sendErrorResponse(unsigned char errCode)
{
	sendResponse(fileHIDDriverSender, mChanId, U2FHID_ERROR, &errCode, 1);
}

VOID sendToPhoneAuthenticator(HANDLE file, PBYTE data, size_t len) {

	switch (data[1]) {
	case 0x03: // FIDO Version Query
		memset(respData, 0, sizeof(respData));
		respData[0] = 0x55;  // U
		respData[1] = 0x32;  // 2
		respData[2] = 0x46;  // F
		respData[3] = 0x5F;  // _
		respData[4] = 0x56;  // V
		respData[5] = 0x32;  // 2
		respData[6] = 0x90;  // SUCCESS code
		respData[7] = 0x00;  //
		txLen = 8;
		sendResponse(file, mChanId, U2FHID_MSG, respData, txLen);
		break;
	case 0x01: // FIDO Registration Messages
	case 0x02: // FIDO Authentication Messages
		AuthBridgeMsgSend.hdr.len = (short)len;
		//AuthBridgeMsgSend.hdr.cid = mChanId;
		//printf("%02x%02x%04x%08x (%d:%d)\n", AuthBridgeMsgSend.hdr.filler, AuthBridgeMsgSend.hdr.cmd,
		//	AuthBridgeMsgSend.hdr.len, AuthBridgeMsgSend.hdr.cid, AuthBridgeMsgSend.hdr.len, AuthBridgeMsgSend.hdr.cid);
		printf("%02x%02x%04x (%d)\n", AuthBridgeMsgSend.hdr.filler, AuthBridgeMsgSend.hdr.cmd,
			AuthBridgeMsgSend.hdr.len, AuthBridgeMsgSend.hdr.len);
		int iSendResult = send(ClientSocket, (char*)&AuthBridgeMsgSend, (int)(len+ MSGHDRLEN), 0);
		if (iSendResult == SOCKET_ERROR) {
			printf("send failed with error: %d\n", WSAGetLastError());
			closesocket(ClientSocket);
		}
		else {
			printf("Send to BRIDGE: Bytes sent: %d\n", iSendResult);
		}
		break;
	default:
		printf("FAILED HERE data[1]=%02x\n", data[1]);
		break;
	}
	
}

int getDigit(char c) {
	int v = 0;

	switch (c) {
	case '0': v = 0; break;
	case '1': v = 1; break;
	case '2': v = 2; break;
	case '3': v = 3; break;
	case '4': v = 4; break;
	case '5': v = 5; break;
	case '6': v = 6; break;
	case '7': v = 7; break;
	case '8': v = 8; break;
	case '9': v = 9; break;
	case 'A': v = 10; break;
	case 'B': v = 11; break;
	case 'C': v = 12; break;
	case 'D': v = 13; break;
	case 'E': v = 14; break;
	case 'F': v = 15; break;
	}
	return v;
}

BOOLEAN
FindMatchingDevice(
    _In_  LPGUID  InterfaceGuid,
    _Out_ HANDLE* Handle
)
{
    CONFIGRET cr = CR_SUCCESS;
    PWSTR deviceInterfaceList = NULL;
    ULONG deviceInterfaceListLength = 0;
    PWSTR currentInterface;
    BOOLEAN bRet = FALSE;
    HANDLE devHandle = INVALID_HANDLE_VALUE;

    if (NULL == Handle) {
        printf("Error: Invalid device handle parameter\n");
        return FALSE;
    }

    *Handle = INVALID_HANDLE_VALUE;

    cr = CM_Get_Device_Interface_List_Size(
            &deviceInterfaceListLength,
            InterfaceGuid,
            NULL,
            CM_GET_DEVICE_INTERFACE_LIST_PRESENT);
    if (cr != CR_SUCCESS) {
        printf("Error 0x%x retrieving device interface list size.\n", cr);
        goto clean0;
    }

    if (deviceInterfaceListLength <= 1) {
        bRet = FALSE;
        printf("Error: No active device interfaces found.\n"
            " Is the sample driver loaded?");
        goto clean0;
    }

    deviceInterfaceList = (PWSTR)malloc(deviceInterfaceListLength * sizeof(WCHAR));
    if (deviceInterfaceList == NULL) {
        printf("Error allocating memory for device interface list.\n");
        goto clean0;
    }
    ZeroMemory(deviceInterfaceList, deviceInterfaceListLength * sizeof(WCHAR));

    cr = CM_Get_Device_Interface_List(
            InterfaceGuid,
            NULL,
            deviceInterfaceList,
            deviceInterfaceListLength,
            CM_GET_DEVICE_INTERFACE_LIST_PRESENT);
    if (cr != CR_SUCCESS) {
        printf("Error 0x%x retrieving device interface list.\n", cr);
        goto clean0;
    }

    //
    // Enumerate devices of this interface class
    //
    printf("\n....looking for our HID device (with UP=0x%04X "
        "and Usage=0x%02X)\n", g_MyUsagePage, g_MyUsage);

    for (currentInterface = deviceInterfaceList;
        *currentInterface;
        currentInterface += wcslen(currentInterface) + 1) {

        devHandle = CreateFile(currentInterface,
                        GENERIC_READ | GENERIC_WRITE,
                        FILE_SHARE_READ | FILE_SHARE_WRITE,
                        NULL, // no SECURITY_ATTRIBUTES structure
                        OPEN_EXISTING, // No special create flags
                        0, // No special attributes
                        NULL); // No template file

        if (INVALID_HANDLE_VALUE == devHandle) {
            printf("Warning: CreateFile failed: %d\n", GetLastError());
            continue;
        }

        if (CheckIfOurDevice(devHandle)) {
            bRet = TRUE;
            *Handle = devHandle;

			// Duplicate a Sender Handle
			fileHIDDriverSender = CreateFile(currentInterface,
				GENERIC_READ | GENERIC_WRITE,
				FILE_SHARE_READ | FILE_SHARE_WRITE,
				NULL, // no SECURITY_ATTRIBUTES structure
				OPEN_EXISTING, // No special create flags
				0, // No special attributes
				NULL); // No template file

			if (INVALID_HANDLE_VALUE == fileHIDDriverSender) {
				printf("Warning: CreateFile failed: %d\n", GetLastError());
				continue;
			}
        }
        else {
            CloseHandle(devHandle);
        }
    }

clean0:
    if (deviceInterfaceList != NULL) {
        free(deviceInterfaceList);
    }
    if (CR_SUCCESS != cr) {
        bRet = FALSE;
    }
    return bRet;
}

BOOLEAN
CheckIfOurDevice(
    HANDLE file)
{
    PHIDP_PREPARSED_DATA Ppd; // The opaque parser info describing this device
    HIDP_CAPS                       Caps; // The Capabilities of this hid device.
    HIDD_ATTRIBUTES attr; // Device attributes

    if (!HidD_GetAttributes(file, &attr))
    {
        printf("Error: HidD_GetAttributes failed \n");
        return FALSE;
    }

    printf("Device Attributes - PID: 0x%x, VID: 0x%x \n", attr.ProductID, attr.VendorID);
    if ((attr.VendorID != HIDMINI_DEFAULT_VID) || (attr.ProductID != HIDMINI_DEFAULT_PID))
    {
        printf("Device attributes doesn't match the sample \n");
        return FALSE;
    }

    if (!HidD_GetPreparsedData (file, &Ppd))
    {
        printf("Error: HidD_GetPreparsedData failed \n");
        return FALSE;
    }

    if (!HidP_GetCaps (Ppd, &Caps))
    {
        printf("Error: HidP_GetCaps failed \n");
        HidD_FreePreparsedData (Ppd);
        return FALSE;
    }

    if ((Caps.UsagePage == g_MyUsagePage) && (Caps.Usage == g_MyUsage)){
        printf("Success: Found my device.. \n");
        return TRUE;

    }

    return FALSE;

}

BOOLEAN
GetInputReport(
    HANDLE file
    )
{
    ULONG bufferSize;
    PUCHAR buffer;
    BOOLEAN bSuccess;

    //
    // Allocate memory
    //
    bufferSize = sizeof(HIDMINI_INPUT_REPORT);
    buffer = (PUCHAR) malloc (bufferSize);
    if (!buffer )
    {
        printf("malloc failed\n");
        return FALSE;
    }

    ZeroMemory(buffer, bufferSize);

    //
    // Fill the first byte with report ID of collection
    //
    buffer[0] = CONTROL_COLLECTION_REPORT_ID;

    //
    // Send Hid control code
    //
    bSuccess = HidD_GetInputReport(file,  // HidDeviceObject,
                               buffer,    // ReportBuffer,
                               bufferSize // ReportBufferLength
                               );
    if (!bSuccess)
    {
        printf("failed HidD_GetInputReport\n");
    }
    else
    {
        printf("Received following data in input report:\n");
		displayHexDump(((PHIDMINI_INPUT_REPORT)buffer)->Data);
    }

    free(buffer);
    return bSuccess;
}


BOOLEAN
SetOutputReport(
    HANDLE file
    )
{
    ULONG bufferSize;
    PHIDMINI_OUTPUT_REPORT buffer;
    BOOLEAN bSuccess;

    //
    // Allocate memory
    //
    bufferSize = sizeof(HIDMINI_OUTPUT_REPORT);
    buffer = (PHIDMINI_OUTPUT_REPORT) malloc (bufferSize);
    if (!buffer )
    {
        printf("malloc failed\n");
        return FALSE;
    }

    ZeroMemory(buffer, bufferSize);

    //
    // Fill the report
    //
    buffer->ReportId = CONTROL_COLLECTION_REPORT_ID;
	for (int i = 0; i < 64; i++) {
		buffer->Data[i] = (UCHAR)(rand() % UCHAR_MAX);

	}
	printf("SetOutputReport buffer->Data:\n");
	displayHexDump(buffer->Data);

    //
    // Send Hid control code
    //
    bSuccess = HidD_SetOutputReport(file,  // HidDeviceObject,
                               buffer,    // ReportBuffer,
                               bufferSize // ReportBufferLength
                               );
    if (!bSuccess)
    {
        printf("failed HidD_SetOutputReport\n");
    }
    else
    {
		printf("Set following data in output report:\n");
		displayHexDump(((PHIDMINI_OUTPUT_REPORT) buffer)->Data);
    }

    free(buffer);
    return bSuccess;
}

BOOLEAN
ReadInputData(
    _In_ HANDLE file
    )
{
    PHIDMINI_INPUT_REPORT report;
    ULONG bufferSize;
    BOOL bSuccess;
    DWORD bytesRead;

    //
    // Allocate memory
    //
    bufferSize = sizeof(HIDMINI_INPUT_REPORT);
    report = (PHIDMINI_INPUT_REPORT) malloc (bufferSize);
    if (!report )
    {
        printf("malloc failed\n");
        return FALSE;
    }

    ZeroMemory(report, bufferSize);

    report->ReportId = CONTROL_COLLECTION_REPORT_ID;

    //
    // get input data.
    //
    bSuccess = ReadFile(
              file,        // HANDLE hFile,
              report,      // LPVOID lpBuffer,
              bufferSize,  // DWORD nNumberOfBytesToRead,
              &bytesRead,  // LPDWORD lpNumberOfBytesRead,
              NULL         // LPOVERLAPPED lpOverlapped
            );

    if (!bSuccess)
    {
        printf("failed ReadFile \n");
    }
    else
    {
        printf("Read following byte from device: rid=%d\n", report->ReportId);
		displayHexDump(report->Data);
    }

    free(report);

    return (BOOLEAN) bSuccess;
}

BOOLEAN
WriteOutputData(
    _In_ HANDLE file
    )
{
    PHIDMINI_OUTPUT_REPORT outputReport;
    ULONG outputReportSize;
    BOOL bSuccess;
    DWORD bytesWritten;

    //
    // Allocate memory for outtput report
    //
    outputReportSize = sizeof(HIDMINI_OUTPUT_REPORT);
    outputReport = (PHIDMINI_OUTPUT_REPORT) malloc (outputReportSize);
    if (!outputReport )
    {
        printf("malloc failed\n");
        return FALSE;
    }

    ZeroMemory(outputReport, outputReportSize);

    outputReport->ReportId = CONTROL_COLLECTION_REPORT_ID;
	for (int i = 0; i < 64; i++) {
		outputReport->Data[i] = (UCHAR)(rand() % UCHAR_MAX);
	}
	printf("WriteOutputData buffer->Data:\n");
	displayHexDump(outputReport->Data);

    //
    // Wrute output data.
    //
    bSuccess = WriteFile(
              file,        // HANDLE hFile,
              (PVOID) outputReport,      // LPVOID lpBuffer,
              outputReportSize,  // DWORD nNumberOfBytesToRead,
              &bytesWritten,  // LPDWORD lpNumberOfBytesRead,
              NULL         // LPOVERLAPPED lpOverlapped
            );

    if (!bSuccess)
    {
        printf("failed WriteFile \n");
    }
    else
    {
		printf("Wrote following byte to device:\n");
		displayHexDump(outputReport->Data);
    }

    free(outputReport);

    return (BOOLEAN) bSuccess;
}

BOOLEAN sendResponse(HANDLE file, UINT32 cid, BYTE cmd, PBYTE reqData, size_t reqLen)
{
	BOOLEAN bSuccess;

	mChanId = cid;
	mCmd = cmd;
	mSeqNo = -1;  // starting from 0 or -1????
	txAppLen = reqLen;
	txAppDataSent = 0;
	txLen = HID_RPT_SIZE + 1;
	pTxReportFrame[0] = CONTROL_COLLECTION_REPORT_ID;

	do
	{
		encodeLayerTransEncap();
		encodeLayerTransFrame();
		encodeLayerSession();

		if ((reqLen - txAppDataSent) < dataLen)
			dataLen = reqLen - txAppDataSent;
		memcpy(&pTxHIDFrame[dataOffset], &reqData[txAppDataSent], dataLen);
		txAppDataSent += dataLen;

		TRACE("Before WriteFile, txAppDataSent=%d\n", (int)txAppDataSent);

		//
		// Send Hid control code
		//
		bSuccess = HidD_SetOutputReport(file,  // HidDeviceObject,
			pTxReportFrame,    // ReportBuffer,
			txLen // ReportBufferLength
		);
		if (!bSuccess)
		{
			printf("failed HidD_SetOutputReport\n");
		}
		else
		{
			printf("Set following data in output report:\n");
			displayHexDump(pTxHIDFrame);
		}

		mSeqNo++;
		Sleep(50);
	} while (reqLen > txAppDataSent);

	TRACE("Finished WRITE, reqLen=%d\n", (int)reqLen);
	mSeqNo = -1;  // starting from 0 or -1???
	return bSuccess;
}

BOOLEAN encodeLayerSession()
{
	memcpy(&pTxHIDFrame[APDU_CID_OFFSET], &mChanId, sizeof(mChanId));
	return TRUE;
}

BOOLEAN encodeLayerTransFrame()
{
	pTxReportFrame[0] = 0;
	//pTxReportFrame[0] = 1; // Report ID must be 1-255
	return TRUE;
}

BOOLEAN encodeLayerTransEncap()
{
	if (mSeqNo < 0) // Initial Frame
	{
		dataOffset = APDU_INIT_DATA_OFFSET; // cid + cmd + bcnth + bcntl
		pTxHIDFrame[APDU_INIT_CMD_OFFSET] = mCmd;
		pTxHIDFrame[APDU_INIT_BCNTH_OFFSET] = (txAppLen >> 8) & 0xff;
		pTxHIDFrame[APDU_INIT_BCNTL_OFFSET] = txAppLen & 0xff;
	}
	else // Continuous Frame
	{
		dataOffset = APDU_CONT_DATA_OFFSET; // cid + seq
		pTxHIDFrame[APDU_CONT_SEQNO_OFFSET] = mSeqNo;
	}
	dataLen = HID_RPT_SIZE - dataOffset;
	return TRUE;
}

BOOLEAN decodeLayerSession()
{
	memcpy(&mChanId, &pRxHIDFrame[APDU_CID_OFFSET], sizeof(mChanId));
	printf("decodeLayerSession, mChanId=0x%08x\n", mChanId);
	return TRUE;
}

BOOLEAN decodeLayerTransFrame()
{
	return TRUE;
}

unsigned char decodeLayerTransEncap()
{
	if (mSeqNo < 0) // Initial Frame
	{
		BYTE cmd = pRxHIDFrame[APDU_INIT_CMD_OFFSET];
		//switch (pRxHIDFrame[APDU_INIT_CMD_OFFSET])
		switch (cmd)
		{
			case U2FHID_INIT:
				// mChanId should have set in the decodeLayerSession()
				if (mChanId != CID_BROADCAST)
				{
					return ERR_INVALID_CID;
				}
				break;
			case U2FHID_MSG:
			case U2FHID_PING:
			case U2FHID_VENDOR_EXIT:
				break;
			default:
				return ERR_INVALID_CMD;
				break;
		}

		mCmd = pRxHIDFrame[APDU_INIT_CMD_OFFSET];
		rxAppLen = pRxHIDFrame[APDU_INIT_BCNTH_OFFSET] << 8 | pRxHIDFrame[APDU_INIT_BCNTL_OFFSET];
		TRACE("pRxHIDFrame[APDU_INIT_CMD_OFFSET]=0x%02x, mCmd=0x%02x, rxAppLen=%d\n", 
			pRxHIDFrame[APDU_INIT_CMD_OFFSET], mCmd,  (int)rxAppLen);

		if ((rxAppLen + rxAppLen % HID_RPT_SIZE) > TXRX_PACKET_SIZE)
			return ERR_INVALID_LEN;

		dataOffset = 7; // set to INIT Frame size // cid + cmd + bcnh + bcnl
	}
	else // Continuous Frame
	{
		// May need to check CID too

		// Chech Sequence Number
		TRACE("pRxHIDFrame[APDU_CONT_SEQNO_OFFSET]=0x%02x, mSeqNo = 0x%02x\n", pRxHIDFrame[APDU_CONT_SEQNO_OFFSET], mSeqNo);
		if (pRxHIDFrame[APDU_CONT_SEQNO_OFFSET] != mSeqNo)
			return ERR_INVALID_SEQ;

		dataOffset = 5; // set to CONT Frame size // cid + seq
	}
	dataLen = HID_RPT_SIZE - dataOffset;

	return ERR_NONE;
}


char hexDump1[65];
char hexDump2[65];
VOID displayHexDump(UCHAR *buf) {
	formatHexDump(buf);
	printf("%s\n", hexDump1);
	printf("%s\n", hexDump2);
}
VOID formatHexDump(UCHAR *buf) {
	int i = 0;

	for (i = 0; i < 32; i++) {
		sprintf_s(&hexDump1[2 * i], 3, "%02x", buf[i]);
	}
	hexDump1[64] = 0;
	for (i = 0; i < 32; i++) {
		sprintf_s(&hexDump2[2 * i], 3, "%02x", buf[32 + i]);
	}
	hexDump2[64] = 0;
}
/// HIDDriverThread ENDS ////