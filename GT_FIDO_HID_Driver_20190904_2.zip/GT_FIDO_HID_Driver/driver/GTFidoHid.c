/*++

Copyright (C) Microsoft Corporation, All Rights Reserved.

Module Name:

    GTFidoHid.cpp

Abstract:

    This module contains the implementation of the driver

Environment:

    Windows Driver Framework (WDF)

--*/

#include "GTFidoHid.h"

//
// This is the default report descriptor for the virtual Hid device returned
// by the mini driver in response to IOCTL_HID_GET_REPORT_DESCRIPTOR.
//
HID_REPORT_DESCRIPTOR       G_DefaultReportDescriptor[] = {
	0x06,0xD0, 0xF1,                // USAGE_PAGE (Vender Defined Usage Page)

	0x09,0x01,                      // USAGE (Vendor Usage 0x01)
	0xA1,0x01,                      // COLLECTION (Application)

	//0x85,0x01,                         // REPORT_ID (1) For FIDO, NO Report Id
	0x15,0x00,                         // LOGICAL_MINIMUM(0)
	0x26,0xff, 0x00,                   // LOGICAL_MAXIMUM(255)

	0x09,0x01,                         // USAGE (Vendor Usage 0x01)
	0x75,0x08,                         // REPORT_SIZE (0x08)
	0x96,(INPUT_REPORT_SIZE_CB & 0xff), (INPUT_REPORT_SIZE_CB >> 8), // REPORT_COUNT
	0x81,0x00,                         // INPUT (Data,Ary,Abs)

	0x09,0x01,                         // USAGE (Vendor Usage 0x01)
	0x75,0x08,                         // REPORT_SIZE (0x08)
	0x96,(OUTPUT_REPORT_SIZE_CB & 0xff), (OUTPUT_REPORT_SIZE_CB >> 8), // REPORT_COUNT
	0x91,0x00,                         // OUTPUT (Data,Ary,Abs)

	0xC0,                           // END_COLLECTION
};

//
// This is the default HID descriptor returned by the mini driver
// in response to IOCTL_HID_GET_DEVICE_DESCRIPTOR. The size
// of report descriptor is currently the size of G_DefaultReportDescriptor.
//

HID_DESCRIPTOR              G_DefaultHidDescriptor = {
	0x09,   // length of HID descriptor
	0x21,   // descriptor type == HID  0x21
	0x0100, // hid spec release
	0x00,   // country code == Not Specified
	0x01,   // number of HID class descriptors
	{                                       //DescriptorList[0]
		0x22,                               //report descriptor type 0x22
		sizeof(G_DefaultReportDescriptor)   //total length of report descriptor
	}
};

WDFREQUEST              AUTHENTICATOR_REQUEST = (WDFREQUEST)NULL;

#define WRITE_REPORT_DATA_QUEUE_SIZE 24
BYTE    WriteReportDataQueue[WRITE_REPORT_DATA_QUEUE_SIZE][64];
UINT32 inIdx = 0;
UINT32 outIdx = 0;
BOOLEAN bAuthenticatorUp = FALSE;

EVT_WDF_TIMER            AuthenticatorLinkTimerFunc;
WDFTIMER                 AuthenticatorLinkTimer;
EVT_WDF_TIMER            AuthenticatorPingTimerFunc;
WDFTIMER                 AuthenticatorPingTimer;

NTSTATUS
DriverEntry(
	_In_  PDRIVER_OBJECT    DriverObject,
	_In_  PUNICODE_STRING   RegistryPath
)
/*++

Routine Description:
	DriverEntry initializes the driver and is the first routine called by the
	system after the driver is loaded. DriverEntry specifies the other entry
	points in the function driver, such as EvtDevice and DriverUnload.

Parameters Description:

	DriverObject - represents the instance of the function driver that is loaded
	into memory. DriverEntry must initialize members of DriverObject before it
	returns to the caller. DriverObject is allocated by the system before the
	driver is loaded, and it is released by the system after the system unloads
	the function driver from memory.

	RegistryPath - represents the driver specific path in the Registry.
	The function driver can use the path to store driver related data between
	reboots. The path does not store hardware instance specific data.

Return Value:

	STATUS_SUCCESS, or another status value for which NT_SUCCESS(status) equals
					TRUE if successful,

	STATUS_UNSUCCESSFUL, or another status for which NT_SUCCESS(status) equals
					FALSE otherwise.

--*/
{
	WDF_DRIVER_CONFIG       config;
	NTSTATUS                status;

	KdPrint(("DriverEntry for VHidMini\n"));

#ifdef _KERNEL_MODE
	//
	// Opt-in to using non-executable pool memory on Windows 8 and later.
	// https://msdn.microsoft.com/en-us/library/windows/hardware/hh920402(v=vs.85).aspx
	//
	ExInitializeDriverRuntime(DrvRtPoolNxOptIn);
#endif

	WDF_DRIVER_CONFIG_INIT(&config, EvtDeviceAdd);

	status = WdfDriverCreate(DriverObject,
		RegistryPath,
		WDF_NO_OBJECT_ATTRIBUTES,
		&config,
		WDF_NO_HANDLE);
	if (!NT_SUCCESS(status)) {
		KdPrint(("Error: WdfDriverCreate failed 0x%x\n", status));
		return status;
	}

	return status;
}

NTSTATUS
EvtDeviceAdd(
	_In_  WDFDRIVER         Driver,
	_Inout_ PWDFDEVICE_INIT DeviceInit
)
/*++
Routine Description:

	EvtDeviceAdd is called by the framework in response to AddDevice
	call from the PnP manager. We create and initialize a device object to
	represent a new instance of the device.

Arguments:

	Driver - Handle to a framework driver object created in DriverEntry

	DeviceInit - Pointer to a framework-allocated WDFDEVICE_INIT structure.

Return Value:

	NTSTATUS

--*/
{
	NTSTATUS                status;
	WDF_OBJECT_ATTRIBUTES   deviceAttributes;
	WDFDEVICE               device;
	PDEVICE_CONTEXT         deviceContext;
	PHID_DEVICE_ATTRIBUTES  hidAttributes;
	UNREFERENCED_PARAMETER(Driver);

	KdPrint(("Enter EvtDeviceAdd\n"));

	//
	// Mark ourselves as a filter, which also relinquishes power policy ownership
	//
	WdfFdoInitSetFilter(DeviceInit);

	WDF_OBJECT_ATTRIBUTES_INIT_CONTEXT_TYPE(
		&deviceAttributes,
		DEVICE_CONTEXT);

	status = WdfDeviceCreate(&DeviceInit,
		&deviceAttributes,
		&device);
	if (!NT_SUCCESS(status)) {
		KdPrint(("Error: WdfDeviceCreate failed 0x%x\n", status));
		return status;
	}

	deviceContext = GetDeviceContext(device);
	deviceContext->Device = device;
	memset(deviceContext->DeviceData, 0, 64);

	hidAttributes = &deviceContext->HidDeviceAttributes;
	RtlZeroMemory(hidAttributes, sizeof(HID_DEVICE_ATTRIBUTES));
	hidAttributes->Size = sizeof(HID_DEVICE_ATTRIBUTES);
	hidAttributes->VendorID = HIDMINI_VID;
	hidAttributes->ProductID = HIDMINI_PID;
	hidAttributes->VersionNumber = HIDMINI_VERSION;

	status = QueueCreate(device,
		&deviceContext->DefaultQueue);
	if (!NT_SUCCESS(status)) {
		return status;
	}

	status = ReportQueueCreate(device,
		&deviceContext->ReadReportQueue, FALSE);
	if (!NT_SUCCESS(status)) {
		return status;
	}

	//status = ReportQueueCreate(device,
	//	&deviceContext->GetReportQueue, FALSE);
	//if (!NT_SUCCESS(status)) {
	//	return status;
	//}

	//
	// Use default "HID Descriptor" (hardcoded). We will set the
	// wReportLength memeber of HID descriptor when we read the
	// the report descriptor either from registry or the hard-coded
	// one.
	//
	deviceContext->HidDescriptor = G_DefaultHidDescriptor;

	//
	// Check to see if we need to read the Report Descriptor from
	// registry. If the "ReadFromRegistry" flag in the registry is set
	// then we will read the descriptor from registry using routine
	// ReadDescriptorFromRegistry(). Otherwise, we will use the
	// hard-coded default report descriptor.
	//

	// Ming: we always use the hard-coded default report descriptor.
	status = STATUS_UNSUCCESSFUL;

#if false
	status = CheckRegistryForDescriptor(device);
	if (NT_SUCCESS(status)) {
		//
		// We need to read read descriptor from registry
		//
		status = ReadDescriptorFromRegistry(device);
		if (!NT_SUCCESS(status)) {
			KdPrint(("Failed to read descriptor from registry\n"));
		}
	}
#endif

	//
	// We will use hard-coded report descriptor if registry one is not used.
	//
	if (!NT_SUCCESS(status)) {
		deviceContext->ReportDescriptor = G_DefaultReportDescriptor;
		KdPrint(("Using Hard-coded Report descriptor\n"));
		status = STATUS_SUCCESS;
	}

	return status;
}

#ifdef _KERNEL_MODE
EVT_WDF_IO_QUEUE_IO_INTERNAL_DEVICE_CONTROL EvtIoDeviceControl;
#else
EVT_WDF_IO_QUEUE_IO_DEVICE_CONTROL          EvtIoDeviceControl;
#endif

NTSTATUS
QueueCreate(
	_In_  WDFDEVICE         Device,
	_Out_ WDFQUEUE          *Queue
)
/*++
Routine Description:

	This function creates a default, parallel I/O queue to proces IOCTLs
	from hidclass.sys.

Arguments:

	Device - Handle to a framework device object.

	Queue - Output pointer to a framework I/O queue handle, on success.

Return Value:

	NTSTATUS

--*/
{
	NTSTATUS                status;
	WDF_IO_QUEUE_CONFIG     queueConfig;
	WDF_OBJECT_ATTRIBUTES   queueAttributes;
	WDFQUEUE                queue;
	PQUEUE_CONTEXT          queueContext;

	WDF_IO_QUEUE_CONFIG_INIT_DEFAULT_QUEUE(
		&queueConfig, 
		WdfIoQueueDispatchParallel);

#ifdef _KERNEL_MODE
	queueConfig.EvtIoInternalDeviceControl = EvtIoDeviceControl;
#else
	//
	// HIDclass uses INTERNAL_IOCTL which is not supported by UMDF. Therefore
	// the hidumdf.sys changes the IOCTL type to DEVICE_CONTROL for next stack
	// and sends it down
	//
	queueConfig.EvtIoDeviceControl = EvtIoDeviceControl;
#endif

	WDF_OBJECT_ATTRIBUTES_INIT_CONTEXT_TYPE(
		&queueAttributes,
		QUEUE_CONTEXT);

	status = WdfIoQueueCreate(
		Device,
		&queueConfig,
		&queueAttributes,
		&queue);

	if (!NT_SUCCESS(status)) {
		KdPrint(("WdfIoQueueCreate failed 0x%x\n", status));
		return status;
	}

	queueContext = GetQueueContext(queue);
	queueContext->Queue = queue;
	queueContext->DeviceContext = GetDeviceContext(Device);
	memset(queueContext->OutputReport, 0, 64);

	*Queue = queue;
	return status;
}

VOID
EvtIoDeviceControl(
	_In_  WDFQUEUE          Queue,
	_In_  WDFREQUEST        Request,
	_In_  size_t            OutputBufferLength,
	_In_  size_t            InputBufferLength,
	_In_  ULONG             IoControlCode
)
/*++
Routine Description:

	This event callback function is called when the driver receives an

	(KMDF) IOCTL_HID_Xxx code when handlng IRP_MJ_INTERNAL_DEVICE_CONTROL
	(UMDF) IOCTL_HID_Xxx, IOCTL_UMDF_HID_Xxx when handling IRP_MJ_DEVICE_CONTROL

Arguments:

	Queue - A handle to the queue object that is associated with the I/O request

	Request - A handle to a framework request object.

	OutputBufferLength - The length, in bytes, of the request's output buffer,
			if an output buffer is available.

	InputBufferLength - The length, in bytes, of the request's input buffer, if
			an input buffer is available.

	IoControlCode - The driver or system defined IOCTL associated with the request

Return Value:

	NTSTATUS

--*/
{
	NTSTATUS                status = STATUS_SUCCESS;
	BOOLEAN                 bCompleteRequest = TRUE;
	BOOLEAN					bPopReadReportQueue = FALSE;
	BOOLEAN					bPopGetReportQueue = FALSE;
	WDFDEVICE               device = WdfIoQueueGetDevice(Queue);
	PDEVICE_CONTEXT         deviceContext = NULL;
	PQUEUE_CONTEXT          queueContext = GetQueueContext(Queue);
	UNREFERENCED_PARAMETER(OutputBufferLength);
	UNREFERENCED_PARAMETER(InputBufferLength);

	deviceContext = GetDeviceContext(device);

	KdPrint(("\n"));
	switch (IoControlCode)
	{
	case IOCTL_HID_GET_DEVICE_DESCRIPTOR:   // METHOD_NEITHER
		//
		// Retrieves the device's HID descriptor.
		//
		KdPrint(("** IOCTL_HID_GET_DEVICE_DESCRIPTOR **\n"));

		_Analysis_assume_(deviceContext->HidDescriptor.bLength != 0);
		status = RequestCopyFromBuffer(Request,
			&deviceContext->HidDescriptor,
			deviceContext->HidDescriptor.bLength);
		break;

	case IOCTL_HID_GET_DEVICE_ATTRIBUTES:   // METHOD_NEITHER
		//
		//Retrieves a device's attributes in a HID_DEVICE_ATTRIBUTES structure.
		//
		KdPrint(("** IOCTL_HID_GET_DEVICE_ATTRIBUTES **\n"));

		status = RequestCopyFromBuffer(Request,
			&queueContext->DeviceContext->HidDeviceAttributes,
			sizeof(HID_DEVICE_ATTRIBUTES));
		break;

	case IOCTL_HID_GET_REPORT_DESCRIPTOR:   // METHOD_NEITHER
		//
		//Obtains the report descriptor for the HID device.
		//
		KdPrint(("** IOCTL_HID_GET_REPORT_DESCRIPTOR **\n"));

		status = RequestCopyFromBuffer(Request,
			deviceContext->ReportDescriptor,
			deviceContext->HidDescriptor.DescriptorList[0].wReportLength);
		break;

	case IOCTL_HID_READ_REPORT:             // METHOD_NEITHER
		//
		// Returns a report from the device into a class driver-supplied
		// buffer.
		//
		KdPrint(("** IOCTL_HID_READ_REPORT **\n"));

		status = ReadReport(queueContext, Request, &bCompleteRequest);
		break;

	case IOCTL_HID_WRITE_REPORT:            // METHOD_NEITHER
		//
		// Transmits a class driver-supplied report to the device.
		//
		KdPrint(("** IOCTL_HID_WRITE_REPORT **\n"));

		status = WriteReport(queueContext, Request, &bPopGetReportQueue);
		break;

#ifdef _KERNEL_MODE

	case IOCTL_HID_GET_FEATURE:             // METHOD_OUT_DIRECT

		status = GetFeature(queueContext, Request);
		break;

	case IOCTL_HID_SET_FEATURE:             // METHOD_IN_DIRECT

		status = SetFeature(queueContext, Request);
		break;

	case IOCTL_HID_GET_INPUT_REPORT:        // METHOD_OUT_DIRECT

		status = GetInputReport(queueContext, Request);
		break;

	case IOCTL_HID_SET_OUTPUT_REPORT:       // METHOD_IN_DIRECT

		status = SetOutputReport(queueContext, Request);
		break;

#else // UMDF specific

		//
		// HID minidriver IOCTL uses HID_XFER_PACKET which contains an embedded pointer.
		//
		//   typedef struct _HID_XFER_PACKET {
		//     PUCHAR reportBuffer;
		//     ULONG  reportBufferLen;
		//     UCHAR  reportId;
		//   } HID_XFER_PACKET, *PHID_XFER_PACKET;
		//
		// UMDF cannot handle embedded pointers when marshalling buffers between processes.
		// Therefore a special driver mshidumdf.sys is introduced to convert such IRPs to
		// new IRPs (with new IOCTL name like IOCTL_UMDF_HID_Xxxx) where:
		//
		//   reportBuffer - passed as one buffer inside the IRP
		//   reportId     - passed as a second buffer inside the IRP
		//
		// The new IRP is then passed to UMDF host and driver for further processing.
		//

	case IOCTL_UMDF_HID_GET_FEATURE:        // METHOD_NEITHER
		KdPrint(("** IOCTL_UMDF_HID_GET_FEATURE **\n"));
		//status = GetFeature(queueContext, Request);
		break;

	case IOCTL_UMDF_HID_SET_FEATURE:        // METHOD_NEITHER
		KdPrint(("** IOCTL_UMDF_HID_SET_FEATURE **\n"));
		//status = SetFeature(queueContext, Request);
		break;

	case IOCTL_UMDF_HID_GET_INPUT_REPORT:  // METHOD_NEITHER
		KdPrint(("** IOCTL_UMDF_HID_GET_INPUT_REPORT **\n"));
		status = GetInputReport(queueContext, Request, &bCompleteRequest);
		break;

	case IOCTL_UMDF_HID_SET_OUTPUT_REPORT: // METHOD_NEITHER
		KdPrint(("** IOCTL_UMDF_HID_SET_OUTPUT_REPORT **\n"));
		status = SetOutputReport(queueContext, Request, &bPopReadReportQueue);
		break;

#endif // _KERNEL_MODE

	case IOCTL_HID_GET_STRING:                      // METHOD_NEITHER
		KdPrint(("** IOCTL_HID_GET_STRING\n"));
		status = GetString(Request);
		break;

	case IOCTL_HID_GET_INDEXED_STRING:              // METHOD_OUT_DIRECT
		KdPrint(("** IOCTL_HID_GET_INDEXED_STRING **\n"));
		//status = GetIndexedString(Request);
		break;

	case IOCTL_HID_SEND_IDLE_NOTIFICATION_REQUEST:  // METHOD_NEITHER
		//
		// This has the USBSS Idle notification callback. If the lower driver
		// can handle it (e.g. USB stack can handle it) then pass it down
		// otherwise complete it here as not inplemented. For a virtual
		// device, idling is not needed.
		//
		// Not implemented. fall through...
		//
		KdPrint(("** IOCTL_HID_SEND_IDLE_NOTIFICATION_REQUEST **\n"));
		break;
	case IOCTL_HID_ACTIVATE_DEVICE:                 // METHOD_NEITHER
		KdPrint(("** IOCTL_HID_ACTIVATE_DEVICE **\n"));
		break;

	case IOCTL_HID_DEACTIVATE_DEVICE:               // METHOD_NEITHER
		KdPrint(("** IOCTL_HID_DEACTIVATE_DEVICE **\n"));
		break;

	case IOCTL_GET_PHYSICAL_DESCRIPTOR:             // METHOD_OUT_DIRECT
		//
		// We don't do anything for these IOCTLs but some minidrivers might.
		//
		// Not implemented. fall through...
		KdPrint(("** IOCTL_GET_PHYSICAL_DESCRIPTOR **\n"));
		break;
		//
	default:
		KdPrint(("** INVALID HID Messages - 0x%08x **\n", IoControlCode));
		status = STATUS_NOT_IMPLEMENTED;
		break;
	}

	//
	// Complete the request. Information value has already been set by request
	// handlers.
	//
	KdPrint(("<< bCompleteRequest::%d, bPopReadReportQueue::%d, bPopGetReportQueue::%d\n",
		bCompleteRequest, bPopReadReportQueue, bPopGetReportQueue));
	if (bCompleteRequest) {
		WdfRequestComplete(Request, status);
	}
	if (bPopReadReportQueue) {
		PopReadReportQueue(queueContext);
	}
	if (bPopGetReportQueue) {
		PopGetReportQueue(queueContext);
	}
}

NTSTATUS
RequestCopyFromBuffer(
	_In_  WDFREQUEST        Request,
	_In_  PVOID             SourceBuffer,
	_When_(NumBytesToCopyFrom == 0, __drv_reportError(NumBytesToCopyFrom cannot be zero))
	_In_  size_t            NumBytesToCopyFrom
)
/*++

Routine Description:
	for ReadReport & GetInputReport
	A helper function to copy specified bytes to the request's output memory

Arguments:

	Request - A handle to a framework request object.

	SourceBuffer - The buffer to copy data from.

	NumBytesToCopyFrom - The length, in bytes, of data to be copied.

Return Value:

	NTSTATUS

--*/
{
	NTSTATUS                status;
	WDFMEMORY               memory;
	size_t                  outputBufferLength;
	PHIDMINI_INPUT_REPORT   pReadReport;

	if (NumBytesToCopyFrom == sizeof(HIDMINI_INPUT_REPORT)) {
		pReadReport = (PHIDMINI_INPUT_REPORT)SourceBuffer;
		KdPrint(("        >> RequestCopyFromBuffer [R=%04x, Siz=%d, Brid=%d]\n",
			Request, NumBytesToCopyFrom, pReadReport->ReportId));
		displayHexDump(pReadReport->Data);

	}
	else {
		KdPrint(("        >> RequestCopyFromBuffer [R=%04x, Siz=%d]\n", Request, NumBytesToCopyFrom));
	}

	status = WdfRequestRetrieveOutputMemory(Request, &memory);
	if (!NT_SUCCESS(status)) {
		KdPrint(("          RequestCopyFromBuffer::WdfRequestRetrieveOutputMemory failed 0x%x\n", status));
		return status;
	}
	WdfMemoryGetBuffer(memory, &outputBufferLength);
	KdPrint(("           RequestCopyFromBuffer::WdfMemoryGetBuffer [R=%04x, Olen=%d]\n", Request, outputBufferLength));

	if (outputBufferLength == NumBytesToCopyFrom) { // Has REPORT_ID or Other Request
		status = WdfMemoryCopyFromBuffer(memory, 0, SourceBuffer, outputBufferLength);
	}
	else if (outputBufferLength == (NumBytesToCopyFrom - 1)) { // NO Report_ID and ReadReport
		pReadReport = (PHIDMINI_INPUT_REPORT)SourceBuffer;
		status = WdfMemoryCopyFromBuffer(memory, 0, pReadReport->Data, outputBufferLength);
	}
	else if (outputBufferLength < NumBytesToCopyFrom) {
		status = STATUS_INVALID_BUFFER_SIZE;
		KdPrint(("           RequestCopyFromBuffer: buffer too small. Size %d, expect %d\n",
			(int)outputBufferLength, (int)NumBytesToCopyFrom));
		return status;
	}
	else {
		status = WdfMemoryCopyFromBuffer(memory, 0, SourceBuffer, NumBytesToCopyFrom);
		outputBufferLength = NumBytesToCopyFrom;
	}

	if (!NT_SUCCESS(status)) {
		KdPrint(("           RequestCopyFromBuffer::WdfMemoryCopyFromBuffer[%d] failed 0x%x\n", outputBufferLength, status));
		return status;
	}

	WdfRequestSetInformation(Request, outputBufferLength);
	return status;
}

NTSTATUS
ReadReport(
	_In_  PQUEUE_CONTEXT    QueueContext,
	_In_  WDFREQUEST        Request,
	_Always_(_Out_)
	BOOLEAN					*bCompleteRequest
)
/*++

Routine Description:

	Handles IOCTL_HID_READ_REPORT for the HID collection. Normally the request
	will be forwarded to a report queue for further process. In that case, the
	caller should not try to complete the request at this time, as the request
	will later be retrieved back from the manually queue and completed there.
	However, if for some reason the forwarding fails, the caller still need
	to complete the request with proper error code immediately.

Arguments:

	QueueContext - The object context associated with the queue

	Request - Pointer to  Request Packet.

	bCompleteRequest - A boolean output value, indicating whether the caller
			should complete the request or not

Return Value:

	NT status code.

--*/
{
	NTSTATUS                status;

	KdPrint((">> ReadReport\n"));

	//
	// forward the request to READ report queue
	//
	status = WdfRequestForwardToIoQueue(
		Request,
		QueueContext->DeviceContext->ReadReportQueue);
	if (!NT_SUCCESS(status)) {
		KdPrint(("WdfRequestForwardToIoQueue[ReadReportQueue] failed with 0x%x\n", status));
		*bCompleteRequest = TRUE;
	}
	else {
		KdPrint(("<> ReadReport::WdfRequestForwardToIoQueue[ReadReportQueue: R=%04x]\n", Request));
		*bCompleteRequest = FALSE;
	}
	return status;
}

NTSTATUS
WriteReport(
	_In_  PQUEUE_CONTEXT    QueueContext,
	_In_  WDFREQUEST        Request,
	_Out_ BOOLEAN			*bPopGetReportQueue
)
/*++

Routine Description:

	Handles IOCTL_HID_WRITE_REPORT all the collection.

Arguments:

	QueueContext - The object context associated with the queue

	Request - Pointer to  Request Packet.

Return Value:

	NT status code.

--*/

{
	NTSTATUS                status = STATUS_SUCCESS;
	HID_XFER_PACKET         packet;
	ULONG                   reportSize;
	PHIDMINI_OUTPUT_REPORT  outputReport;
	//WDF_IO_QUEUE_STATE queueStatus;
	//ULONG queueCount = 0;

	UNREFERENCED_PARAMETER(QueueContext);
	KdPrint((">> WriteReport, inIdx=%d, outIdx=%d\n", inIdx, outIdx));

	status = RequestGetHidXferPacket_ToWriteToDevice(
		Request,
		&packet);
	if (!NT_SUCCESS(status)) {
		return status;
	}

	if (packet.reportId != CONTROL_COLLECTION_REPORT_ID) {
		//
		// Return error for unknown collection
		//
		status = STATUS_INVALID_PARAMETER;
		KdPrint(("   WriteReport: unkown report id %d\n", packet.reportId));
		return status;
	}

#if 0
	{
		queueStatus = WdfIoQueueGetState(
			QueueContext->DeviceContext->GetReportQueue,
			&queueCount,
			NULL
		);
		KdPrint(("WriteReport: GetReportQueue Count=%d, IDLE=%d\n", queueCount,
			(WDF_IO_QUEUE_IDLE(queueStatus)) ? TRUE : FALSE));
	}
#endif
	if (AUTHENTICATOR_REQUEST) {  // there is a GetInputReport in QUEUE
		//
		// before touching buffer make sure buffer is big enough.
		//
		reportSize = sizeof(HIDMINI_OUTPUT_REPORT);

		if (packet.reportBufferLen == reportSize) {
			outputReport = (PHIDMINI_OUTPUT_REPORT)packet.reportBuffer;
			//memcpy(QueueContext->DeviceContext->DeviceData, outputReport->Data, 64);
			memcpy(QueueContext->OutputReport, outputReport->Data, 64);
			KdPrint(("<> WriteReport [Rid=%d, RSize=%d, Brid=%d]\n",
				packet.reportId, packet.reportBufferLen, outputReport->ReportId));
			//displayHexDump(QueueContext->DeviceContext->DeviceData);
			displayHexDump(QueueContext->OutputReport);
		}
		else if (packet.reportBufferLen == (reportSize - 1)) {
			//memcpy(QueueContext->DeviceContext->DeviceData,	packet.reportBuffer, 64);
			memcpy(QueueContext->OutputReport, packet.reportBuffer, 64);
			KdPrint(("<> WriteReport [Rid=%d, RSize=%d]\n",
				packet.reportId, packet.reportBufferLen));
			//displayHexDump(QueueContext->DeviceContext->DeviceData);
			displayHexDump(QueueContext->OutputReport);
		}
		else {
			status = STATUS_INVALID_BUFFER_SIZE;
			KdPrint(("   WriteReport: invalid input buffer. size %d, expect %d\n",
				packet.reportBufferLen, reportSize));
			return status;
		}
		//
		// set status and information
		//
		WdfRequestSetInformation(Request, packet.reportBufferLen);
		(*bPopGetReportQueue) = TRUE;
	}
	else { // Check if Authenticator is UP
		if (bAuthenticatorUp == TRUE)
		{  // Authenticator is BUSY, put into WriteReportDataQueue
			KdPrint(("   WriteReport: *!*!*!*!*!*!Authenticator is not READY, put into WriteReportDataQueue!*!*!*!*!*!\n"));
			memcpy(WriteReportDataQueue[inIdx%WRITE_REPORT_DATA_QUEUE_SIZE], packet.reportBuffer, 64);
			inIdx++;
			KdPrint(("<> WriteReport [Rid=%d, RSize=%d]\n", packet.reportId, packet.reportBufferLen));
			//displayHexDump(QueueContext->DeviceContext->DeviceData);
			displayHexDump(packet.reportBuffer);
		}
		else
		{
			status = STATUS_NO_SUCH_DEVICE;
			KdPrint(("   WriteReport: AUTHENTICATOR is not UP!\n"));
			return status;
		}
	}

	return status;
}


NTSTATUS
GetInputReport(
	_In_  PQUEUE_CONTEXT    QueueContext,
	_In_  WDFREQUEST        Request,
	_Always_(_Out_)
	BOOLEAN					*bCompleteRequest
)
/*++

Routine Description:

	Handles IOCTL_HID_GET_INPUT_REPORT for all the collection.

Arguments:

	QueueContext - The object context associated with the queue

	Request - Pointer to Request Packet.

Return Value:

	NT status code.

--*/
{
	NTSTATUS                status = STATUS_SUCCESS;
	HID_XFER_PACKET         packet;
	ULONG                   reportSize;
	PHIDMINI_INPUT_REPORT   reportBuffer;

	UNREFERENCED_PARAMETER(QueueContext);
	KdPrint((">> GetInputRepor, inIdx=%d, outIdx=%d\n", inIdx, outIdx));

#if 0
//status = WdfRequestForwardToIoQueue(
//	Request,
//	QueueContext->DeviceContext->GetReportQueue);
//if (!NT_SUCCESS(status)) {
//	KdPrint(("WdfRequestForwardToIoQueue[GetReportQueue] failed with 0x%x\n", status));
//	*bCompleteRequest = TRUE;
//}
//else {
//	*bCompleteRequest = FALSE;
//	KdPrint(("<> GetInputReport::WdfRequestForwardToIoQueue[GetReportQueue: R=%04x]\n", Request));
//}
#endif
	bAuthenticatorUp = TRUE;
	if (inIdx == outIdx) { // no WriteReportDataQueue is EMPTY
		AUTHENTICATOR_REQUEST = Request;
		KdPrint(("   GetInputReport::WdfTimerStop(AuthenticatorLinkTimer)::bAuthenticatorUp = TRUE\n"));
		WdfTimerStop(AuthenticatorLinkTimer, FALSE);
		WdfTimerStart(AuthenticatorPingTimer, WDF_REL_TIMEOUT_IN_SEC(10));
		*bCompleteRequest = FALSE;
		KdPrint(("   GetInputReport::WdfTimerStart(AuthenticatorPingTimer)::set AUTHENTICATOR_REQUEST=%08x\n", AUTHENTICATOR_REQUEST));
	}
	else {
		status = RequestGetHidXferPacket_ToReadFromDevice(
			Request,
			&packet);
		if (!NT_SUCCESS(status)) {
			return status;
		}

		if (packet.reportId != CONTROL_COLLECTION_REPORT_ID) {
			//
			// If collection ID is not for control collection then handle
			// this request just as you would for a regular collection.
			//
			status = STATUS_INVALID_PARAMETER;
			KdPrint(("   GetInputReport: invalid report id %d\n", packet.reportId));
			return status;
		}

		UINT32 idx = outIdx % WRITE_REPORT_DATA_QUEUE_SIZE;
		outIdx++;
		reportSize = sizeof(HIDMINI_INPUT_REPORT);
		if (packet.reportBufferLen == reportSize) {
			reportBuffer = (PHIDMINI_INPUT_REPORT)(packet.reportBuffer);
			reportBuffer->ReportId = CONTROL_COLLECTION_REPORT_ID;
			memcpy(reportBuffer->Data, WriteReportDataQueue[idx], 64);
			KdPrint(("<> GetInputReport [Rid=%d, RSize=%d, Brid=%d]\n",
				packet.reportId, packet.reportBufferLen, reportBuffer->ReportId));
			displayHexDump(reportBuffer->Data);
		}
		else if (packet.reportBufferLen == (reportSize - 1)) {
			memcpy(packet.reportBuffer, WriteReportDataQueue[idx], 64);
			KdPrint(("<> GetInputReport [Rid=%d, RSize=%d]\n",
				packet.reportId, packet.reportBufferLen));
			displayHexDump(packet.reportBuffer);
		}
		else {
			status = STATUS_INVALID_BUFFER_SIZE;
			KdPrint(("   GetInputReport: output buffer too small. Size %d, expect %d\n",
				packet.reportBufferLen, reportSize));
			return status;
		}

		//
		// Report how many bytes were copied
		//
		WdfRequestSetInformation(Request, packet.reportBufferLen);
	}
	return status;
}


NTSTATUS
SetOutputReport(
	_In_  PQUEUE_CONTEXT    QueueContext,
	_In_  WDFREQUEST        Request,
	_Out_ BOOLEAN			*bPopReadReportQueue
)
/*++

Routine Description:

	Handles IOCTL_HID_SET_OUTPUT_REPORT for all the collection.

Arguments:

	QueueContext - The object context associated with the queue

	Request - Pointer to Request Packet.

Return Value:

	NT status code.

--*/
{
	NTSTATUS                status;
	HID_XFER_PACKET         packet;
	ULONG                   reportSize;
	PHIDMINI_OUTPUT_REPORT  reportBuffer;

	KdPrint((">> SetOutputReport\n"));

	status = RequestGetHidXferPacket_ToWriteToDevice(
		Request,
		&packet);
	if (!NT_SUCCESS(status)) {
		return status;
	}

	if (packet.reportId != CONTROL_COLLECTION_REPORT_ID) {
		//
		// If collection ID is not for control collection then handle
		// this request just as you would for a regular collection.
		//
		status = STATUS_INVALID_PARAMETER;
		KdPrint(("   SetOutputReport: unkown report id %d\n", packet.reportId));
		return status;
	}

	WDF_IO_QUEUE_STATE queueStatus;
	ULONG queueCount = 0;
	queueStatus = WdfIoQueueGetState(
		QueueContext->DeviceContext->ReadReportQueue,
		&queueCount,
		NULL
	);

	//return (WDF_IO_QUEUE_IDLE(queueStatus)) ? TRUE : FALSE;
	KdPrint(("   SetOutputReport: ReadReportQueue Count=%d, IDLE=%d\n", queueCount,
		(WDF_IO_QUEUE_IDLE(queueStatus)) ? TRUE : FALSE));

	if (queueCount > 0) {  // There is a READ REPORT request pending
		//
		// before touching buffer make sure buffer is big enough.
		//
		reportSize = sizeof(HIDMINI_OUTPUT_REPORT);

		if (packet.reportBufferLen == reportSize) {
			reportBuffer = (PHIDMINI_OUTPUT_REPORT)packet.reportBuffer;
			//memcpy(QueueContext->OutputReport, reportBuffer->Data, 64);
			memcpy(QueueContext->DeviceContext->DeviceData, reportBuffer->Data, 64);
			KdPrint(("<> SetOutputReport [Rid=%d, RSize=%d, Brid=%d]\n",
				packet.reportId, packet.reportBufferLen, reportBuffer->ReportId));
			//displayHexDump(QueueContext->OutputReport);
			displayHexDump(QueueContext->DeviceContext->DeviceData);

		}
		else if (packet.reportBufferLen == (reportSize - 1)) {
			//memcpy(QueueContext->OutputReport, packet.reportBuffer, 64);
			memcpy(QueueContext->DeviceContext->DeviceData, packet.reportBuffer, 64);
			KdPrint(("<> SetOutputReport [Rid=%d, RSize=%d]\n",
				packet.reportId, packet.reportBufferLen));
			//displayHexDump(QueueContext->OutputReport);
			displayHexDump(QueueContext->DeviceContext->DeviceData);
		}
		else {
			status = STATUS_INVALID_BUFFER_SIZE;
			KdPrint(("   SetOutputReport: invalid input buffer. size %d, expect %d\n",
				packet.reportBufferLen, reportSize));
			return status;
		}

		//
		// Report how many bytes were copied
		//
		WdfRequestSetInformation(Request, packet.reportBufferLen);
		(*bPopReadReportQueue) = TRUE;
	}
	else { // No request to Read Report
		status = STATUS_FATAL_APP_EXIT;
		KdPrint(("WriteReport: Application is not ready\n"));
		return status;
	}
	return status;
}

NTSTATUS
GetStringId(
	_In_  WDFREQUEST        Request,
	_Out_ ULONG            *StringId,
	_Out_ ULONG            *LanguageId
)
/*++

Routine Description:

	Helper routine to decode IOCTL_HID_GET_INDEXED_STRING and IOCTL_HID_GET_STRING.

Arguments:

	Request - Pointer to Request Packet.

Return Value:

	NT status code.

--*/
{
	NTSTATUS                status;
	ULONG                   inputValue;

	WDFMEMORY               inputMemory;
	size_t                  inputBufferLength;
	PVOID                   inputBuffer;
	KdPrint((">> GetStringId\n"));
	//
	// mshidumdf.sys updates the IRP and passes the string id (or index) through
	// the input buffer correctly based on the IOCTL buffer type
	//

	status = WdfRequestRetrieveInputMemory(Request, &inputMemory);
	if (!NT_SUCCESS(status)) {
		KdPrint(("WdfRequestRetrieveInputMemory failed 0x%x\n", status));
		return status;
	}
	inputBuffer = WdfMemoryGetBuffer(inputMemory, &inputBufferLength);

	//
	// make sure buffer is big enough.
	//
	if (inputBufferLength < sizeof(ULONG))
	{
		status = STATUS_INVALID_BUFFER_SIZE;
		KdPrint(("GetStringId: invalid input buffer. size %d, expect %d\n",
			(int)inputBufferLength, (int)sizeof(ULONG)));
		return status;
	}

	inputValue = (*(PULONG)inputBuffer);

	//
	// The least significant two bytes of the INT value contain the string id.
	//
	*StringId = (inputValue & 0x0ffff);

	//
	// The most significant two bytes of the INT value contain the language
	// ID (for example, a value of 1033 indicates English).
	//
	*LanguageId = (inputValue >> 16);
	KdPrint(("<< GetStringId\n"));
	return status;
}

NTSTATUS
GetString(
	_In_  WDFREQUEST        Request
)
/*++

Routine Description:

	Handles IOCTL_HID_GET_STRING.

Arguments:

	Request - Pointer to Request Packet.

Return Value:

	NT status code.

--*/
{
	NTSTATUS                status;
	ULONG                   languageId, stringId;
	size_t                  stringSizeCb;
	PWSTR                   string;

	status = GetStringId(Request, &stringId, &languageId);
	KdPrint((">> GetString::stringId=0x%02x\n", stringId));

	// While we don't use the language id, some minidrivers might.
	//
	UNREFERENCED_PARAMETER(languageId);

	if (!NT_SUCCESS(status)) {
		return status;
	}

	switch (stringId) {
	case HID_STRING_ID_IMANUFACTURER:
		KdPrint((">> GetString::HID_STRING_ID_IMANUFACTURER\n"));
		stringSizeCb = sizeof(VHIDMINI_MANUFACTURER_STRING);
		string = VHIDMINI_MANUFACTURER_STRING;
		break;
	case HID_STRING_ID_IPRODUCT:
		KdPrint((">> GetString::HID_STRING_ID_IPRODUCT\n"));
		stringSizeCb = sizeof(VHIDMINI_PRODUCT_STRING);
		string = VHIDMINI_PRODUCT_STRING;
		break;
	case HID_STRING_ID_ISERIALNUMBER:
		KdPrint((">> GetString::HID_STRING_ID_ISERIALNUMBER\n"));
		stringSizeCb = sizeof(VHIDMINI_SERIAL_NUMBER_STRING);
		string = VHIDMINI_SERIAL_NUMBER_STRING;
		break;
	default:
		KdPrint((">> GetString::INVALID_PARAMETER\n"));
		status = STATUS_INVALID_PARAMETER;
		KdPrint(("GetString: unkown string id %d\n", stringId));
		return status;
	}

	status = RequestCopyFromBuffer(Request, string, stringSizeCb);
	KdPrint(("<< GetString::stringSizeCb=%d\n", stringSizeCb));
	return status;
}

NTSTATUS
ReportQueueCreate(
	_In_  WDFDEVICE         Device,
	_Out_ WDFQUEUE          *Queue,
	_In_  BOOLEAN			bStartTimer
)
/*++
Routine Description:

	This function creates a report I/O queue to receive IOCTL_HID_READ_REPORT
	forwarded from the device's default queue handler.

	It also creates a periodic timer to check the queue and complete any pending
	request with data from the device. Here timer expiring is used to simulate
	a hardware event that new data is ready.

	The workflow is like this:

	- Hidclass.sys sends an ioctl to the miniport to read input report.

	- The request reaches the driver's default queue. As data may not be avaiable
	  yet, the request is forwarded to a second report queue temporarily.

	- Later when data is ready (as simulated by timer expiring), the driver
	  checks for any pending request in the report queue, and then completes it.

	- Hidclass gets notified for the read request completion and return data to
	  the caller.

	On the other hand, for IOCTL_HID_WRITE_REPORT request, the driver simply
	sends the request to the hardware (as simulated by storing the data at
	DeviceContext->DeviceData) and completes the request immediately. There is
	no need to use another queue for write operation.

Arguments:

	Device - Handle to a framework device object.

	Queue - Output pointer to a framework I/O queue handle, on success.

Return Value:

	NTSTATUS

--*/
{
	NTSTATUS                status;
	WDF_IO_QUEUE_CONFIG     queueConfig;
	WDF_OBJECT_ATTRIBUTES   queueAttributes;
	WDFQUEUE                queue;
	PREPORT_QUEUE_CONTEXT   queueContext;
	//WDF_TIMER_CONFIG        timerConfig;
	//WDF_OBJECT_ATTRIBUTES   timerAttributes;
	//ULONG                   timerPeriodInSeconds = 5;
	//ULONG                   timerPeriodInSeconds = 30;

	WDF_TIMER_CONFIG        AuthenticatorLinkTimerConfig;
	WDF_OBJECT_ATTRIBUTES   AuthenticatorLinkTimerAttributes;
	WDF_TIMER_CONFIG        AuthenticatorPingTimerConfig;
	WDF_OBJECT_ATTRIBUTES   AuthenticatorPingTimerAttributes;

	UNREFERENCED_PARAMETER(bStartTimer);

	WDF_IO_QUEUE_CONFIG_INIT(
		&queueConfig,
		WdfIoQueueDispatchManual);

	WDF_OBJECT_ATTRIBUTES_INIT_CONTEXT_TYPE(
		&queueAttributes,
		REPORT_QUEUE_CONTEXT);

	status = WdfIoQueueCreate(
		Device,
		&queueConfig,
		&queueAttributes,
		&queue);

	if (!NT_SUCCESS(status)) {
		KdPrint(("WdfIoQueueCreate failed 0x%x\n", status));
		return status;
	}

	queueContext = RetrieveReportQueueContext(queue);
	queueContext->Queue = queue;
	queueContext->DeviceContext = GetDeviceContext(Device);

	WDF_TIMER_CONFIG_INIT(
		&AuthenticatorLinkTimerConfig,
		AuthenticatorLinkTimerFunc);

	WDF_OBJECT_ATTRIBUTES_INIT(&AuthenticatorLinkTimerAttributes);
	AuthenticatorLinkTimerAttributes.ParentObject = queue;
	status = WdfTimerCreate(&AuthenticatorLinkTimerConfig,
		&AuthenticatorLinkTimerAttributes,
		&AuthenticatorLinkTimer);

	if (!NT_SUCCESS(status)) {
		KdPrint(("WdfTimerCreate Authenticator Link Timer failed 0x%x\n", status));
		return status;
	}

	WDF_TIMER_CONFIG_INIT(
		&AuthenticatorPingTimerConfig,
		AuthenticatorPingTimerFunc);

	WDF_OBJECT_ATTRIBUTES_INIT(&AuthenticatorPingTimerAttributes);
	AuthenticatorPingTimerAttributes.ParentObject = queue;
	status = WdfTimerCreate(&AuthenticatorPingTimerConfig,
		&AuthenticatorPingTimerAttributes,
		&AuthenticatorPingTimer);

	if (!NT_SUCCESS(status)) {
		KdPrint(("WdfTimerCreate Authenticator Ping Timer failed 0x%x\n", status));
		return status;
	}

#if false
	WDF_TIMER_CONFIG_INIT_PERIODIC(
		&timerConfig,
		EvtTimerFunc,
		timerPeriodInSeconds * 1000);

	WDF_OBJECT_ATTRIBUTES_INIT(&timerAttributes);
	timerAttributes.ParentObject = queue;
	status = WdfTimerCreate(&timerConfig,
		&timerAttributes,
		&queueContext->Timer);

	if (!NT_SUCCESS(status)) {
		KdPrint(("WdfTimerCreate failed 0x%x\n", status));
		return status;
	}

	if (bStartTimer) {
		WdfTimerStart(queueContext->Timer, WDF_REL_TIMEOUT_IN_SEC(1));
	}
#endif

	*Queue = queue;

	return status;
}

VOID PopGetReportQueue(_In_  PQUEUE_CONTEXT    QueueContext) {
	UCHAR					reportId = CONTROL_COLLECTION_REPORT_ID;
	WDFREQUEST              request = NULL;
	NTSTATUS                status = STATUS_SUCCESS;
	ULONG                   reportSize;
	HIDMINI_INPUT_REPORT    reportBuffer;

	KdPrint((">> PopGetReportQueue::AUTHENTICATOR_REQUEST=%08x::rid=%d\n", AUTHENTICATOR_REQUEST, reportId));

	if (AUTHENTICATOR_REQUEST) {
		request = AUTHENTICATOR_REQUEST;
		AUTHENTICATOR_REQUEST = (WDFREQUEST)NULL;
	}
	else {
		status = STATUS_DEVICE_NOT_READY;
		KdPrint((">> PopGetReportQueue::!#!#!#!#STATUS_DEVICE_NOT_READY!#!#!#!\n", QueueContext, reportId));
		//status = WdfIoQueueRetrieveNextRequest(QueueContext->DeviceContext->GetReportQueue, &request);
	}
	if (NT_SUCCESS(status)) {
		reportSize = sizeof(HIDMINI_INPUT_REPORT);
		reportBuffer.ReportId = reportId;
		memcpy(reportBuffer.Data, QueueContext->OutputReport, 64);
		//
		// Report how many bytes were copied
		//
		status = RequestCopyFromBuffer(request, &reportBuffer, reportSize);
		//KdPrint(("***PopGetReportQueue::WdfRequestSetInformation(%d)***\n", OUTPUT_REPORT_SIZE_CB));
		//WdfRequestSetInformation(request, reportSize);
		//KdPrint(("*****PopGetReportQueue::WdfRequestComplete(%04x, %d)*****\n", status, reportId));
		WdfRequestComplete(request, status);
		KdPrint(("   PopGetReportQueue::WdfTimerStart(AuthenticatorLinkTimer)::WdfTimerStop(AuthenticatorPingTimer)\n"));
		WdfTimerStart(AuthenticatorLinkTimer, WDF_REL_TIMEOUT_IN_MS(1500));
		WdfTimerStop(AuthenticatorPingTimer, FALSE);
	}

	KdPrint(("<< PopGetReportQueue [%08x]\n\n", status));
}

VOID PopReadReportQueue(_In_  PQUEUE_CONTEXT    QueueContext) {
	NTSTATUS                status;
	WDFREQUEST              request;
	HIDMINI_INPUT_REPORT    reportBuffer;
	ULONG                   reportSize;
	UCHAR					reportId = CONTROL_COLLECTION_REPORT_ID;

	KdPrint((">> PopReadReportQueue::QueueContext=%08x::rid=%d\n", QueueContext, reportId));
	//
	// see if we have a request in manual queue
	//
	status = WdfIoQueueRetrieveNextRequest(QueueContext->DeviceContext->ReadReportQueue, &request);
	if (NT_SUCCESS(status)) {
		KdPrint(("PopReadReportQueue::BINGO::We have a request in ReadReportQueue::request=%08x\n", request));
		reportSize = sizeof(HIDMINI_INPUT_REPORT);
		reportBuffer.ReportId = reportId;
		memcpy(reportBuffer.Data, QueueContext->DeviceContext->DeviceData, 64);

		status = RequestCopyFromBuffer(request, &reportBuffer, reportSize);

		//KdPrint(("***PopReadReportQueue::WdfRequestSetInformation(%d)***\n", OUTPUT_REPORT_SIZE_CB));
		//WdfRequestSetInformation(request, reportSize);
		//KdPrint(("*****PopReadReportQueue::WdfRequestComplete(%04x, %d)*****\n", status, OUTPUT_REPORT_SIZE_CB));
		WdfRequestComplete(request, status);

	}
	else {
		KdPrint((">> PopReadReportQueue::!#!#!#!#APPLICATION_NOT_READY!#!#!#!\n", QueueContext, reportId));
	}
	KdPrint(("<< PopReadReportQueue\n\n"));
}

void
AuthenticatorLinkTimerFunc(
	_In_  WDFTIMER          Timer
)
{
	UNREFERENCED_PARAMETER(Timer);
	KdPrint(("\n<> AuthenticatorLinkTimerFunc(!!TIMEOUT!!)::bAuthenticatorUp = FALSE\n"));

	bAuthenticatorUp = FALSE;
	outIdx = inIdx; // Trash saved HID reports
}


void
AuthenticatorPingTimerFunc(
	_In_  WDFTIMER          Timer
)
{
	UCHAR					reportId = CONTROL_COLLECTION_REPORT_ID;
	WDFREQUEST              request = NULL;
	NTSTATUS                status = STATUS_SUCCESS;
	ULONG                   reportSize;
	HIDMINI_INPUT_REPORT    reportBuffer;
	BYTE					pingBuffer[8] = { 0xff, 0xff, 0xff, 0xff, 0xC3, 0x00, 0x01, 0x00 };

	UNREFERENCED_PARAMETER(Timer);
	KdPrint(("\n<> AuthenticatorPingTimerFunc(!!TIMEOUT!!)::bAuthenticatorUp=%d\n", bAuthenticatorUp));

	if (AUTHENTICATOR_REQUEST) {
		request = AUTHENTICATOR_REQUEST;
		AUTHENTICATOR_REQUEST = (WDFREQUEST)NULL;

		// Send U2FHID_PING to Authenticator
		reportSize = sizeof(HIDMINI_INPUT_REPORT);
		reportBuffer.ReportId = reportId;
		memset(&reportBuffer.Data[8], 0x00, 56);
		memcpy(reportBuffer.Data, pingBuffer, 8);
		//
		// Report how many bytes were copied
		//
		status = RequestCopyFromBuffer(request, &reportBuffer, reportSize);
		WdfRequestComplete(request, status);

		KdPrint(("   AuthenticatorPingTimerFunc::WdfTimerStart(AuthenticatorLinkTimer)\n"));
		WdfTimerStart(AuthenticatorLinkTimer, WDF_REL_TIMEOUT_IN_MS(1500));
	}
}

void
EvtTimerFunc(
	_In_  WDFTIMER          Timer
)
/*++
Routine Description:

	This periodic timer callback routine checks the device's READ report queue and
	completes any pending request with data from the device.

Arguments:

	Timer - Handle to a timer object that was obtained from WdfTimerCreate.

Return Value:

	VOID

--*/
{
	NTSTATUS                status;
	WDFQUEUE                queue;
	PREPORT_QUEUE_CONTEXT   queueContext;
	WDFREQUEST              request;
	HIDMINI_INPUT_REPORT    readReport;

	KdPrint(("      >> EvtTimerFunc\n"));

	queue = (WDFQUEUE)WdfTimerGetParentObject(Timer);
	queueContext = RetrieveReportQueueContext(queue);

	//
	// see if we have a request in READ report queue
	//
	status = WdfIoQueueRetrieveNextRequest(
		queueContext->Queue,
		&request);

	if (NT_SUCCESS(status)) {
		KdPrint(("      >> EvtTimerFunc::WdfIoQueueRetrieveNextRequest[R=%04x]\n", request));
		readReport.ReportId = CONTROL_COLLECTION_REPORT_ID;
		memcpy(readReport.Data, queueContext->DeviceContext->DeviceData, 64);

		status = RequestCopyFromBuffer(request, &readReport, sizeof(readReport));

		WdfRequestComplete(request, status);
	}
}

NTSTATUS
CheckRegistryForDescriptor(
	WDFDEVICE Device
)
/*++

Routine Description:

	Read "ReadFromRegistry" key value from device parameters in the registry.

Arguments:

	device - pointer to a device object.

Return Value:

	NT status code.

--*/

{
	WDFKEY          hKey = NULL;
	NTSTATUS        status;
	UNICODE_STRING  valueName;
	ULONG           value;

	status = WdfDeviceOpenRegistryKey(Device,
		PLUGPLAY_REGKEY_DEVICE,
		KEY_READ,
		WDF_NO_OBJECT_ATTRIBUTES,
		&hKey);
	if (NT_SUCCESS(status)) {

		RtlInitUnicodeString(&valueName, L"ReadFromRegistry");

		status = WdfRegistryQueryULong(hKey,
			&valueName,
			&value);

		if (NT_SUCCESS(status)) {
			if (value == 0) {
				status = STATUS_UNSUCCESSFUL;
			}
		}

		WdfRegistryClose(hKey);
	}

	return status;
}

NTSTATUS
ReadDescriptorFromRegistry(
	WDFDEVICE Device
)
/*++

Routine Description:

	Read HID report descriptor from registry

Arguments:

	device - pointer to a device object.

Return Value:

	NT status code.

--*/
{
	WDFKEY          hKey = NULL;
	NTSTATUS        status;
	UNICODE_STRING  valueName;
	WDFMEMORY       memory;
	size_t          bufferSize;
	PVOID           reportDescriptor;
	PDEVICE_CONTEXT deviceContext;
	WDF_OBJECT_ATTRIBUTES   attributes;

	deviceContext = GetDeviceContext(Device);

	status = WdfDeviceOpenRegistryKey(Device,
		PLUGPLAY_REGKEY_DEVICE,
		KEY_READ,
		WDF_NO_OBJECT_ATTRIBUTES,
		&hKey);

	if (NT_SUCCESS(status)) {

		RtlInitUnicodeString(&valueName, L"MyReportDescriptor");

		WDF_OBJECT_ATTRIBUTES_INIT(&attributes);
		attributes.ParentObject = Device;

		status = WdfRegistryQueryMemory(hKey,
			&valueName,
			NonPagedPool,
			&attributes,
			&memory,
			NULL);

		if (NT_SUCCESS(status)) {

			reportDescriptor = WdfMemoryGetBuffer(memory, &bufferSize);

			KdPrint(("No. of report descriptor bytes copied: %d\n", (INT)bufferSize));

			//
			// Store the registry report descriptor in the device extension
			//
			deviceContext->ReadReportDescFromRegistry = TRUE;
			deviceContext->ReportDescriptor = reportDescriptor;
			deviceContext->HidDescriptor.DescriptorList[0].wReportLength = (USHORT)bufferSize;
		}

		WdfRegistryClose(hKey);
	}

	return status;
}

char hexDump1[65];
char hexDump2[65];
VOID displayHexDump(UCHAR *buf) {
	formatHexDump(buf);
	KdPrint(("%s\n", hexDump1));
	KdPrint(("%s\n", hexDump2));
}
VOID formatHexDump(UCHAR *buf) {
	int i = 0;

	for (i = 0; i < 32; i++) {
		sprintf_s(&hexDump1[2 * i], 3, "%02x", buf[i]);
	}
	hexDump1[64] = 0;
	for (i = 0; i < 32; i++) {
		sprintf_s(&hexDump2[2 * i], 3, "%02x", buf[32 + i]);
	}
	hexDump2[64] = 0;
}
