/*++

Copyright (C) Microsoft Corporation, All Rights Reserved

Module Name:

    GTFidoHid.h

Abstract:

    This module contains the type definitions for the driver

Environment:

    Windows Driver Framework (WDF)

--*/

#include <windows.h>

#include <wdf.h>

#include <stdio.h>

#include <hidport.h>  // located in $(DDK_INC_PATH)/wdm

#include "common.h"

typedef UCHAR HID_REPORT_DESCRIPTOR, *PHID_REPORT_DESCRIPTOR;

DRIVER_INITIALIZE                   DriverEntry;
EVT_WDF_DRIVER_DEVICE_ADD           EvtDeviceAdd;
EVT_WDF_TIMER                       EvtTimerFunc;

typedef struct _DEVICE_CONTEXT
{
	WDFDEVICE               Device;
	WDFQUEUE                DefaultQueue;
	WDFQUEUE                ReadReportQueue;
	//WDFQUEUE                GetReportQueue;
	HID_DEVICE_ATTRIBUTES   HidDeviceAttributes;
	BYTE                    DeviceData[64];
	HID_DESCRIPTOR          HidDescriptor;
	PHID_REPORT_DESCRIPTOR  ReportDescriptor;
	BOOLEAN                 ReadReportDescFromRegistry;

} DEVICE_CONTEXT, *PDEVICE_CONTEXT;

WDF_DECLARE_CONTEXT_TYPE_WITH_NAME(DEVICE_CONTEXT, GetDeviceContext);

typedef struct _QUEUE_CONTEXT
{
	WDFQUEUE                Queue;
	PDEVICE_CONTEXT         DeviceContext;
	UCHAR                   OutputReport[64];

} QUEUE_CONTEXT, *PQUEUE_CONTEXT;

WDF_DECLARE_CONTEXT_TYPE_WITH_NAME(QUEUE_CONTEXT, GetQueueContext);

NTSTATUS
QueueCreate(
	_In_  WDFDEVICE         Device,
	_Out_ WDFQUEUE          *Queue
);

typedef struct _REPORT_QUEUE_CONTEXT
{
	WDFQUEUE                Queue;
	PDEVICE_CONTEXT         DeviceContext;
	WDFTIMER                Timer;

} REPORT_QUEUE_CONTEXT, *PREPORT_QUEUE_CONTEXT;

WDF_DECLARE_CONTEXT_TYPE_WITH_NAME(REPORT_QUEUE_CONTEXT, RetrieveReportQueueContext);

NTSTATUS
ReportQueueCreate(
	_In_  WDFDEVICE         Device,
	_Out_ WDFQUEUE          *Queue,
	_In_  BOOLEAN			bHasTimer
);

NTSTATUS
ReadReport(
	_In_  PQUEUE_CONTEXT    QueueContext,
	_In_  WDFREQUEST        Request,
	_Always_(_Out_)
	BOOLEAN*          CompleteRequest
);

NTSTATUS
WriteReport(
	_In_  PQUEUE_CONTEXT    QueueContext,
	_In_  WDFREQUEST        Request,
	_Out_ BOOLEAN			*bPopGetReportQueue
);

NTSTATUS
GetInputReport(
	_In_  PQUEUE_CONTEXT    QueueContext,
	_In_  WDFREQUEST        Request,
	_Always_(_Out_)
	BOOLEAN					*bCompleteRequest
);

NTSTATUS
SetOutputReport(
	_In_  PQUEUE_CONTEXT    QueueContext,
	_In_  WDFREQUEST        Request,
	_Out_ BOOLEAN			*bPopReadReportQueue
);

NTSTATUS
GetStringId(
	_In_  WDFREQUEST        Request,
	_Out_ ULONG            *StringId,
	_Out_ ULONG            *LanguageId
);

NTSTATUS
GetString(
	_In_  WDFREQUEST        Request
);

NTSTATUS
RequestCopyFromBuffer(
	_In_  WDFREQUEST        Request,
	_In_  PVOID             SourceBuffer,
	_When_(NumBytesToCopyFrom == 0, __drv_reportError(NumBytesToCopyFrom cannot be zero))
	_In_  size_t            NumBytesToCopyFrom
);

NTSTATUS
RequestGetHidXferPacket_ToReadFromDevice(
	_In_  WDFREQUEST        Request,
	_Out_ HID_XFER_PACKET  *Packet
);

NTSTATUS
RequestGetHidXferPacket_ToWriteToDevice(
	_In_  WDFREQUEST        Request,
	_Out_ HID_XFER_PACKET  *Packet
);

NTSTATUS
CheckRegistryForDescriptor(
	_In_ WDFDEVICE Device
);

NTSTATUS
ReadDescriptorFromRegistry(
	_In_ WDFDEVICE Device
);

VOID PopGetReportQueue(_In_  PQUEUE_CONTEXT    QueueContext);
VOID PopReadReportQueue(_In_  PQUEUE_CONTEXT    QueueContext);
VOID displayHexDump(UCHAR *buf);
VOID formatHexDump(UCHAR *buf);
//
// Misc definitions
//

//
// These are the device attributes returned by the mini driver in response
// to IOCTL_HID_GET_DEVICE_ATTRIBUTES.
//
#define HIDMINI_PID             0xFEED
#define HIDMINI_VID             0xDEED
#define HIDMINI_VERSION         0x0101

#define CID_BROADCAST           0xffffffff	// Broadcast channel id

#define TYPE_MASK               0x80	// Frame type mask
#define TYPE_INIT               0x80	// Initial frame identifier
#define TYPE_CONT               0x00	// Continuation frame identifier
