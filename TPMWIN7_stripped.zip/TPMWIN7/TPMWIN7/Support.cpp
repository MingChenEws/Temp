#include "stdafx.h"

HRESULT
PcpToolGetVersion(
int argc,
_In_reads_(argc) WCHAR* argv[]
)
/*++
Retrieve the version strings from the PCP provider and the TPM.
--*/
{
	HRESULT hr = S_OK;
	BCRYPT_ALG_HANDLE hAlg = NULL;
	WCHAR versionData[256] = L"";
	DWORD cbData = 0;


	TBS_HCONTEXT hContext = NULL;
//	TBS_CONTEXT_PARAMS2 contextParams = { 0 };
	TBS_CONTEXT_PARAMS contextParams = { TBS_CONTEXT_VERSION_ONE };


	UNREFERENCED_PARAMETER(argc);
	UNREFERENCED_PARAMETER(argv);


	// Open TBS and read the current log
//	contextParams.version = TBS_CONTEXT_VERSION_TWO;
//	contextParams.asUINT32 = 0;
//	contextParams.includeTpm12 = 1;
//	contextParams.includeTpm20 = 1;
	if (FAILED(hr = Tbsi_Context_Create((PTBS_CONTEXT_PARAMS)&contextParams, &hContext)))
	{
		goto Cleanup;
	}

	ZeroMemory(versionData, sizeof(versionData));

	if (FAILED(hr = HRESULT_FROM_NT(BCryptOpenAlgorithmProvider(
		&hAlg,
		BCRYPT_RNG_ALGORITHM,
		MS_PRIMITIVE_PROVIDER,
		0))))
	{
		goto Cleanup;
	}

#if 0
	if (FAILED(hr = HRESULT_FROM_NT(BCryptOpenAlgorithmProvider(
		&hAlg,
		BCRYPT_RNG_ALGORITHM,
		MS_PLATFORM_CRYPTO_PROVIDER,
		0))))
	{
		goto Cleanup;
	}
#endif

	if (FAILED(hr = HRESULT_FROM_NT(BCryptGetProperty(
		hAlg,
		BCRYPT_PCP_PROVIDER_VERSION_PROPERTY,
		(PUCHAR)versionData,
		sizeof(versionData) - sizeof(WCHAR),
		&cbData,
		0))))
	{
		goto Cleanup;
	}

	if (cbData > sizeof(versionData) - sizeof(WCHAR))
	{
		hr = HRESULT_FROM_WIN32(ERROR_INVALID_DATA);
		goto Cleanup;
	}
	versionData[cbData / sizeof(WCHAR)] = 0x0000;

	wprintf(L"<Version>\n");
	wprintf(L"  <Provider>%s</Provider>\n", versionData);

	if (FAILED(hr = HRESULT_FROM_NT(BCryptGetProperty(
		hAlg,
		BCRYPT_PCP_PLATFORM_TYPE_PROPERTY,
		(PUCHAR)versionData,
		sizeof(versionData) - sizeof(WCHAR),
		&cbData,
		0))))
	{
		goto Cleanup;
	}

	if (cbData > sizeof(versionData) - sizeof(WCHAR))
	{
		hr = HRESULT_FROM_WIN32(ERROR_INVALID_DATA);
		goto Cleanup;
	}
	versionData[cbData / sizeof(WCHAR)] = 0x0000;

	wprintf(L"  <TPM>\n    %s\n  </TPM>\n", versionData);
	wprintf(L"</Version>\n");

Cleanup:
	if (hAlg != NULL)
	{
		BCryptCloseAlgorithmProvider(hAlg, 0);
		hAlg = NULL;
	}
	PcpToolCallResult(L"PcpToolGetVersion()", hr);
	return hr;
}


void
PcpToolCallResult(
_In_ WCHAR* func,
HRESULT hr
)
{
	PWSTR Buffer = NULL;
	DWORD result = 0;

	if (FAILED(hr))
	{
		result = FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER |
			FORMAT_MESSAGE_FROM_SYSTEM |
			FORMAT_MESSAGE_IGNORE_INSERTS,
			(PVOID)GetModuleHandle(NULL),
			hr,
			MAKELANGID(LANG_NEUTRAL, SUBLANG_NEUTRAL),
			(PTSTR)&Buffer,
			0,
			NULL);

		if (result != 0)
		{
			wprintf(L"ERROR - %s: (0x%08lx) %s\n", func, hr, Buffer);
		}
		else
		{
			wprintf(L"ERROR - %s: (0x%08lx)\n", func, hr);
		}
		LocalFree(Buffer);
	}
}

